import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[4]
os.chdir(root)
run = Path(__file__).resolve().parent
env = os.environ | {'GIT_OPTIONAL_LOCKS': '0'}
plan = json.loads(Path('Design/AgentReports/SkirmishExpansion/EngineeringCheckpoint/CurrentCandidateStableUnion/CURRENT_CHECKPOINT.plan.json').read_text(encoding='utf-8-sig'))
expected = {}
for row in plan['exactCurrentRows']:
    path = row['path'].replace('\\', '/')
    assert path not in expected or expected[path] == row['sha256'], path
    expected[path] = row['sha256']
expected['.gitattributes'] = hashlib.sha256(Path('.gitattributes').read_bytes()).hexdigest()
approved = {path.replace('\\', '/') for path in plan['stageExactChangedPaths']}
extra = run / 'extra-staged-approved.json'
if extra.exists():
    for row in json.loads(extra.read_text(encoding='utf-8-sig')):
        expected[row['path']] = row['sha256']
        approved.add(row['path'])
staged = [path.decode('utf-8') for path in subprocess.check_output(['git', 'diff', '--cached', '--name-only', '--no-renames', '-z'], env=env).split(b'\0') if path]
assert staged and set(staged) <= approved, set(staged) - approved
data = subprocess.check_output(['git', 'cat-file', '--batch'], input=''.join(':' + path + '\n' for path in staged).encode('utf-8'), env=env)
position = 0
bad = []
for path in staged:
    end = data.index(b'\n', position)
    fields = data[position:end].decode('utf-8').split()
    assert len(fields) == 3 and fields[1] == 'blob', (path, fields)
    size = int(fields[2])
    start = end + 1
    actual = hashlib.sha256(data[start:start + size]).hexdigest()
    position = start + size + 1
    if actual != expected[path]:
        bad.append({'path': path, 'expected': expected[path], 'actual': actual})
assert position == len(data)
assert not bad, bad
result = {'stagedFiles': len(staged), 'expectedByteHashesMatched': len(staged), 'unapprovedPaths': 0, 'allStagedBlobsEqualTestedBytes': True, 'planPathsNormalizedToGitSeparators': True}
(run / 'staged-blob-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result))
