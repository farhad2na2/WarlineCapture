"""Synthetic offline parser controls only. No native, source or gameplay calls."""
import copy,hashlib,importlib.util,json,pathlib

bundle=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('campaign_m3_1281_qualifier',bundle/'run_campaign_m3_1281.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
log='[CampaignM3Journey1281] result=Passed\n[CampaignNativeSelection] result=Passed\n[CampaignScopedJourney] result=Passed mission=3\n[CampaignTutorialEntry] result=Passed\n'
mission='saga.ch01.m03.radar_warning'
stages=['CampaignLaunchObserved','InitialDragDispatched','InitialDragAccepted','NativeHoldFourAccepted','NativeVictoryRendered','CampaignReturnRendered']
rows=[dict(stage=s,entry=7,frame=10+i,mission=mission,session='native-m3',attempt=1,readOnly=True,launchOrigin='CampaignOperations',returnDestination='CampaignOperations',selected=4,held=4,group='rifle-native',convoyElements=2,convoyResolved=2,actualRendered=True,outcome='Victory') for i,s in enumerate(stages)]
rows[0].update(returnDestination='None',outcome='None',phase='Engage')
def sample(wall,eligible=True,visible=True,missing=0):
    return dict(entry=7,mission=mission,phase='Engage',wall=wall,eligibleDefense=eligible,legitimateOwnedSurface=not eligible,activePredicatePanel=visible,statusText='00:30' if visible else '',missingSeconds=missing)
base=[sample(10)]
cases=[]
def check(name,expect_pass,raw=None,status=None,text=log):
    errors=module.qualify(text,rows if raw is None else raw,base if status is None else status,'fa-IR')
    passed=not errors
    assert passed==expect_pass,(name,errors)
    cases.append(dict(name=name,expectedAccepted=expect_pass,actualAccepted=passed,errors=errors))
check('valid complete ordered native witnesses',True)
for index,key,value,name in [(0,'launchOrigin','FirstLaunch','reject nonCampaign public origin'),(0,'returnDestination','CampaignOperations','reject premature terminal destination at launch'),(0,'outcome','Victory','reject terminal outcome disguised as launch'),(4,'returnDestination','None','reject missing native Victory destination'),(5,'returnDestination','None','reject missing rendered return destination'),(5,'outcome','Defeat','reject nonVictory return')]:
    bad=copy.deepcopy(rows);bad[index][key]=value;check(name,False,raw=bad)
for stage in ('InitialDragAccepted','NativeHoldFourAccepted','NativeVictoryRendered','CampaignReturnRendered'):
    check('reject missing '+stage,False,raw=[r for r in rows if r['stage']!=stage])
bad=copy.deepcopy(rows);bad[4]['convoyResolved']=1;check('reject missing second resolved convoy',False,raw=bad)
check('reject missing eligible visible countdown',False,status=[sample(10,eligible=False,visible=False)])
check('reject genuine eligible missing gap greater than1.5',False,status=[sample(10),sample(11,visible=False),sample(12.6,visible=False,missing=1.6),sample(12.7)])
check('allow long legitimate FullMap suppression followed by immediate eligible restoration',True,status=[sample(10),sample(11,eligible=False,visible=False),sample(14,eligible=False,visible=False,missing=3),sample(14.1,visible=False,missing=3.1),sample(14.2)])
check('reset previous missing gap on legitimate own surface',True,status=[sample(10),sample(11,visible=False),sample(12,eligible=False,visible=False,missing=1),sample(14,visible=False,missing=3),sample(14.1)])
check('reject native explicit countdown failure even after restored visibility',False,text=log+'[CampaignNativeContinuousStatus1281] result=Failed\n')
check('reject nonmonotonic status chronology',False,status=[sample(10),sample(9)])
check('reject nonfinite status time',False,status=[sample(10),sample(float('nan'))])
white=[sample(10),sample(11),sample(12.6),sample(12.7)]
white[1]['statusText']=white[2]['statusText']='   '
check('whitespace is missing and rejects true eligible gap',False,status=white)
bad=copy.deepcopy(rows);bad[2]['selected']=3;check('reject partial initial Rifle selection',False,raw=bad)
bad=copy.deepcopy(rows);bad[3]['held']=3;check('reject partial Rifle Hold',False,raw=bad)
bad=copy.deepcopy(rows);bad[4]['actualRendered']=False;check('reject unrendered native Victory',False,raw=bad)
bad=copy.deepcopy(rows);bad[5]['frame']=1;check('reject return before Victory',False,raw=bad)
output=bundle/'offline-parser-controls.json'
with output.open('x') as stream:json.dump(dict(result='Passed',controls=len(cases),scope='Synthetic flat parser controls only; no native execution or gameplay proof',runnerSha256=hashlib.sha256((bundle/'run_campaign_m3_1281.py').read_bytes()).hexdigest(),cases=cases),stream,indent=2);stream.write('\n')
print(json.dumps(dict(result='Passed',controls=len(cases),file=str(output))))
