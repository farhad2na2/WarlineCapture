# 1278 runner-only V2

Original1278 bundle remains immutable. Native fixture/idle paths remain original, preserving the successful exact dry compile. Only the exact validated dry proof path+SHA is excluded from artifact collisions. Other compile/load/source/native evidence blocks launch. No native run has occurred.

rtk proxy python3 /private/tmp/s005-stop-manual-takeover1278-runner-v2/runner.py final-1258-ground-carrier-post-source-manifest.json --dry-compile-proof /Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/compile1278-stop-manual-reviewed-dry-run.json --heavy-lane-owner main1278

Same1278 source/fixture/seed155926/control/Victory/return gates; no new native compile is needed for this runner-only correction. Ten pure collision controls pass; original57 proof-schema controls are preserved unchanged. Root owns native execution.
