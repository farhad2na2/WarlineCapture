"""Offline parser/clone controls only; no native calls and no gameplay qualification."""
import ast, hashlib, json, pathlib

BASE=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
matrix=json.loads((BASE/'matrix-manifest.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def record(name,fn):
 fn();checks.append(name)
def raises(fn):
 try:fn()
 except ValueError:return
 raise AssertionError('Negative control was accepted')
def extracted_guard(tree,label):
 matches=[n for n in ast.walk(tree) if isinstance(n,ast.If) and any(isinstance(k,ast.Constant) and k.value==label for k in ast.walk(n))]
 assert len(matches)==1,(label,len(matches))
 return compile(ast.fix_missing_locations(ast.Module(body=matches,type_ignores=[])),'actual-runner-guard','exec')

for run in matrix['runs']:
 rid=run['id'];fixture=pathlib.Path(run['fixture']);runner=pathlib.Path(run['runner']);prep=json.loads(pathlib.Path(run['prep']).read_text())
 assert sha(fixture)==run['fixtureSha256']==prep['fixtureSha256']
 assert sha(runner)==run['runnerSha256']==prep['runnerSha256']
 assert sha(pathlib.Path(run['prep']))==run['prepSha256']
 original=BASE/'preserved-lineage'/str(rid-13)/f'S005NormalAria{rid-13}Observer.cs'
 assert fixture.read_text().replace(str(rid),str(rid-13))==original.read_text()
 assert prep['currentCandidateSourceHash']==matrix['candidateHash']
 assert prep['normalDefaults']['size']=='Standard' and prep['normalDefaults']['difficulty']=='Regular'
 assert prep['normalDefaults']['developmentFullVision'] is False and prep['normalDefaults']['sharedFog'] is True
 tree=ast.parse(runner.read_text())
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_aria_no_physical_takeover']
 assert len(nodes)==1
 ns={};exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'actual-runner-physical-guard','exec'),ns)
 guard=ns['verify_aria_no_physical_takeover']
 good=[dict(kind='Ended',unexpected=0,interventions=0,receiptViolations=0)]
 record(f'{rid}:positive-zero-intervention-control',lambda:guard('',good))
 for field in ('unexpected','interventions','receiptViolations'):
  bad=[dict(good[0]),dict(good[0],**{field:1}),dict(good[0])]
  record(f'{rid}:reject-earlier-{field}-even-clean-final-row',lambda bad=bad:raises(lambda:guard('',bad)))
 record(f'{rid}:reject-physical-kind-even-zero-counters',lambda:raises(lambda:guard('',[dict(good[0],kind='PhysicalTakeover')])))
 record(f'{rid}:reject-missing-counter',lambda:raises(lambda:guard('',[dict(kind='Ended',interventions=0,unexpected=0)])))
 record(f'{rid}:reject-empty-touch',lambda:raises(lambda:guard('',[])))
 record(f'{rid}:reject-actual-physical-log-marker',lambda:raises(lambda:guard('[AriaTouchInput] physicalTakeover device=Mouse type=FastMouse generated=False',good)))
 record(f'{rid}:reject-manual-abort-marker',lambda:raises(lambda:guard('ariaStopped:Manual',good)))
 native=extracted_guard(tree,'Actual wrapper/native exit must both be0 for counted win')
 for wrapper,receipt in ((0,0),(1,0),(0,1)):
  env=dict(wrapper=wrapper,native=receipt,errors=[]);exec(native,env)
  assert bool(env['errors'])==(wrapper!=0 or receipt!=0)
  checks.append(f'{rid}:actual-wrapper-native-guard-{wrapper}-{receipt}')
 source=extracted_guard(tree,'Full source/material manifests changed')
 for same in (True,False):
  env=dict(same=same,errors=[]);exec(source,env);assert bool(env['errors']) is (not same)
  checks.append(f'{rid}:actual-full-source-guard-{same}')
 terminalguard=extracted_guard(tree,'Actual frozen Victory trace/clock missing')
 valid=dict(phase='Finished',outcome='Victory',clockPaused=1,simulationActive=0,elapsed=200)
 for field,bad in [('outcome','Defeat'),('clockPaused',0),('simulationActive',1),('elapsed',1081)]:
  env=dict(terminal=dict(valid,**{field:bad}),errors=[]);exec(terminalguard,env);assert env['errors']
  checks.append(f'{rid}:actual-frozen-result-guard-{field}')
 env=dict(terminal=valid,errors=[]);exec(terminalguard,env);assert not env['errors']
 checks.append(f'{rid}:actual-frozen-result-positive')
 # This is real preserved failed input evidence, tested offline, never rewritten/promoted.
 physical=json.loads((BASE/'preserved-lineage'/'native1253-normal-aria-failure.json').read_text())
 raw=[json.loads(l) for l in (BASE/'preserved-lineage'/(physical['trace']+'.touch.jsonl')).read_text().splitlines() if l.strip()]
 record(f'{rid}:reject-real-preserved1253-input',lambda:raises(lambda:guard('',raw)))

assert [(r['locale'],r['seed']) for r in matrix['runs']]==[('en',104734),('en',130368),('en',155926),('fa-IR',104734),('fa-IR',130368),('fa-IR',155926)]
out={'result':'Passed','scope':'Offline actual-runner negative controls and immutable fixture/source/seed clone checks. No Unity execution or native qualification.','cases':len(checks),'checks':checks,'candidateHash':matrix['candidateHash'],'matrixSha256':sha(BASE/'matrix-manifest.json'),'nativeExecuted':False,'playerReady':False}
with (BASE/'offline-controls-result.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('result','cases','scope','candidateHash')},indent=2))
