$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\SharedNativePreparation\20261015-01'
$markerPath = Join-Path $projectPath 'Design\AgentReports\SkirmishExpansion\S005\aircraft-framing-inventory\SHARED150_NATIVE_MARKERS_20261015.json'
$markers = Get-Content -LiteralPath $markerPath -Raw | ConvertFrom-Json
$refreshPath = Join-Path $projectPath 'Tools\CI\SkirmishProductionDrafts\TransportMeasuredDependencyRefresh\manifest.json'
$refresh = Get-Content -LiteralPath $refreshPath -Raw | ConvertFrom-Json
$inputPath = Join-Path $runPath 'provenance-input.json'
$ownedExit = 1
try {
    $inputFacts = Get-Content -LiteralPath $inputPath -Raw | ConvertFrom-Json
    $actualSha = (Get-FileHash -LiteralPath $inputFacts.report -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha -ne $inputFacts.sha256) { throw 'Fresh provenance report hash mismatch' }
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_REPORT = $inputFacts.report
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_SHA256 = $actualSha
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    & (Join-Path $projectPath 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unityPath -ProjectPath $projectPath -ExecuteMethod $refresh.entry -LogFile (Join-Path $runPath 'unity.log') -RequiredPassMarker $refresh.required_final_marker -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if ($LASTEXITCODE -ne 0) { throw 'Checked shared native validation failed' }
    $logText = [IO.File]::ReadAllText((Join-Path $runPath 'unity.log'))
    foreach ($marker in $markers.required_independent_markers) {
        if (-not $logText.Contains($marker)) { throw "Missing independent marker: $marker" }
    }
    foreach ($marker in @($refresh.required_refresh_marker, $refresh.required_controls_marker, $refresh.required_final_marker)) {
        if (-not $logText.Contains($marker)) { throw "Missing transport refresh marker: $marker" }
    }
    if ($logText.Contains('suiteFailed=')) { throw 'Independent suite failure found' }
    $ownedExit = 0
    Write-Output '[Shared150RootChecks] result=Passed independentMarkers=13 refreshMarkers=3 missionAcceptance=Pending'
} catch {
    [Console]::Error.WriteLine($_.ToString())
} finally {
    [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit)
}
exit $ownedExit
