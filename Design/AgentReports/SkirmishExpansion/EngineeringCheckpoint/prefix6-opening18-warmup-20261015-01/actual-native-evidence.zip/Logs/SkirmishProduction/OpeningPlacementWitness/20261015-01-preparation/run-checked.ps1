$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\OpeningPlacementWitness\20261015-01-preparation'
$ownedExit=1
try {
    $env:WARLINE_S005_SCENE_WARMUP_OUTPUT=Join-Path $run 'scene-warmup.json'
    $facts=Get-Content -LiteralPath (Join-Path $project 'Tools\CI\SkirmishProductionDrafts\PilotStaticPrefixWitnessSuccessor\manifest.json') -Raw|ConvertFrom-Json
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    & (Join-Path $project 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unity -ProjectPath $project -ExecuteMethod $facts.preparation_entry -LogFile (Join-Path $run 'unity.log') -RequiredPassMarker $facts.required_markers[-1] -BuildTarget Android -GuiLicensing -TimeoutSeconds 900
    if($LASTEXITCODE -ne 0){throw 'Native prefix/opening controls and warmup failed'}
    $log=[IO.File]::ReadAllText((Join-Path $run 'unity.log'))
    foreach($marker in $facts.required_markers){if(-not $log.Contains($marker)){throw "Missing marker: $marker"}}
    if(-not $log.Contains('[S005SceneArtifactWarmup] result=Passed scenes=2 keySource=NativeEditorSceneSystem defaultWorldPreserved=1 playStarted=0 missionCertified=0 snapshotAfterWrapperExit=1')){throw 'Warmup marker absent'}
    $ownedExit=0
}catch{[Console]::Error.WriteLine($_.ToString())}
finally{[IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
