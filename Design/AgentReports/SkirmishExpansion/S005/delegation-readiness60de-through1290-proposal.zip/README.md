# External current-source readiness reconciliation through1290

Proposal only. CURRENT_ACCEPTANCE.md and TECHNICAL_READINESS_CURRENT.json have not been written. Source60de remains unchanged; technicallyReady/playerReady stay false.

CURRENT_ACCEPTANCE.patch replaces only the authoritative source60de top section. The full historical suffix is identical. Requested closed cargo1272/1282/1289, Stop/manual1278/1287, air1280/1284, Campaign1275/1281 failures and their exact pinned logs remain failures. The scoped1273 ten-cycle reset/pause/input pass explicitly leaves fullX17/memory stability pending, including its observed Editor native/graphics allocation growth. Six-case ARIA/EN1262 qualifications retain their original scopes.

The proposal additionally incorporates the independently audited immutable1290 real Stop/manual controls + naturalVictory/renderedMainMenu pass. Original1290 runner failure and all raw failure/cleanup rows remain unchanged. No replay or manufactured TerminalClosure row was used. Foreign QA carry-reset branch was not natively exercised; physical automatic takeover and human/device acceptance remain pending.

Keyed update-readiness.py defaults to read-only validation. It reads the latest shared state, compares exactly reviewed key values, refuses activeRun ownership, changed source/readiness/evidence, or any newly added/changed latest-evidence key, verifies every dedicated proof/log pin, and preserves unrelated historical/unknown keys. It never changes active ownership, map/source/shipping identity or applies the Markdown patch. Any later1291 or other completed result must be incorporated into a fresh reviewed revision before application; this frozen proposal is not permission to overwrite newer evidence.

Read-only check:
rtk proxy python3 /private/tmp/s005-readiness60de-through1290-proposal/update-readiness.py

Optional external preview after actual idle and unchanged evidence:
rtk proxy python3 /private/tmp/s005-readiness60de-through1290-proposal/update-readiness.py --output /private/tmp/s005-reviewed-readiness-through1290-preview.json

Root-only reviewed application, only after idle and refreshed cutoff if necessary:
rtk proxy python3 /private/tmp/s005-readiness60de-through1290-proposal/update-readiness.py --apply --backup /private/tmp/s005-readiness-before-reviewed-through1290.json

Review/apply CURRENT_ACCEPTANCE.patch separately; git apply --check passed at preparation.36 pure negative compare-and-set controls pass, including active-run/new-evidence/key conflicts, preserving history and refusing player-ready promotion. The real default check deliberately refused current native1291 ownership. No shared document, Unity, gameplay or Git mutation occurred.
