$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\SharedNativePreparation\20261015-03-ui-storage'
$markerPath = Join-Path $projectPath 'Tools\CI\SkirmishProductionDrafts\AriaUiOwnedStorage\NATIVE_MARKERS.json'
$markers = Get-Content -LiteralPath $markerPath -Raw | ConvertFrom-Json
$ownedExit = 1
try {
    $inputFacts = Get-Content -LiteralPath (Join-Path $runPath 'provenance-input.json') -Raw | ConvertFrom-Json
    $hashStream = [IO.File]::OpenRead($inputFacts.report)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { $actualSha = [BitConverter]::ToString($hasher.ComputeHash($hashStream)).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose(); $hashStream.Dispose() }
    if ($actualSha -ne $inputFacts.sha256) { throw 'Fresh provenance report hash mismatch' }
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_REPORT = $inputFacts.report
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_SHA256 = $actualSha
    $env:WARLINE_S005_SCENE_WARMUP_OUTPUT = Join-Path $runPath 'scene-warmup.json'
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    & (Join-Path $projectPath 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unityPath -ProjectPath $projectPath -ExecuteMethod $markers.entry -LogFile (Join-Path $runPath 'unity.log') -RequiredPassMarker $markers.required_markers[-1] -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if ($LASTEXITCODE -ne 0) { throw 'Checked shared/UI/warmup validation failed' }
    $logText = [IO.File]::ReadAllText((Join-Path $runPath 'unity.log'))
    foreach ($marker in $markers.required_markers) {
        if (-not $logText.Contains($marker)) { throw "Missing required marker: $marker" }
    }
    if ($logText.Contains('suiteFailed=')) { throw 'Independent suite failure found' }
    $ownedExit = 0
    Write-Output '[UiStorageRootChecks] result=Passed sharedControls=150 uiStorageControls=7 warmupScenes=2 markers=18 snapshotRequiredAfterThisExit=1'
} catch {
    [Console]::Error.WriteLine($_.ToString())
} finally {
    [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit)
}
exit $ownedExit
