import ast,copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('q1290',P/'qualifier.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
checks=[]
def check(name,rows,expect):
 try:q.qualify_fresh_manual(rows,'current');ok=True
 except (ValueError,KeyError,TypeError):ok=False
 if ok!=expect:raise AssertionError(name)
 checks.append({'name':name,'passed':True,'expectedAccept':expect})
base=[dict(stage='StopVerified',frame=10,attempt='current'),dict(stage='ManualCarryGuardCensus',frame=11,attempt='current',qaOnly=True,sameAttempt=True,carryPending=False,resumeActive=False,nativeRecovery=False,resumeSession='old',resumeDone=True,resumeCombat=True,resumeAttackReceipts=2,evidenceActive=True),dict(stage='ManualDriverFreshStarted',frame=12,attempt='current',qaOnly=True,sameAttempt=True,carryAfter=False,evidenceActive=True,priorGestures=0,manualActions=0,manualAttackReceipts=0),dict(stage='ManualOwnershipHandoff',frame=13,attempt='current')]
check('No pending carry performs no cleanup mutation',base,True)
stale=copy.deepcopy(base);stale[1]['carryPending']=True
stale.insert(2,dict(stage='InactiveForeignQaCarryCleared',frame=11,attempt='current',qaOnly=True,sameAttempt=True,carryPending=True,clearedStaleCarry=True,carryAfter=False,nativeRecovery=False,resumeSession='old'))
stale.append(dict(stage='QaCarryFlagRestored',frame=1,attempt='current',qaOnly=True,playing=False,carryPending=True,carryAfter=True,restoredExact=True))
check('Inactive identified foreign carry with exact closed restoration',stale,True)
for stage,key,val in [('ManualCarryGuardCensus','resumeActive',True),('ManualCarryGuardCensus','nativeRecovery',True),('ManualCarryGuardCensus','attempt','foreign'),('ManualCarryGuardCensus','sameAttempt',False),('ManualCarryGuardCensus','qaOnly',False),('ManualCarryGuardCensus','resumeSession','current'),('ManualCarryGuardCensus','resumeSession',''),('ManualDriverFreshStarted','carryAfter',True),('ManualDriverFreshStarted','evidenceActive',False),('ManualDriverFreshStarted','priorGestures',1),('ManualDriverFreshStarted','manualActions',1),('ManualDriverFreshStarted','manualAttackReceipts',1),('ManualDriverFreshStarted','frame',9),('InactiveForeignQaCarryCleared','resumeSession','other'),('InactiveForeignQaCarryCleared','clearedStaleCarry',False),('InactiveForeignQaCarryCleared','nativeRecovery',True),('InactiveForeignQaCarryCleared','carryAfter',True),('QaCarryFlagRestored','playing',True),('QaCarryFlagRestored','carryAfter',False),('QaCarryFlagRestored','restoredExact',False)]:
 rows=copy.deepcopy(stale);next(r for r in rows if r['stage']==stage)[key]=val;check(stage+'/'+key,rows,False)
early=copy.deepcopy(stale);restore=early.pop();early.insert(0,restore);check('Restore before handoff forbidden by actual raw row order',early,False)
for stage in ['ManualCarryGuardCensus','ManualDriverFreshStarted','InactiveForeignQaCarryCleared','QaCarryFlagRestored','StopVerified','ManualOwnershipHandoff']:
 check('Missing '+stage,[r for r in stale if r['stage']!=stage],False)
 rows=copy.deepcopy(stale);rows.append(copy.deepcopy(next(r for r in rows if r['stage']==stage)));check('Duplicate '+stage,rows,False)
rows=copy.deepcopy(base);rows.append(copy.deepcopy(stale[2]));check('No carry forbids cleanup',rows,False)
rows=copy.deepcopy(base);del rows[1]['carryPending'];check('Missing actual carry operand',rows,False)
for file in P.glob('*.py'):ast.parse(file.read_text())
result={'result':'Passed','cases':len(checks),'scope':'Synthetic offline negative parser controls only; no native carry/gameplay result manufactured','checks':checks}
with (P/'fresh-manual-controls-results.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'result':'Passed','cases':len(checks),'nativeExecuted':False}))
