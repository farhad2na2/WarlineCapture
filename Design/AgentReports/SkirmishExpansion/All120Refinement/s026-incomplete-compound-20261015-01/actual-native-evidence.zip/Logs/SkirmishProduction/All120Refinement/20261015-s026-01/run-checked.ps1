$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\All120Refinement\20261015-s026-01'
$ownedExit = 1
try {
    $env:WARLINE_ALL120_REFINEMENT_CATALOG = 'S026'
    $env:WARLINE_ALL120_REFINEMENT_OUTPUT = Join-Path $runPath 'S026.json'
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    & (Join-Path $projectPath 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unityPath -ProjectPath $projectPath -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.RunAll120SimultaneousLogicalRefinement' -LogFile (Join-Path $runPath 'unity.log') -RequiredPassMarker '[All120SimultaneousLogicalRefinement] result=Collected catalog=S026 sourceFitCertified=0' -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if ($LASTEXITCODE -ne 0) { throw 'Checked native S026 source collection failed' }
    $ownedExit = 0
} catch { [Console]::Error.WriteLine($_.ToString()) }
finally { [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit) }
exit $ownedExit
