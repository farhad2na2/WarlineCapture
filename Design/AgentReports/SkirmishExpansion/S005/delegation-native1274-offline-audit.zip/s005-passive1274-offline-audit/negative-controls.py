"""Strict offline controls over retained actual1274 evidence; no native calls."""
import copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('audit1274',P/'audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
R=a.REPORT;f=a.read(R/a.FAILURE);text=(R/f['log']).read_text();idles=[a.read(R/('native1274-'+t+'-idle.json')) for t in ('before-load','before-dispatch','after-close')]
checks=[]
def reject(name,call):
 try:call()
 except (ValueError,KeyError,AssertionError):checks.append({'name':name,'passed':True});return
 raise AssertionError('Accepted invalid '+name)
a.core(f,text,0,0,idles);checks.append({'name':'Actual retained core accepted','passed':True})
for key,value in [('result','Passed'),('sourceHash','other'),('fullSourceUnchanged',False),('errors',f['errors']+['real failure']),('normalResourcesPosesDamageVisibilityClocksOutcomeInjected',True),('enemyAIOrNativeDefensiveCombatDisabled',True),('countedPlayerWins',1),('normalMissionWinCertified',True),('deviceCertified',True),('performanceBudgetPassed',True),('playerReady',True)]:
 q=copy.deepcopy(f);q[key]=value;reject('Reject changed '+key,lambda q=q:a.core(q,text,0,0,idles))
reject('Nonzero actual wrapper',lambda:a.core(f,text,1,0,idles));reject('Nonzero actual native receipt',lambda:a.core(f,text,0,1,idles))
for marker in ('[ExistingEditorValidation] result=Passed executeMethod='+a.METHOD,'[S005PassivePressure1274] result=Passed scope=NormalNativePassiveEnemyPressure wins=0 playerReady=0'):
 reject('Missing substantive '+marker,lambda marker=marker:a.core(f,text.replace(marker,'Removed'),0,0,idles))
reject('Native failed marker retained',lambda:a.core(f,text+'\n[ExistingEditorValidation] result=Failed',0,0,idles))
q=copy.deepcopy(idles);q[-1]['data']['result']['result']='True|False|False|False|False|'+str(a.ROOT/'Assets');reject('Owned Play not idle',lambda:a.core(f,text,0,0,q))
q=copy.deepcopy(idles);q[-1]['data']['success']=False;reject('Native data success false',lambda:a.core(f,text,0,0,q))
obs=a.rows(R/f['observation']);trace=pathlib.Path(f['tracePath']);inputs={'observation':obs,'externalTouch':a.rows(R/'native1274-passive-pressure-touch.jsonl'),'inheritedTouch':a.rows(pathlib.Path(str(trace)+'.touch.jsonl'))};contacts=a.load('audit_skirmish_native_contacts');pressure=a.load('pressure-qualifier')
for stage,key,value in [('FreshNativeAttempt','sameBudget',False),('QaPassiveCoordination','manualActions',1),('NativePlayerPassivity','receipt',1),('NativeFrozenRenderedDefeat','rendered',False),('NativeFrozenRenderedDefeat','reason','TimeExpired'),('NativeMainMenuDestination','exactMainMenuOwner',False),('ClosedPassivePressure','passed',False)]:
 modified=list(obs);i=next(i for i,r in enumerate(modified) if r['stage']==stage);modified[i]={**modified[i],key:value};x={**inputs,'observation':modified};reject('Reject actual-row violation '+stage+'.'+key,lambda x=x:pressure.qualify(x,contacts.audit))
x={**inputs,'externalTouch':[dict(r) for r in inputs['externalTouch']]};x['externalTouch'][-1]['interventions']=1;reject('Physical intervention unqualified',lambda:pressure.qualify(x,contacts.audit))
proof=a.read(R/'native1274-offline-audited-passive-pressure-performance-proof.json');assert proof['editorPerformanceEvidence']==f['editorPerformanceEvidence'];assert not proof['deviceCertified'] and not proof['performanceBudgetPassed'] and not proof['fullX17MemoryQualified'];assert proof['pressureEvidence']['features']['nativeElapsedAtDefeat']<1080
with (P/'negative-control-results.json').open('x') as out:json.dump({'result':'Passed','cases':len(checks),'scope':'Offline raw-evidence integrity controls; no synthetic measurements or native certification','checks':checks},out,indent=2);out.write('\n')
print(json.dumps({'result':'Passed','cases':len(checks),'sharedFilesWritten':False}))
