from pathlib import Path
old=Path('Logs/SkirmishProduction/OpeningGroupCandidates/20261015-shared152-01/run-checked.ps1')
out=Path('Logs/SkirmishProduction/OpeningGroupCandidates/20261015-ui157-measured-01/run-checked.ps1')
text=old.read_text().replace('20261015-shared152-01','20261015-ui157-measured-01').replace('RunS005OpeningGroupViewCandidates','RunS005MeasuredOpeningGroupViewCandidates')
text=text.replace("        '[S005OpeningGroupCandidates]", "        '[S005MeasuredOpeningRuntimeGate] result=Passed errors=0 viewsCompleted=4 wrapperExitStillRequired=1',\n        '[S005MeasuredOpeningCandidates] result=CapturedUnqualified views=4 profileChanged=0 commandsIssued=0 selectionChanged=0 runtimeGateAtQuitRequired=1',\n        '[S005OpeningGroupCandidates]")
out.write_text(text)
print(out)
