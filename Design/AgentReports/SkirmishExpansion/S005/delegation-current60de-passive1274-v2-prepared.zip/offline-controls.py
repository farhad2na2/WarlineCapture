"""Offline historical replay and synthetic rejection controls only. No Unity."""
import ast,copy,hashlib,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent;R=pathlib.Path('/Users/farhad/Projects/WarlineCapture');D=R/'Design/AgentReports/SkirmishExpansion/S005'
def load(name,path=None):
 spec=importlib.util.spec_from_file_location(name,path or P/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
pressure=load('pressure-qualifier');escort=load('escort-qualifier');perf=load('performance-qualifier');contacts=load('contacts',R/'Tools/CI/audit_skirmish_native_contacts.py')
checks=[]
def check(name,fn,positive=False):
 try:fn();ok=True
 except Exception:ok=False
 if ok!=positive:raise AssertionError(name)
 checks.append(dict(name=name,passed=True,expectsSuccess=positive))
obs=[json.loads(x) for x in (D/'native1219-passive-pressure-observation.jsonl').read_text().splitlines() if x.strip()]
coord=next(r for r in obs if r['stage']=='QaPassiveCoordination');trace=pathlib.Path(coord['tracePath']);touch=[json.loads(x) for x in (D/'native1219-passive-pressure-touch.jsonl').read_text().splitlines() if x.strip()];native=[json.loads(x) for x in pathlib.Path(str(trace)+'.touch.jsonl').read_text().splitlines() if x.strip()]
historical=dict(observation=obs,externalTouch=touch,inheritedTouch=native)
check('Preserved old1219 scoped normal passive/Defeat/return parser PASS, not current qualification',lambda:pressure.qualify(historical,contacts.audit),True)
def rowchange(stage,**values):
 d=dict(historical);rr=list(obs);i=next(i for i,r in enumerate(rr) if r['stage']==stage);rr[i]=dict(rr[i],**values);d['observation']=rr;return d
for name,stage,values in [
 ('wrong authored seed','FreshNativeAttempt',dict(seed=1)),('fresh selection leak','FreshNativeAttempt',dict(selected=1)),('full vision injected','FreshNativeAttempt',dict(developmentFullVision=True)),('wrong baseline budget','FreshNativeAttempt',dict(sameBudget=False)),('readiness changed','FreshNativeAttempt',dict(readiness=3)),('manual command before passive','QaPassiveCoordination',dict(manualActions=1)),('foreign handoff attempt','QaPassiveCoordination',dict(attempt='old')),('clock speed changed','NativePressureRuntime',dict(timeScale=2)),('passive player order','NativePlayerPassivity',dict(manualAttackReceipts=1)),('wrong result outcome','NativeFrozenRenderedDefeat',dict(outcome='Victory')),('timeout substituted','NativeFrozenRenderedDefeat',dict(reason='TimeLimit')),('fake settled result','NativeFrozenRenderedDefeat',dict(saveAcknowledged=0)),('unrendered result','NativeFrozenRenderedDefeat',dict(rendered=False)),('wrong localized caption','NativeFrozenRenderedDefeat',dict(captionMatches=False)),('deadline escaped','NativeFrozenRenderedDefeat',dict(elapsed=1080)),('wrong result attempt','NativeFrozenRenderedDefeat',dict(resultSession='old')),('wrong destination','NativeMainMenuDestination',dict(shellRoute='QuickCustomSetup')),('wrong typed return','NativeMainMenuDestination',dict(exactMainMenuOwner=False)),('unfinished Leave Touch','NativePassivePressureSummary',dict(completed=0)),('unclosed Play','ClosedPassivePressure',dict(passed=False))]:
 d=rowchange(stage,**values);check(name,lambda d=d:pressure.qualify(d,contacts.audit))
check('empty early native pressure failure cannot crash or qualify',lambda:pressure.qualify(dict(observation=[],externalTouch=[],inheritedTouch=[]),contacts.audit))
# Exact old native assignment geometry read-only migration for negative control only.
oldAssignments=[]
for r in obs:
 if r['stage']=='NativeEnemyAssignment':
  r=dict(r);raw=json.loads(r['snapshot'])
  for small,big in [('lastProgressAt','LastProgressAt'),('lastProgressX','LastProgressX'),('lastProgressZ','LastProgressZ'),('lastIssuedAt','LastIssuedAt'),('retryAfter','RetryAfter')]:r[small]=raw[big]
 oldAssignments.append(r)
check('Actual old1219 same-goal Car progress reset is rejected, old pressure PASS unchanged',lambda:escort.qualify(oldAssignments))
a='synthetic';e=[dict(stage='FreshNativeAttempt',attempt=a),dict(stage='NativePaidReservation',attempt=a,faction=2,reservationId=101,materialsPaid=80,memberCount=4,deliveredMembers=4),dict(stage='NativeEnemyActor',attempt=a,faction=2,reservationId=101,initialActor=False,alive=True,bodyPresent=True,role='Rifle')]
for gid,role in [(9,'Car'),(10,'ApcArmored')]:
 for i in range(2):
  e.append(dict(stage='NativeEnemyActor',attempt=a,faction=2,reservationId=0,initialActor=True,alive=True,bodyPresent=True,role=role,groupId=gid,displacement=i*20))
  e.append(dict(stage='NativeEnemyAssignment',attempt=a,groupId=gid,groupOrder='Move',actionKey=gid,duty='Escort',orderAccepted=1,elapsed=5+i*5,x=0,z=0,lastProgressAt=5+i*5,lastProgressX=100-i*20,lastProgressZ=0,lastIssuedAt=5,retryAfter=0))
check('Synthetic real schema paid/escort net2m approach',lambda:escort.qualify(e),True)
for name,mut in [
 ('no naturally paid delivery',lambda d:d[1].update(deliveredMembers=0)),('no actual paid living actor',lambda d:d[2].update(alive=False)),('unpaid enemy receipt',lambda d:d[1].update(materialsPaid=0)),('foreign pressure authority',lambda d:d[2].update(attempt='old')),('old stagnant timer refresh',lambda d:d[6].update(lastProgressX=101)),('missing flat progress provenance',lambda d:d[6].pop('lastProgressX')),('assignment clock future',lambda d:d[6].update(lastProgressAt=100)),('missing actual Car body',lambda d:d[3].update(bodyPresent=False)),('unaccepted Escort',lambda d:[r.update(orderAccepted=0) for r in d if r['stage']=='NativeEnemyAssignment'])]:
 d=copy.deepcopy(e);mut(d);check(name,lambda d=d:escort.qualify(d))
frames=[]
for i in range(500):frames.append(dict(stage='Frame',attempt=a,frame=1000+i,frameGap=0,phase=1,editorWall=20+i/60,wallIntervalMs=0 if i==0 else 1000/60,frameIntervalMs=1000/60,elapsed=20+i/60,timeScale=1,active=True,postWarmup=i>=180,activeFrames=i+1,gcValid=True,gcNonempty=True,gcAllocatedBytes=100,simulationValid=True,simulationNonempty=True,simulationNanoseconds=1000000,focused=True))
scope='InstrumentedEditorRenderedCallbackIntervalsNotDeviceCertification';header=dict(stage='Header',attempt=a,scope=scope,deviceCertified=False,performanceBudgetPassed=False,unityVersion='Synthetic',operatingSystem='Synthetic',gpu='Synthetic',width=2400,height=1080,quality=0,msaa=0);closed=dict(stage='Closed',attempt=a,scope=scope,deviceCertified=False,performanceBudgetPassed=False,passed=True,overflow=False,samples=500);raw=[header]+frames+[closed];memory=[dict(stage='NativePressureRuntime',attempt=a,managedBytes=100,nativeAllocatedBytes=200,nativeReservedBytes=300,graphicsBytes=100)]*2
check('Synthetic bounded actual recorder schema measurement only',lambda:perf.qualify(raw,memory,a),True)
for name,mut in [
 ('performance foreign attempt',lambda d:d[1].update(attempt='old')),('performance forged device acceptance',lambda d:d[0].update(deviceCertified=True)),('performance forged budget acceptance',lambda d:d[0].update(performanceBudgetPassed=True)),('performance native overflow',lambda d:d[-1].update(overflow=True)),('performance unclosed',lambda d:d[-1].update(passed=False)),('performance false sample count',lambda d:d[-1].update(samples=0)),('concealed actual frame gap',lambda d:d[2].update(frame=1002)),('duplicated actual frame',lambda d:d[2].update(frame=1000)),('performance wallclock backward',lambda d:d[2].update(editorWall=1)),('performance warmup bypass',lambda d:d[1].update(postWarmup=True)),('performance fabricated warmup count',lambda d:d[1].update(activeFrames=999)),('performance active speedup',lambda d:d[400].update(timeScale=2)),('performance negative metric',lambda d:d[400].update(frameIntervalMs=-1)),('performance missing GC represented zero',lambda d:d[400].update(gcNonempty=False,gcAllocatedBytes=0)),('performance missing ECS represented zero',lambda d:d[400].update(simulationNonempty=False,simulationNanoseconds=0)),('performance unavailable GC cannot certify',lambda d:[r.update(gcValid=False,gcNonempty=False,gcAllocatedBytes=-1) for r in d if r['stage']=='Frame']),('performance unavailable ECS cannot certify',lambda d:[r.update(simulationValid=False,simulationNonempty=False,simulationNanoseconds=-1) for r in d if r['stage']=='Frame'])]:
 d=copy.deepcopy(raw);mut(d);check(name,lambda d=d:perf.qualify(d,memory,a))
check('performance empty early failure',lambda:perf.qualify([],memory,a));check('performance missing native memory',lambda:perf.qualify(raw,[],a))
for f in P.glob('*.py'):ast.parse(f.read_text())
with (P/'offline-controls.json').open('x') as f:json.dump(dict(scope='Offline historical/synthetic parser controls only; no current/native/device qualification',count=len(checks),checks=checks,historicalObservationSha256=hashlib.sha256((D/'native1219-passive-pressure-observation.jsonl').read_bytes()).hexdigest()),f,indent=2);f.write('\n')
print('PASS',len(checks),'offline controls; PythonAST PASS')
