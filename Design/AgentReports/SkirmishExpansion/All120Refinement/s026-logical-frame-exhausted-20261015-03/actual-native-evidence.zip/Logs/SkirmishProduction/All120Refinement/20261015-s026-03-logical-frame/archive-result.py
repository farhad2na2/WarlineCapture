import hashlib
import json
import zipfile
from pathlib import Path

root = Path.cwd()
run = root/'Logs/SkirmishProduction/All120Refinement/20261015-s026-03-logical-frame'
out = root/'Design/AgentReports/SkirmishExpansion/All120Refinement/s026-logical-frame-exhausted-20261015-03'
out.mkdir(parents=True, exist_ok=True)
assert (run/'checked-child-exit.txt').read_text().strip() == '0'
log = (run/'unity.log').read_text(encoding='utf-8-sig')
for marker in ['[UnityInvoke] ExitCode: 0', '[BoundedLogicalFrameControls] result=Passed controls=6 frameCandidates=4 physicalSourceChanged=0 sourceFitCertified=0', '[All120SimultaneousLogicalRefinement] result=Collected catalog=S026 sourceFitCertified=0']:
    assert marker in log
report = json.loads((run/'S026.json').read_text())
assert report['sourcePinsRecheckedAfterMeasurement'] and report['cleanupVerified']
measurement = report['missions'][0]['measurement']
assert measurement.get('strictThreeSizePlacementPass') is None
rows = [s for p in measurement['passes'] for s in p['sizes']]
assert len(rows) == 12 and not any(s.get('completeFacilities') for s in rows)
before = json.loads((run/'source-before.json').read_text())
after = json.loads((run/'source-after.json').read_text())
assert before['source_manifest'] == after['source_manifest']
assert (run/'source-after.json').read_bytes() == (run/'source-after-parallel.json').read_bytes()
paths = [p for p in sorted(run.rglob('*')) if p.is_file() and p.suffix.lower() not in {'.dll', '.pdb', '.pyc'}]
analysis = root/'Design/AgentReports/SkirmishExpansion/All120Refinement/S026_LOGICAL_FRAME03_INDEPENDENT_FAILURE_ANALYSIS_20261015.json'
assert hashlib.sha256(analysis.read_bytes()).hexdigest() == '9b12e5b9afb36d85ae6e217a16f427083782798a7061a38101cb785102f01c86'
paths.append(analysis)
archive = out/'actual-native-evidence.zip'
assert not archive.exists()
pins = []
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in paths:
        data = path.read_bytes()
        rel = path.relative_to(root).as_posix()
        z.writestr(rel, data)
        pins.append(dict(path=rel, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)))
receipt = dict(status='CollectedUnqualified_AllFourFramesExhausted', actualWrapperExit=0, nativeFrameControls=6, frames=4, sizeRows=12, completeFacilityRows=0, strictThreeSizePlacementPass=None, sourcePinsRechecked=True, nativeCleanupVerified=True, full41598SourceManifestUnchanged=True, expectedCompilationBoundary='Only Game.Editor and Game.Tests.Editor changed from835 to836; exact DLL changes retained in parity receipt', finalBuildSha256=after['build_sha256'], fullOldNewSnapshotCliByteParity=True, sourceCandidateSha256=after['candidate_sha256'], physicalSourceChanged=False, cameraAccepted=False, missionQualified=False, sequential113Admitted=False, archiveSha256=hashlib.sha256(archive.read_bytes()).hexdigest(), members=pins)
(out/'EVIDENCE.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(archive=str(archive.relative_to(root)), sha256=receipt['archiveSha256'], members=len(paths), sourceFiles=len(after['source_manifest']))))
