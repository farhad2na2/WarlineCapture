$ErrorActionPreference = 'Stop'
$env:WARLINE_NATIVE_CODEC_DIAGNOSTIC_OUTPUT = 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/native-codec-json-diagnostic-20261015-01.json'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:/Projects/WarlineCapture/Tools/CI/InvokeUnityExecuteMethodValidation.ps1' -UnityExe 'D:/Program Files/Unity/6000.5.2f1/Editor/Unity.exe' -ProjectPath 'D:/Projects/WarlineCapture' -ExecuteMethod 'Game.Tests.Editor.SkirmishNativeCodecJsonDiagnostic.Run' -LogFile 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/native-codec-json-diagnostic-20261015-01.log' -RequiredPassMarker '[SkirmishNativeCodecJsonDiagnostic] result=Collected' -TimeoutSeconds 600 -GuiLicensing
$taskExit = $LASTEXITCODE
Set-Content -LiteralPath 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/native-codec-json-diagnostic-20261015-01.wrapper-exit.txt' -Value $taskExit
exit $taskExit
