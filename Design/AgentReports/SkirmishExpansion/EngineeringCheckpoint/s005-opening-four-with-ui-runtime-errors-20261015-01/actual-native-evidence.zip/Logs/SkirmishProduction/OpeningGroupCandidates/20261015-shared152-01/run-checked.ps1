$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\OpeningGroupCandidates\20261015-shared152-01'
$env:WARLINE_S005_OPENING_GROUP_OUTPUT = Join-Path $runPath 'opening-group-candidates.jsonl'
$env:WARLINE_S005_EXIT_DIAGNOSTIC_OUTPUT = Join-Path $runPath 'startup-exit.jsonl'
$env:WARLINE_ARIA_BACKGROUND_VALIDATION = '1'
$env:WARLINE_SKIRMISH_STARTUP_ONLY = $null
$ownedExit = 1
try {
    if (-not (Test-Path -LiteralPath (Join-Path $runPath 'source-before.json') -PathType Leaf)) { throw 'Post-warmup source snapshot is required before capture' }
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    $arguments = @('-buildTarget', 'Android', '-executeMethod', 'Game.Editor.SkirmishS002AriaRunHarness.RunS005OpeningGroupViewCandidates')
    & (Join-Path $projectPath 'Tools\CI\InvokeUnity.ps1') -UnityExe $unityPath -ProjectPath $projectPath -LogFile (Join-Path $runPath 'unity.log') -NoProcessExit -GuiLicensing -TimeoutSeconds 900 -UnityArguments $arguments
    if ($LASTEXITCODE -ne 0) { throw 'Checked opening capture failed' }
    $logText = [IO.File]::ReadAllText((Join-Path $runPath 'unity.log'))
    $required = @(
        '[S005OpeningGroupCandidates] result=CapturedUnqualified views=4 profileChanged=0 commandsIssued=0 selectionChanged=0 wrapperExitStillRequired=1',
        '[S005StartupExitDiagnostic] result=ObservedStartupAndEditMode diagnosticOnly=1 wrapperExitStillRequired=1',
        '[SkirmishS003Startup] result=Passed reason=sharedStartupDiagnostic'
    )
    foreach ($marker in $required) {
        if (-not $logText.Contains($marker)) { throw "Missing required capture marker: $marker" }
    }
    if ($logText.Contains('result=Failed')) { throw 'Capture log contains failure marker' }
    $ownedExit = 0
} catch {
    [Console]::Error.WriteLine($_.ToString())
} finally {
    [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit)
}
exit $ownedExit
