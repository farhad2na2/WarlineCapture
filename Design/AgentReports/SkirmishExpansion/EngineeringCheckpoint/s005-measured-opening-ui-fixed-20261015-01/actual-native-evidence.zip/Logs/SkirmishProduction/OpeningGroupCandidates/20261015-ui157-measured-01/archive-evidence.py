from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();run=root/'Logs/SkirmishProduction/OpeningGroupCandidates/20261015-ui157-measured-01'
assert (run/'checked-child-exit.txt').read_text()=='0'
before=json.loads((run/'source-before.json').read_text());after=json.loads((run/'source-after.json').read_text());assert before==after
rows=[json.loads(x) for x in (run/'opening-group-candidates.jsonl').read_text().splitlines()]
gate=[r for r in rows if r['phase']=='MeasuredRuntimeGateAtQuit'];assert len(gate)==1 and gate[0]['runtimeErrors']==0
views=[r for r in rows if r['phase']=='CandidateEndOfFrame'];assert len(views)==4
images=list(run.glob('*.png'));assert len(images)==4
log=(run/'unity.log').read_text(errors='replace');assert '[S005MeasuredOpeningRuntimeGate] result=Passed errors=0 viewsCompleted=4 wrapperExitStillRequired=1' in log
evidence={'actualWrapperExit':0,'runtimeErrors':0,'sourceAndDllEndpointsEqual':True,'sourceFiles':len(before['source_manifest']),'candidateSha256':before['candidate_sha256'],'buildSha256':before['build_sha256'],'views':4,'ariaPlayVisibleInRootVisualReview':True,'cameraAccepted':False,'normalMissionReady':False,'lateNativeJobTempAllocationWarnings':'remaining Allocations on the JobTempAlloc' in log,'interpretation':'Measured QA poses and zero managed runtime errors through quitting; shipping camera, roof/HUD occlusion, aircraft, performance, native allocation warnings and normal mission acceptance remain separate gates'}
(run/'collection-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
target=root/'Design/AgentReports/SkirmishExpansion/EngineeringCheckpoint/s005-measured-opening-ui-fixed-20261015-01';target.mkdir(parents=True,exist_ok=True)
archive=target/'actual-native-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(root).as_posix())
receipt={'archive':archive.relative_to(root).as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'wrapperExit':0,'runtimeErrors':0,'sourceAndDllEndpointsEqual':True,**{k:v for k,v in evidence.items() if k not in ['actualWrapperExit','runtimeErrors','sourceAndDllEndpointsEqual']}}
(target/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
