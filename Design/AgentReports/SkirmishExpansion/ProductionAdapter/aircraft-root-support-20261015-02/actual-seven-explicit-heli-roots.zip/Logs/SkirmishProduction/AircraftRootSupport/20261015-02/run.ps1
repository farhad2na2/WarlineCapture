$ErrorActionPreference='Stop'
$root='D:\Projects\WarlineCapture'
$run='D:\Projects\WarlineCapture\Logs\SkirmishProduction\AircraftRootSupport\20261015-02'
foreach($candidate in @(Get-CimInstance Win32_Process -Filter "Name='Unity.exe'")){
 if($candidate.ExecutablePath -eq 'D:\Program Files\Unity Hub\resources\unity.exe' -and $candidate.CommandLine -match '\sserve\s*$'){continue}
 if([string]::IsNullOrWhiteSpace($candidate.CommandLine) -or $candidate.CommandLine.Replace('/','\').IndexOf($root,[StringComparison]::OrdinalIgnoreCase) -ge 0){throw 'Active or uninspectable Unity process may own project'}
}
if(@(Get-CimInstance Win32_Process -Filter "Name='Unity Hub.exe'").Count -eq 0){throw 'Hub must remain open/signed in'}
$raw=Join-Path $run 'aircraft-root-support.json'
$log=Join-Path $run 'unity.log'
if((Test-Path -LiteralPath $raw) -or (Test-Path -LiteralPath $log)){throw 'Fresh native outputs required'}
$versionText=[IO.File]::ReadAllText((Join-Path $root 'ProjectSettings\ProjectVersion.txt'))
if($versionText -notmatch '(?m)^m_EditorVersion:\s*(\S+)'){throw 'Recorded Editor version missing'}
& rtk proxy powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion $Matches[1] -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
if($LASTEXITCODE -ne 0){throw 'Editor resolution failed'}
$resolvedEditor=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
$env:WARLINE_AIRCRAFT_ROOT_SUPPORT_OUTPUT=$raw
$marker='[CanonicalAircraftRootSupportProvenance] result=Collected rolesExpected=7 templateOnly=1 defaultWorldPreserved=1 cameraAccepted=0'
$ownedExit=1
try{
 & rtk proxy powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $resolvedEditor -ProjectPath $root -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.CollectCanonicalAircraftRootProvenance' -LogFile $log -RequiredPassMarker $marker -GuiLicensing -TimeoutSeconds 900
 $ownedExit=$LASTEXITCODE
}finally{
 @{actualCheckedWrapperExit=$ownedExit;rawOutput=$raw;requiredMarker=$marker;motionCertified=$false;cameraAccepted=$false;missionReadiness=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $run 'wrapper-receipt.json')
}
exit $ownedExit
