Prepared offline only. No Unity execution, no source mutation, no current-source pass claim.

Source: 60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9
Run1263–1265: EN seeds104734/130368/155926. Run1266–1268: FA same seeds.
Root must first close current1262 and verify exclusive native ownership, then review/drycompile each unique observer. Actual drycompile JSON must be saved to the exact compile<ID>-normal-aria-reviewed-dry-run.json path. The runner checks outer/data/nested success, exact file/entry/target and error diagnostics before any native call.

Physical Mouse/keyboard/touch takeover is prohibited during qualification. The game retains normal physical takeover authority. Operator must leave the native lane untouched; any takeover, Manual abort, unexpected input, intervention or receipt violation fails. No device/input policy is modified. Failed1253 proof and actual raw Mouse event are preserved in preserved-lineage and original repository evidence.

Every fixture is an exact predecessor ID-only normalized clone. All native rendered setup/purpose/objective/clock/ARIAStop, normal flags, current-source CSV/census, frozen Victory and post-result AdjustSetup gates remain. Complete source/materials preflight/pre-dispatch/post equality, native idle, native/wrapper0, all recorded Menu/Runtime/Terminal contacts and verified command receipts remain mandatory. No gameplay resources/poses/clocks/damage/outcomes are injected.

120 offline checks =20 parser/clone controls repeated for six actual runners, not native mission tests. Native compile/run remains pending. Archived source/idle helpers preserve exact bytes for host recovery.

First root drycompile command (archive its exact output at the required proof path):
rtk proxy unity command run_script --file /private/tmp/s005-repaired-aria-matrix1263-1268/1263/S005NormalAria1263Observer.cs --entry S005NormalAria1263Observer.Run --dry_run true --timeout_ms 30000 --project-path /Users/farhad/Projects/WarlineCapture --format json

First root runner command, after review/dry/ownership release:
rtk proxy python3 /private/tmp/s005-repaired-aria-matrix1263-1268/1263/s005-run-normal-aria-1263.py final-1262-normal-manual-r2-recovery-pre-dispatch-source-manifest.json --dry-compile-proof /Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/compile1263-normal-aria-reviewed-dry-run.json --heavy-lane-owner main1263
