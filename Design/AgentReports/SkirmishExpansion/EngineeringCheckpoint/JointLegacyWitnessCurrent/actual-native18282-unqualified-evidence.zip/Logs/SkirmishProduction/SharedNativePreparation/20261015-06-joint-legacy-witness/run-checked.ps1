$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\SharedNativePreparation\20261015-06-joint-legacy-witness'
$ownedExit=1
$wrapperExit=$null
$failure=$null
$arguments=@('-buildTarget','Android','-warlineProfilerMarkers','-executeMethod','Game.Editor.SkirmishGroundSourceFitSurvey.RunJointLogicalRefinementLegacyAndOpeningWitness')
$required=@(
    '[JointLogicalPadControls] result=Passed controls=10 candidateWindow=9 maximumStrictPasses=2 sourceFitCertified=0',
    '[All120SimultaneousLogicalRefinement] result=Collected catalog=S026 sourceFitCertified=0',
    '[SkirmishLegacySourceResolutionControls] result=Passed explicitPresets=2 compatibilityFallbacks=1 ordinarySelections=3 nativeJobs=0',
    '[SkirmishLegacyProductionControls] result=Passed presets=3 ordinaryQueues=3 identityMutations=15 savedResultMutations=7 nativeJobs=0 samplingCoverageCredit=0',
    '[S005OpeningPlacementWitness] result=CapturedUnqualified views=4 geometryOnly=1 placementAccepted=0 occlusionAccepted=0 wrapperExitStillRequired=1',
    '[S005MeasuredOpeningCandidates] result=CapturedUnqualified views=4 profileChanged=0 commandsIssued=0 selectionChanged=0 runtimeGateAtQuitRequired=1',
    '[S005OpeningGroupCandidates] result=CapturedUnqualified views=4 profileChanged=0 commandsIssued=0 selectionChanged=0 wrapperExitStillRequired=1',
    '[S005MeasuredOpeningRuntimeGate] result=Passed errors=0 viewsCompleted=4 wrapperExitStillRequired=1',
    '[S005StartupExitDiagnostic] result=ObservedStartupAndEditMode diagnosticOnly=1 wrapperExitStillRequired=1',
    '[SkirmishS003Startup] result=Passed reason=sharedStartupDiagnostic',
    '[LateEcsRecorderCensus] result=CollectedDiagnosticOnly',
    '[UnityInvoke] ExitCode: 0'
)
function FileSha([string]$path) {
    $stream=[IO.File]::OpenRead($path);$algorithm=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}
    finally{$stream.Dispose();$algorithm.Dispose()}
}
try {
    Set-Location -LiteralPath $project
    if(-not (Test-Path -LiteralPath (Join-Path $run 'source-before.json') -PathType Leaf)){throw 'Fresh complete post-import/current-main source and DLL snapshot required'}
    foreach($name in @('unity.log','S026-joint.json','opening-placement-witness.jsonl','startup-exit.jsonl','checked-run-receipt.json')) {
        if(Test-Path -LiteralPath (Join-Path $run $name)){throw "Fresh exclusive output required: $name"}
    }
    $projectMatch=$project.Replace('/','\')
    foreach($editor in @(Get-CimInstance Win32_Process -Filter "Name = 'Unity.exe'")) {
        if([string]::IsNullOrWhiteSpace($editor.CommandLine) -or $editor.CommandLine.Replace('/','\').IndexOf($projectMatch,[StringComparison]::OrdinalIgnoreCase) -ge 0){throw 'An active or uninspectable Unity process may own this project; preserve it'}
    }
    if(@(Get-CimInstance Win32_Process -Filter "Name = 'Unity Hub.exe' OR Name = 'UnityHub.exe'").Count -eq 0){throw 'Keep Unity Hub open and signed in before checked GUI licensing'}
    $authorities=@(
        @('Tools\CI\SkirmishProductionDrafts\JointLogicalPadAllocation\manifest.json','57b074178528d02dc7750541edca827a2e7507a8445e2d9ba8bcf9464c8c103a'),
        @('Tools\CI\SkirmishProductionDrafts\LegacyFallbackWitnessDiagnostic\manifest.json','c3588da14e009f5ecc6e6f736d939252cc9ef6b7ce865cdd4eff5ee330f53285')
    )
    foreach($authority in $authorities) {
        $path=Join-Path $project $authority[0]
        if((FileSha $path) -cne $authority[1]){throw "Held authority drift: $path"}
        $map=[IO.File]::ReadAllText($path)|ConvertFrom-Json
        foreach($row in $map.files) {
            $installed=Join-Path $project $row.target
            if(-not (Test-Path -LiteralPath $installed -PathType Leaf) -or (FileSha $installed) -cne $row.sha256){throw "Reviewed source must be imported exactly before launch: $($row.target)"}
        }
    }
    $env:WARLINE_ALL120_REFINEMENT_CATALOG='S026'
    $env:WARLINE_ALL120_REFINEMENT_OUTPUT=Join-Path $run 'S026-joint.json'
    $env:WARLINE_ALL120_REFINEMENT_SOURCE_GROUP=$null
    $env:WARLINE_S005_OPENING_GROUP_OUTPUT=Join-Path $run 'opening-placement-witness.jsonl'
    $env:WARLINE_S005_EXIT_DIAGNOSTIC_OUTPUT=Join-Path $run 'startup-exit.jsonl'
    $env:WARLINE_ARIA_BACKGROUND_VALIDATION='1'
    $env:WARLINE_SKIRMISH_STARTUP_ONLY=$null
    $versionText=[IO.File]::ReadAllText((Join-Path $project 'ProjectSettings\ProjectVersion.txt'))
    if($versionText -notmatch '(?m)^m_EditorVersion:\s*(\S+)\s*$'){throw 'Recorded Editor version is required'}
    $version=$Matches[1]
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion $version -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked recorded-version Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    $required|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $run 'required-markers.json') -Encoding UTF8
    & (Join-Path $project 'Tools\CI\InvokeUnity.ps1') -UnityExe $unity -ProjectPath $project -LogFile (Join-Path $run 'unity.log') -NoProcessExit -GuiLicensing -TimeoutSeconds 1800 -UnityArguments $arguments
    $wrapperExit=$LASTEXITCODE
    if($wrapperExit -ne 0){throw "Actual checked wrapper failed: $wrapperExit"}
    $log=[IO.File]::ReadAllText((Join-Path $run 'unity.log'))
    foreach($marker in $required){if(-not $log.Contains($marker)){throw "Missing required marker: $marker"}}
    if($log.Contains('result=Failed')){throw 'Native log contains a failed validation marker'}
    $joint=[IO.File]::ReadAllText($env:WARLINE_ALL120_REFINEMENT_OUTPUT)|ConvertFrom-Json
    if($joint.result -cne 'CollectedUnqualified' -or $joint.catalogId -cne 'S026' -or $joint.cleanupVerified -ne $true){throw 'Actual collector result and owned cleanup receipt required; fit remains unqualified'}
    $facts=@(Get-Content -LiteralPath $env:WARLINE_S005_OPENING_GROUP_OUTPUT|Where-Object {-not [string]::IsNullOrWhiteSpace($_)}|ForEach-Object {$_|ConvertFrom-Json})
    $captured=@($facts|Where-Object {$_.phase -ceq 'CandidateEndOfFrame'})
    if($captured.Count -ne 4 -or @($captured.candidate|Sort-Object -Unique).Count -ne 4 -or @($captured.attempt|Sort-Object -Unique).Count -ne 1 -or [string]::IsNullOrWhiteSpace($captured[0].attempt)){throw 'Four distinct actual candidate EOF receipts in one native attempt required'}
    foreach($view in $captured) {
        if(-not (Test-Path -LiteralPath $view.png -PathType Leaf) -or (FileSha $view.png) -cne $view.pngSha256){throw 'Actual captured PNG bytes must match their native receipt'}
    }
    $quit=@($facts|Where-Object {$_.phase -ceq 'MeasuredRuntimeGateAtQuit'})
    if($quit.Count -ne 1 -or $quit[0].runtimeErrors -ne 0 -or $quit[0].allErrorsCounted -ne $true){throw 'Actual final measured runtime error gate required'}
    $censusPath=$env:WARLINE_S005_OPENING_GROUP_OUTPUT+'.ecs-recorders.jsonl'
    $census=@(Get-Content -LiteralPath $censusPath|Where-Object {-not [string]::IsNullOrWhiteSpace($_)}|ForEach-Object {$_|ConvertFrom-Json})
    $closed=@($census|Where-Object {$_.kind -ceq 'Closed'})
    if($closed.Count -ne 1 -or $closed[0].errors -ne 0 -or $closed[0].remainingOwnedRecorders -ne 0 -or @($closed[0].disposeErrors).Count -ne 0 -or $closed[0].attempt -cne $captured[0].attempt){throw 'Exact native attempt Closed census with zero errors and zero remaining owned recorders required'}
    $ownedExit=0
}catch{$failure=$_.ToString();[Console]::Error.WriteLine($failure)}
finally {
    [IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)
    [ordered]@{checkedExitCode=$ownedExit;actualWrapperExitCode=$wrapperExit;failure=$failure;unityArguments=$arguments;guiLicensing=$true;timeoutSeconds=1800;quitArgument=$false;sourceFitCertified=$false;cameraAccepted=$false;missionReadiness=0;queueSuccessEnabled=$false;fullAfterSnapshotAndCompiledCandidateStillRequired=$true}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $run 'checked-run-receipt.json') -Encoding UTF8
}
exit $ownedExit
