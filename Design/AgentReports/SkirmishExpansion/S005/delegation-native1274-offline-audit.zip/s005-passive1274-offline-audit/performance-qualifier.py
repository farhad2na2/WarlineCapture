"""Inclusive instrumented Editor samples only; device/performance budgets stay pending."""
import math
def distribution(v):
 if not v:return dict(available=False,count=0,p95=None,p99=None,max=None,average=None)
 a=sorted(v);n=len(a);return dict(available=True,count=n,average=sum(a)/n,p95=a[math.ceil(n*.95)-1],p99=a[math.ceil(n*.99)-1],max=a[-1],percentileMethod='NearestRank')
def qualify(rows,obs,attempt):
 if not rows or rows[0]['stage']!='Header' or rows[-1]['stage']!='Closed' or any(r['stage']!='Frame' for r in rows[1:-1]):raise ValueError('Actual ordered Header/Frame/Closed performance stream required')
 header,closed=rows[0],rows[-1];frames=rows[1:-1]
 scope='InstrumentedEditorRenderedCallbackIntervalsNotDeviceCertification'
 if header['scope']!=scope or closed['scope']!=scope or any(r['attempt']!=attempt for r in rows):raise ValueError('Exact performance scope and actual attempt required')
 if header['deviceCertified'] or header['performanceBudgetPassed'] or closed['deviceCertified'] or closed['performanceBudgetPassed']:raise ValueError('Unsupported budget/device claim')
 if not closed['passed'] or closed['overflow'] or closed['samples']!=len(frames) or not frames:raise ValueError('Actual bounded performance native closure failed')
 previous=None;activeCount=0
 for r in frames:
  if r['active']:activeCount+=1
  if r['activeFrames']!=activeCount:raise ValueError('Observed active-frame warmup count altered')
  if r['frameGap']<0 or r['phase'] not in (1,2,3):raise ValueError('Malformed native rendered frame phase/gap')
  for k in ('editorWall','wallIntervalMs','frameIntervalMs','elapsed','timeScale'):
   if not isinstance(r[k],(int,float)) or not math.isfinite(r[k]) or r[k]<0:raise ValueError('Nonfinite/negative native measurement '+k)
  if previous is not None and (r['frame']<=previous['frame'] or r['editorWall']<=previous['editorWall'] or r['frameGap']!=r['frame']-previous['frame']-1 or r['elapsed']<previous['elapsed']):raise ValueError('Duplicate/backward frame/time or concealed gap')
  if previous is None and r['frameGap']!=0:raise ValueError('First actual frame gap must zero')
  if r['postWarmup'] and (r['activeFrames']<=180 or r['elapsed']<15):raise ValueError('Reviewed180-frame/15-second warmup changed')
  if not r['gcNonempty'] and r['gcAllocatedBytes']!=-1 or r['gcNonempty'] and (not r['gcValid'] or r['gcAllocatedBytes']<0):raise ValueError('GC unavailable sample concealed or malformed')
  if not r['simulationNonempty'] and r['simulationNanoseconds']!=-1 or r['simulationNonempty'] and (not r['simulationValid'] or r['simulationNanoseconds']<0):raise ValueError('ECS unavailable sample concealed or malformed')
  previous=r
 measured=[r for r in frames if r['phase']==1 and r['active'] and r['postWarmup']]
 if len(measured)<180 or any(abs(r['timeScale']-1)>.0001 or r['frameIntervalMs']<=0 for r in measured):raise ValueError('At least180 genuine post-warmup normal-clock active measurements required')
 gc=[r['gcAllocatedBytes'] for r in measured if r['gcNonempty']];ecs=[r['simulationNanoseconds']/1e6 for r in measured if r['simulationNonempty']]
 if len(gc)<180 or len(ecs)<180:raise ValueError('Actual GC/ECS counters must each supply180 measured values; unavailable is pending')
 memory=[r for r in obs if r['stage']=='NativePressureRuntime']
 if len(memory)<2 or any(r['attempt']!=attempt or any(r[k]<0 for k in ('managedBytes','nativeAllocatedBytes','nativeReservedBytes','graphicsBytes')) for r in memory) or max(r['nativeAllocatedBytes'] for r in memory)<=0:raise ValueError('Actual same-attempt native memory samples missing')
 return dict(measurementQualified=True,scope=scope,deviceCertified=False,androidCertified=False,performanceBudgetPassed=False,renderGpuTimeMeasured=False,expectedScale='Actual passive Standard/Regular; no injected population saturation',sampleCount=len(frames),measuredActiveFrames=len(measured),retainedFrameGaps=sum(r['frameGap'] for r in frames),missingFramesNeverImputed=True,measuredFrameIntervalMs=distribution([r['frameIntervalMs'] for r in measured]),measuredWallIntervalMs=distribution([r['wallIntervalMs'] for r in measured]),nativeFrameGcAllocatedBytesInclusive=distribution(gc),ecsSimulationMilliseconds=distribution(ecs),unavailableGcMeasuredFrames=len(measured)-len(gc),unavailableEcsMeasuredFrames=len(measured)-len(ecs),memoryPeaks={k:max(r[k] for r in memory) for k in ('managedBytes','nativeAllocatedBytes','nativeReservedBytes','graphicsBytes')},hardware={k:header[k] for k in ('unityVersion','operatingSystem','gpu','width','height','quality','msaa')},recorderAlignment='Last completed profiler sample; observation frame retained; no exact event-frame/GPU attribution',observerOverheadIncluded=True)
