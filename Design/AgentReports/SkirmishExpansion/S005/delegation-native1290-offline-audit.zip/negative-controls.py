"""Negative controls of offline terminal exception only; not native gameplay evidence."""
import ast,copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('offline1290',P/'audit.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
r=a.REPORT;original=a.read(r/'native1290-normal-stop-manual-failure.json');trace=pathlib.Path(original['trace'])
fog=a.rows(r/'native1290-manual-fog-fallback.jsonl');commands=a.rows(pathlib.Path(str(trace)+'.commands.jsonl'));touch=a.rows(pathlib.Path(str(trace)+'.touch.jsonl'));diagnostic=a.rows(r/'native1290-manual-driver-state.jsonl')
obs=[x for x in a.rows(r/'native1290-normal-stop-manual-observation.jsonl') if x['stage']=='NativeRenderedResultText' and x['renderedVictoryWitnessed']]
case={'fog':fog,'commands':commands,'touch':touch,'diagnostic':diagnostic,'observations':obs[:1],'terminal':a.rows(trace)[-1],'attempt':original['actualResolvedSetup']['attempt']}
checks=[]
def check(name,mutation=None,positive=False):
 d=copy.deepcopy(case)
 if mutation:mutation(d)
 try:a.audit_terminal_exception(**d);passed=True
 except (ValueError,KeyError,TypeError):passed=False
 if passed!=positive:raise AssertionError(name)
 checks.append({'name':name,'passed':True,'expectedAccept':positive})
def row(d,key,stage):return next(x for x in d[key] if x['stage']==stage and x.get('round',2)==2)
check('Actual immutable observed terminal cleanup accepted',positive=True)
for key,value in [('phase','Playing'),('outcome','Defeat'),('clockPaused',0),('simulationActive',1),('enemyBaseHp',1),('elapsed',0)]:
 check('Reject terminal/'+key,lambda d,k=key,v=value:d['terminal'].update({k:v}))
for stage,key,val in [('Failure','reason','Other failure'),('Failure','round',1),('LeaseStarted','attempt','foreign'),('LeaseStarted','sameDriver',False),('LeaseStarted','markerVisible',True),('LeaseRestored','originalDue',0),('LeaseRestored','sameDriver',False),('LeaseRestored','restoredExact',False),('Actor','alive',False),('Actor','selected',False),('Actor','speed',0),('Actor','receipt',1)]:
 check('Reject interrupted '+stage+'/'+key,lambda d,s=stage,k=key,v=val:row(d,'fog',s).update({k:v}))
check('Reject added terrain touch before terminal',lambda d:d['fog'].insert(-2,dict(row(d,'fog','Actor'),stage='GroundTouch')))
check('Reject any post-lease native gameplay acceptance',lambda d:d['commands'].append(dict(frame=3642,operation='Move',receipt=99,verified=True)))
check('Reject missing actual contact Ended',lambda d:d.update(touch=[x for x in d['touch'] if not(x['phase']=='Manual' and x['dispatched']==44 and x['kind']=='Ended')]))
for key,val in [('matchFinished',False),('interventions',1),('acceptedCommands',14),('completed',43),('frame',3642)]:
 check('Reject final actual contact/'+key,lambda d,k=key,v=val:next(x for x in d['touch'] if x['phase']=='Manual' and x['dispatched']==44 and x['kind']=='Ended').update({k:v}))
check('Reject missing frozen native rendered result',lambda d:d.update(observations=[]))
check('Reject foreign rendered result',lambda d:d['observations'][0].update(attempt='foreign'))
check('Reject rendered Defeat substitution',lambda d:d['observations'][0].update(outcome='Defeat'))
check('Reject missing actual paused boundary',lambda d:next(x for x in d['diagnostic'] if x['stage']=='ManualDriverState' and x['frame']==3642).update(paused=False))
check('Reject missing completed native driver drain',lambda d:d.update(diagnostic=[x for x in d['diagnostic'] if not(x['stage']=='ManualDriverState' and x['frame']>=3644 and not x['driverBusy'])]))
for f in P.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
with (P/'negative-controls-results.json').open('x') as f:json.dump({'result':'Passed','cases':len(checks),'scope':'Mutated copied actual schemas for offline rejection controls only; no fabricated native proof or Unity','checks':checks},f,indent=2);f.write('\n')
print(json.dumps({'result':'Passed','cases':len(checks),'nativeReplayPerformed':False}))
