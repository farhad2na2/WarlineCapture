"""Pure readiness compare-and-set controls; never writes authoritative documents."""
import ast,copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent;spec=importlib.util.spec_from_file_location('update_readiness',P/'update-readiness.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
proposal=m.read(P/'keyed-update.json')
base={'sourceHash':proposal['sourceHash'],'activeRun':None,'activeLog':None,'activeScope':None,'activePreManifest':None,'unknownPreserved':{'nested':['history','sentinel']},**proposal['guardLatestSnapshot']}
for key,c in proposal['changes'].items():
 if c['expectedPresent']:base[key]=copy.deepcopy(c['expected'])
checks=[]
def check(name,current,payload,expect):
 try:out=m.reconcile(current,payload);ok=True
 except ValueError:ok=False
 if ok!=expect:raise AssertionError(name)
 if ok:
  assert out['unknownPreserved']==current['unknownPreserved'] and out['activeRun'] is None
  assert not out['playerReady'] and not out['technicallyReady']
 checks.append({'name':name,'passed':True,'expectedAccept':expect})
check('Exact reviewed idle keys accepted with unknown/history preserved',base,proposal,True)
for key,value in [('activeRun','nativeFuture'),('sourceHash','different'),('playerReady',True),('technicallyReady',True)]:
 d=copy.deepcopy(base);d[key]=value;check('Reject '+key,d,proposal,False)
d=copy.deepcopy(base);d['latestUnincorporatedCase']='new-proof';check('New closure requires refreshed proposal',d,proposal,False)
for key,c in proposal['changes'].items():
 d=copy.deepcopy(base)
 if c['expectedPresent']:d[key]={'unexpected':'new concurrent value'}
 else:d[key]='newly present'
 check('Reject concurrent keyed change '+key,d,proposal,False)
for key in ['activeRun','sourceHash','physicalSource','shippingRuntimeCommit']:
 p=copy.deepcopy(proposal);p['changes'][key]={'expectedPresent':key in base,'expected':base.get(key),'proposed':'unauthorized'};check('Reject forbidden identity/ownership '+key,base,p,False)
p=copy.deepcopy(proposal);p['changes']['playerReady']['proposed']=True;check('Reject false player-ready promotion',base,p,False)
before=(P/'CURRENT_ACCEPTANCE.before.md').read_text();after=(P/'CURRENT_ACCEPTANCE.proposed.md').read_text();boundary='## Current S005 native validation (source 746a)'
assert before.split(boundary,1)[1]==after.split(boundary,1)[1]
assert 'Not yet technically ready or player-ready' in after and 'native1290-offline-audited-stop-manual-proof.json' in after
for f in P.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
with (P/'offline-controls-results.json').open('x') as f:json.dump({'result':'Passed','cases':len(checks),'historicalMarkdownSuffixByteIdentical':True,'scope':'Pure proposal safety controls; no shared-file writes/Unity/native certification','checks':checks},f,indent=2);f.write('\n')
print(json.dumps({'result':'Passed','cases':len(checks),'sharedFilesWritten':False,'historicalMarkdownSuffixByteIdentical':True}))
