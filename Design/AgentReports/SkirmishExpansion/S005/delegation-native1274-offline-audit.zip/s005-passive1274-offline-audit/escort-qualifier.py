"""Read-only current native paid-production/escort evidence; no gameplay APIs."""
import math
def qualify(obs):
 fresh=[r for r in obs if r['stage']=='FreshNativeAttempt']
 if len(fresh)!=1:raise ValueError('One actual fresh attempt required')
 attempt=fresh[0]['attempt'];assignments=[r for r in obs if r['stage']=='NativeEnemyAssignment'];actors=[r for r in obs if r['stage']=='NativeEnemyActor'];receipts=[r for r in obs if r['stage']=='NativePaidReservation']
 if not assignments or not actors or any(r['attempt']!=attempt for r in assignments+actors+receipts):raise ValueError('Same-attempt native observation coverage required')
 paid=[r for r in receipts if r['faction']==2 and r['materialsPaid']>0 and r['memberCount']>0 and 0<r['deliveredMembers']<=r['memberCount']]
 if not paid:raise ValueError('Actual naturally paid delivered enemy reservation required')
 if not any(r['faction']==2 and r['reservationId'] in {p['reservationId'] for p in paid} and not r['initialActor'] and r['alive'] and r['bodyPresent'] for r in actors):raise ValueError('Actual living delivered paid enemy actor required')
 # Flat primitive fields are mandatory. No JsonUtility nested-default assumption.
 prior={};checks=0;resetChecks=0
 for a in assignments:
  for k in ('elapsed','x','z','lastProgressAt','lastProgressX','lastProgressZ','lastIssuedAt','retryAfter'):
   if not isinstance(a[k],(int,float)) or not math.isfinite(a[k]):raise ValueError('Finite factual assignment '+k+' required')
  if a['lastProgressAt']<0 or a['lastProgressAt']>a['elapsed']+.001 or a['lastIssuedAt']>a['elapsed']+.001:raise ValueError('Assignment factual clock exceeds actual objective time')
  old=prior.get(a['groupId']);prior[a['groupId']]=a
  if old is None:continue
  if a['elapsed']<old['elapsed']:raise ValueError('Native assignment time regressed')
  if old['groupOrder']!='Move' or a['groupOrder']!='Move' or old['actionKey']!=a['actionKey'] or math.hypot(old['x']-a['x'],old['z']-a['z'])>.001:continue
  checks+=1
  if a['lastProgressAt']<=old['lastProgressAt']+.001:continue
  before=math.hypot(old['lastProgressX']-a['x'],old['lastProgressZ']-a['z']);after=math.hypot(a['lastProgressX']-a['x'],a['lastProgressZ']-a['z']);resetChecks+=1
  if before-after<1.999:raise ValueError('Same actual Move goal/action refreshed progress without native2m net approach: group'+str(a['groupId']))
 candidates=[]
 for role in ('Car','ApcArmored'):
  owned=[r for r in actors if r['role']==role and r['initialActor'] and r['faction']==2 and r['alive'] and r['bodyPresent']]
  if len(owned)<2:raise ValueError('Actual living original escort actor trajectory missing '+role)
  ids={r['groupId'] for r in owned};escorts=[r for r in assignments if r['groupId'] in ids and r['duty']=='Escort' and r['groupOrder']=='Move' and r['orderAccepted']==1]
  if not escorts:raise ValueError('Actual accepted original escort Move assignment missing '+role)
  if not any(r['displacement']>=2 for r in owned):raise ValueError('Actual original escort body movement missing '+role)
  candidates.append(dict(role=role,groups=sorted(ids),samples=len(owned),maximumDisplacement=max(r['displacement'] for r in owned),acceptedEscortRows=len(escorts)))
 if checks==0:raise ValueError('No repeated actual unchanged-goal observation')
 return dict(scope='Same-attempt natural paid enemy delivery and original Car/APC Escort Move/body trajectories; sampled native net-goal progress reset guard',paidDeliveredReservations=sorted({r['reservationId'] for r in paid}),escortActors=candidates,sameGoalChecks=checks,netGoalResetChecks=resetChecks,allEnemyPlanStepsCertified=False,combatEffectAttributed=False)
