# External Campaign M3 successor1286

Source60de; native pending. Root owns all Editor calls. Observer repair only; no gameplay/source writes. Frozen terminal provenance is explicitly separate from current runtime/menu state. Menu proof requires real current Campaign route and bound rendered typed title. Both actual resolved convoys remain required. FA default does not certify EN.

Dry compile with the existing connected Unity CLI command run_script --file /private/tmp/campaign-m3-current1286/CampaignSelectionJourney1286.cs --entry CampaignSelectionJourney1286.Run --dry_run true --timeout_ms 30000 --project-path /Users/farhad/Projects/WarlineCapture --format json. Archive exact outer/data/nested proof as compile1286-campaign-m3-reviewed-dry-run.json. Dry compile is not Play or execution.

Root-owned execution after reviewed dry compile:

rtk proxy python3 /private/tmp/campaign-m3-current1286/run_campaign_m3_1286.py final-1258-ground-carrier-pre-source-manifest.json --dry-compile-proof /Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/compile1286-campaign-m3-reviewed-dry-run.json --heavy-lane-owner main1286 --scope fa-IR

All public launch/contact/result gates, full source equality, native idle and wrapper/native0 closure remain strict. Original1281 loaded bytes/failure untouched. 43 offline synthetic controls are parser checks only.
