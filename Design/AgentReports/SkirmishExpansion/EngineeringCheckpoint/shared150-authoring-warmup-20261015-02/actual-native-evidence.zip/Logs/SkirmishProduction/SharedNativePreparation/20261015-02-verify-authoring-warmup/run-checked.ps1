$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\SharedNativePreparation\20261015-02-verify-authoring-warmup'
$markerPath = Join-Path $projectPath 'Design\AgentReports\SkirmishExpansion\S005\aircraft-framing-inventory\SHARED150_NATIVE_MARKERS_20261015.json'
$markers = Get-Content -LiteralPath $markerPath -Raw | ConvertFrom-Json
$resumeMarkers = Get-Content -LiteralPath (Join-Path $projectPath 'Tools\CI\SkirmishProductionDrafts\InstalledAircraftSharedPreparation\NATIVE_MARKERS.json') -Raw | ConvertFrom-Json
$inputPath = Join-Path $runPath 'provenance-input.json'
$finalMarker = '[InstalledSharedAndAuthoringWarmup] result=Passed sharedControls=150 sourceGroupsStarted=0 warmupScenes=2 snapshotAfterWrapperExit=1 missionAcceptance=Pending'
$ownedExit = 1
try {
    $inputFacts = Get-Content -LiteralPath $inputPath -Raw | ConvertFrom-Json
    $hashStream = [IO.File]::OpenRead($inputFacts.report)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { $actualSha = [BitConverter]::ToString($hasher.ComputeHash($hashStream)).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose(); $hashStream.Dispose() }
    if ($actualSha -ne $inputFacts.sha256) { throw 'Fresh provenance report hash mismatch' }
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_REPORT = $inputFacts.report
    $env:WARLINE_AIRCRAFT_ROOT_PROVENANCE_SHA256 = $actualSha
    $env:WARLINE_S005_SCENE_WARMUP_OUTPUT = Join-Path $runPath 'scene-warmup.json'
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    & (Join-Path $projectPath 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unityPath -ProjectPath $projectPath -ExecuteMethod 'Game.Tests.Editor.SkirmishInstalledAircraftSharedPreparation.RunVerifySharedAndAuthoringWarmup' -LogFile (Join-Path $runPath 'unity.log') -RequiredPassMarker $finalMarker -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if ($LASTEXITCODE -ne 0) { throw 'Checked installed shared/authoring/warmup validation failed' }
    $logText = [IO.File]::ReadAllText((Join-Path $runPath 'unity.log'))
    foreach ($marker in $markers.required_independent_markers) {
        if ($marker.StartsWith('[SkirmishAircraftCameraTerminalPreparation]') -or $marker.StartsWith('[MeasuredCanonicalAircraftGeometry]')) { continue }
        if (-not $logText.Contains($marker)) { throw "Missing independent marker: $marker" }
    }
    $extraMarkers = @(
        '[InstalledAircraftMetadataVerification] result=Passed transportSources=3 transportDraws=57 additionalRoles=6 rotorRoles=4 freshNativeProvenance=1 metadataGenerated=0 cameraAcceptance=Pending',
        '[SkirmishInstalledAircraftSharedPreparation] result=Passed sharedControls=150 installedMetadataVerified=1 metadataGenerated=0 geometryChanged=0 cameraAndMissionAcceptance=Pending',
        '[All120RefinementAuthoring] result=Passed additionalGeneric=83 protectedReadOnly=7 canonicalSizeVectorsInspected=249 exactNonCeBudgetVectors=189 ceNativeBayBudgetPending=60 negativeControls=83 streamingWorldsCreated=0 sourceFitCertified=0 cameraAccepted=0',
        '[All120AuthoringSceneWarmup] result=Passed sourceGroupsStarted=0 warmupScenes=2 snapshotAfterWrapperExit=1 missionCertified=0',
        '[S005SceneArtifactWarmup] result=Passed scenes=2 keySource=NativeEditorSceneSystem defaultWorldPreserved=1 playStarted=0 missionCertified=0 snapshotAfterWrapperExit=1',
        $finalMarker
    )
    foreach ($marker in $extraMarkers) {
        if (-not $logText.Contains($marker)) { throw "Missing installed/authoring/warmup marker: $marker" }
    }
    foreach ($marker in $resumeMarkers.required_combined_markers) {
        if (-not $logText.Contains($marker)) { throw "Missing combined native marker: $marker" }
    }
    if ($logText.Contains('suiteFailed=')) { throw 'Independent suite failure found' }
    $ownedExit = 0
    Write-Output '[InstalledSharedRootChecks] result=Passed sharedControls=150 authoringControls=83 warmupScenes=2 snapshotRequiredAfterThisExit=1'
} catch {
    [Console]::Error.WriteLine($_.ToString())
} finally {
    [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit)
}
exit $ownedExit
