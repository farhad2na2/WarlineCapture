using Game.UI.Contracts;
using Game.UI.Shell.Contracts.Ecs;
using Unity.Burst;
using Unity.Entities;
namespace Game.UI.Shell.Ecs
{
    /// <summary>Base Assault skill. Inputs contain only currently presented player information.</summary>
    [BurstCompile, UpdateInGroup(typeof(PresentationSystemGroup)), UpdateBefore(typeof(AriaPlayDecisionSystem))]
    public partial struct AriaSkirmishPlanSystem : ISystem
    {
        [BurstCompile]
        public void OnUpdate(ref SystemState state)
        {
            foreach (var (view, plan, touch, output) in SystemAPI.Query<RefRO<AriaSkirmishObservationComponent>, RefRW<AriaSkirmishPlanComponent>, RefRW<AriaPlaySessionComponent>, RefRW<AriaPlayObservationComponent>>())
                if (view.ValueRO.Value.Active) Step(view.ValueRO.Value, ref plan.ValueRW, ref touch.ValueRW, ref output.ValueRW);
        }
        public static void Step(in AriaSkirmishObservation view, ref AriaSkirmishPlanComponent plan,
            ref AriaPlaySessionComponent touch, ref AriaPlayObservationComponent output)
        {
            output = new AriaPlayObservationComponent { Kind = view.Finished ? AriaPlayObservationKind.Finished : AriaPlayObservationKind.Waiting, Time = view.Time, Frame = view.Frame, GoalId = 10000 + plan.Cycle * 10 + plan.Slot };
            if (view.PublicObjective.Applicable)
            {
                if (StepPublicBoarding(view,ref plan,ref touch,ref output)) return;
                if (StepOffensiveAir(view,ref plan,ref touch,ref output)) return;
                if (StepPublicScan(view,ref plan,ref touch,ref output)) return;
                if (StepPublicObjectiveSupport(view,ref plan,ref touch,ref output)) return;
                plan.Intent = view.PublicObjective.Intent;
                StepPublicObjective(view, view.PublicObjective, ref plan.ObjectiveTouch, ref touch, ref output);
                if (plan.ObjectiveTouch.Stage == 4) plan.Intent = AriaSkirmishIntent.ObserveObjective;
                return;
            }
            if (view.ExpandedSession)
            {
                // Blocked remains stopped until the player explicitly retries ARIA.
                // Repeated failed taps must not erase the watchdog's evidence.
                // Manual is idle / pre-consent: still publish the presented control so
                // the cyan hand and DecisionSystem can see TargetId. Starting waits
                // for the touch driver. Touching is held inside StepExpanded.
                if (!view.Finished && touch.Phase is AriaPlayPhase.Blocked or AriaPlayPhase.Starting)
                    return;
                if (view.ExpandedRosterRevision != 0 && touch.Phase != AriaPlayPhase.Touching)
                {
                    if (plan.SweepRosterRevision != 0 && plan.SweepRosterRevision != view.ExpandedRosterRevision)
                    {
                        plan.PagedToAssault = 0;
                        plan.AssaultSelecting = 0;
                        plan.AssaultIssued = 0;
                        plan.StructureOrdered = 0;
                        plan.AssaultPageSeen = 0;
                        plan.PagesOrdered = 0;
                    }
                    plan.SweepRosterRevision = view.ExpandedRosterRevision;
                }
                StepExpandedBaseAssault(view, ref plan, ref touch, ref output);
                return;
            }
            if (view.Finished || touch.Phase is AriaPlayPhase.Manual or AriaPlayPhase.Blocked or AriaPlayPhase.Starting) return;
            if (plan.OpeningUntil == 0) { plan.OpeningUntil = view.Time + 180; plan.OpeningSquads = view.AvailableSquads; }
            // Assemble a force and finish the nearby defensive fight before advancing.
            // A deadline prevents waiting forever when production is unaffordable.
            bool awaitingAssault = plan.AssaultStarted == 0;
            // After the opening window, depart with a viable force even if a contact is still nearby.
            // Dense maps otherwise keep ThreatNearForce true until OpeningUntil+60 while the clock burns.
            if (!view.ThreatNearForce && view.Infantry >= 24 ||
                view.Infantry >= 16 && view.Time >= plan.OpeningUntil ||
                view.Time >= plan.OpeningUntil + 60) plan.AssaultStarted = 1;
            if (plan.LastProgressAt == 0 || plan.EnemyHealth != view.EnemyHealth || plan.PlayerHealth != view.PlayerHealth || plan.ForceHealth != view.ForceHealth || plan.Infantry != view.Infantry)
            { plan.LastProgressAt = view.Time; plan.EnemyHealth = view.EnemyHealth; plan.PlayerHealth = view.PlayerHealth; plan.ForceHealth = view.ForceHealth; plan.Infantry = view.Infantry; }
            // Opening assembly is deliberate waiting for the assault deadline, not a stuck tap loop.
            // Dense maps can hold a nearby contact without health changes until OpeningUntil+60.
            // Refresh on the transition frame too so the deadline itself is not treated as stall.
            if (awaitingAssault) plan.LastProgressAt = view.Time;
            // A loop of successful taps is not evidence that the match is progressing.
            if (view.Time - plan.LastProgressAt > 150) { touch.Phase = AriaPlayPhase.Blocked; return; }
            if (touch.Phase == AriaPlayPhase.Touching) return;
            if (OpeningDefense(view, ref plan, ref touch, ref output)) return;
            if (plan.TargetPending != 0 && (touch.TargetId == -20001 || touch.TargetId == -20002 || touch.TargetId == -20006) && touch.Actions > plan.ActionsAtTarget)
            {
                plan.TargetPending = 0;
                // Preserve a rectangle-selected fighting group between engagements.
                // Replacing it with individual cards splits an otherwise coordinated army.
                if (plan.GroupStage == 3 && view.SelectionVisible)
                {
                    plan.Slot = 0; plan.Cycle++; plan.ObserveUntil = view.Time + (touch.TargetId == -20006 ? 8 : touch.TargetId == -20001 ? 12 : 8);
                    plan.Intent = AriaSkirmishIntent.ObserveBattle;
                    return;
                }
                plan.Slot++;
                while (plan.Slot < 5 && (view.AvailableSquads & (1 << plan.Slot)) == 0) plan.Slot++;
                plan.ObserveUntil = view.Time + 1;
                if (plan.Slot >= 5) { plan.Slot = 0; plan.Cycle++; plan.ObserveUntil = view.Time + (touch.TargetId == -20006 ? 8 : touch.TargetId == -20001 ? 12 : 8); }
                // Finish issuing the army's orders before returning to production.
                // Only near-total losses justify interrupting the coordinated advance.
                if (plan.Slot != 0 && view.Infantry < 4 && view.Time >= plan.NextRecruitAt)
                { plan.Intent = AriaSkirmishIntent.Recruit; plan.RecruitBurstRemaining = 2; plan.ObserveUntil = 0; }
            }
            if (!view.MapOpen && plan.MapNavigationStage == 1)
            {
                // Keep the opening gesture stable while the hand moves to the map.
                // Advancing the plan here would cancel that touch before it lands.
                plan.Intent = plan.GroupStage == 7 ? AriaSkirmishIntent.GroupForce : AriaSkirmishIntent.FindThreat;
                Target(plan.AdvanceNavigation != 0 ? view.FocusAdvance : plan.GroupStage == 7 ? view.FocusGroup : view.FocusThreat, false, ref output);
                return;
            }
            if (view.MapOpen)
            {
                var focus = plan.AdvanceNavigation != 0 ? view.FocusAdvance : plan.GroupStage == 7 ? view.FocusGroup : view.FocusThreat;
                bool drag = plan.AdvanceNavigation != 0 ? view.FocusAdvanceDrag : plan.GroupStage == 7 ? view.FocusGroupDrag : view.FocusThreatDrag;
                var dragEnd = plan.AdvanceNavigation != 0 ? view.FocusAdvanceDragEnd : plan.GroupStage == 7 ? view.FocusGroupDragEnd : view.FocusThreatDragEnd;
                if (plan.MapOpenedAt == 0) plan.MapOpenedAt = view.Time;
                if (plan.MapNavigationStage == 1 && !focus.Available && view.Time < plan.MapOpenedAt + 5)
                    return; // The full map needs a presentation frame before its markers are clickable.
                if (plan.MapNavigationStage == 1 && focus.Available)
                {
                    plan.MapNavigationStage = 2; plan.MapFocusActions = touch.Actions;
                }
                if (plan.MapNavigationStage == 2 &&
                    !((touch.TargetId == -20004 || touch.TargetId == -20008 || touch.TargetId == -20011) && touch.Actions > plan.MapFocusActions))
                {
                    plan.Intent = plan.GroupStage == 7 ? AriaSkirmishIntent.GroupForce : AriaSkirmishIntent.FindThreat;
                    Target(focus, false, ref output);
                    if (drag) { output.Drag = 1; output.DragEnd = dragEnd; }
                    return;
                }
                // Exactly one focus gesture per opening, then close regardless of marker motion.
                plan.MapNavigationStage = 3;
                plan.Intent = plan.GroupStage == 7 ? AriaSkirmishIntent.GroupForce : AriaSkirmishIntent.FindThreat;
                Target(view.CloseMap, false, ref output); return;
            }
            if (plan.MapNavigationStage == 3)
            {
                if (plan.GroupStage == 7) { plan.GroupStage = 6; plan.GroupReadyAt = view.Time + 2.5f; }
                plan.MapNavigationStage = 0; plan.MapOpenedAt = 0; plan.AdvanceNavigation = 0;
                plan.MapNavigationReadyAt = view.Time + 6;
                plan.ObserveUntil = view.Time + 1;
            }
            if (view.Time < plan.ObserveUntil)
            {
                // Camera settlement is part of the current attack sequence. Do not
                // turn it into a recruitment window that pulls the camera away again.
                plan.Intent = view.Time < plan.MapNavigationReadyAt
                    ? AriaSkirmishIntent.FindThreat : plan.Slot != 0
                        ? AriaSkirmishIntent.SelectSquad : AriaSkirmishIntent.ObserveBattle;
                return;
            }
            bool finishingBase = view.SelectedCount > 0 && view.AssaultAtBase &&
                view.EnemyHealth > 0 && view.EnemyHealth <= 400;
            if (plan.AssaultStarted != 0 && plan.GroupStage >= 3 && view.Infantry < 8 && !finishingBase)
            {
                // Zero survivors is also a depleted assault. Rebuild before selecting
                // replacement cards, otherwise each delivery is sent out on its own.
                plan.GroupStage = 0; plan.AssaultStarted = 0; plan.OpeningUntil = view.Time + 45;
                plan.NextRecruitAt = view.Time;
                plan.Intent = AriaSkirmishIntent.Recruit;
            }
            else if (plan.GroupStage == 3 && view.SelectedCount < 8 && !finishingBase)
            { plan.GroupStage = 4; plan.Intent = AriaSkirmishIntent.ObserveBattle; }
            if (plan.RecruitDrawerSeen != 0 && !view.DrawerOpen)
            {
                bool unavailable = plan.NextRecruitAt > view.Time;
                plan.RecruitDrawerSeen = 0;
                plan.NextRecruitAt = UnityEngine.Mathf.Max(plan.NextRecruitAt, view.Time + 3);
                plan.RecruitBurstRemaining = unavailable ? 0 : UnityEngine.Mathf.Max(0, plan.RecruitBurstRemaining - 1);
                plan.Intent = plan.RecruitBurstRemaining > 0 && view.Infantry < 24
                    ? AriaSkirmishIntent.Recruit : AriaSkirmishIntent.SelectSquad;
                // Squad cards include replacements. Keep the current camera and
                // continue the rotation instead of regrouping at home after every delivery.
            }
            if (!view.DrawerOpen && plan.RecruitBurstRemaining > 0 && plan.Intent == AriaSkirmishIntent.Recruit &&
                view.Time < plan.NextRecruitAt) return;
            if (view.AvailableSquads == 0) { plan.Intent = AriaSkirmishIntent.Recruit; plan.GroupStage = 0; }
            bool groupStillFighting = plan.GroupStage == 3 && view.SelectionVisible && (view.SelectedCount >= 8 || finishingBase);
            if (groupStillFighting && !finishingBase && view.Infantry < 20 &&
                view.Time >= plan.NextRecruitAt && plan.Intent == AriaSkirmishIntent.ObserveBattle)
            {
                // Keep production working while the current army fights. Squad cards
                // include the arrivals; do not wait for the selected force to be wiped out.
                plan.GroupStage = 4; plan.RecruitBurstRemaining = 1;
                plan.Intent = AriaSkirmishIntent.Recruit; groupStillFighting = false;
            }
            if (!groupStillFighting && view.Infantry < 24 && view.Time >= plan.NextRecruitAt &&
                plan.Intent is AriaSkirmishIntent.Recruit or AriaSkirmishIntent.ObserveBattle)
            {
                if (plan.Intent == AriaSkirmishIntent.ObserveBattle && view.Infantry < 16)
                    plan.RecruitBurstRemaining = 2;
                plan.Intent = AriaSkirmishIntent.Recruit;
                if (view.DrawerOpen) plan.RecruitDrawerSeen = 1;
                if (view.Recruit.Available) { plan.RecruitUnavailableAt = 0; Target(view.Recruit, false, ref output); return; }
                if (plan.RecruitUnavailableAt == 0) plan.RecruitUnavailableAt = view.Time;
                if (view.Time - plan.RecruitUnavailableAt < 3) return;
                // An unavailable Recruit control is visible affordability/capacity feedback.
                // Close the drawer and fight with existing units; never force an order.
                plan.NextRecruitAt = view.Time + 12;
            }
            if (view.DrawerOpen) { Target(view.CloseDrawer, false, ref output); return; }
            if (plan.AssaultStarted == 0)
            {
                // Contest nearby contacts during assembly. Returning without a touch left
                // the opening army idle under fire on dense maps until OpeningUntil+60.
                // Fight campers even while rebuilding; map threat navigation needs a force.
                plan.Intent = AriaSkirmishIntent.ObserveBattle;
                bool openingThreat = view.Threat.Available;
                if (openingThreat)
                {
                    if (!view.AttackMode)
                    { plan.Intent = AriaSkirmishIntent.Attack; Target(view.Attack, false, ref output); return; }
                    plan.Intent = AriaSkirmishIntent.TargetThreat;
                    Target(view.ThreatGround.Available ? view.ThreatGround : view.Threat, true, ref output);
                    plan.ActionsAtTarget = touch.Actions; plan.TargetPending = 1;
                    return;
                }
                if (view.Infantry < 8 || view.AvailableSquads == 0)
                {
                    plan.Intent = AriaSkirmishIntent.Recruit;
                    return;
                }
                if (view.FocusThreat.Available && view.Time >= plan.MapNavigationReadyAt)
                {
                    plan.Intent = AriaSkirmishIntent.FindThreat;
                    plan.MapNavigationStage = 1;
                    Target(view.FocusThreat, false, ref output);
                    return;
                }
                return;
            }
            if (view.AvailableSquads == 0) return;
            if (view.FocusPlayer.Available)
            {
                // A selection disappearing (for example when its last unit dies)
                // needs a surviving squad card, not another camera trip and drag.
                if (plan.GroupStage == 3 && !view.SelectionVisible) plan.GroupStage = 4;
                if (plan.GroupStage < 3 || plan.GroupStage == 6)
                {
                    plan.Intent = AriaSkirmishIntent.GroupForce;
                    if (plan.GroupStage == 0)
                    {
                        if (view.FocusGroup.Available)
                        {
                            plan.GroupStage = 7; plan.MapNavigationStage = 1;
                            Target(view.FocusGroup, false, ref output); return;
                        }
                        plan.GroupAction = touch.Actions; plan.GroupStage = 1; plan.GroupReadyAt = 0;
                        Target(view.FocusPlayer, false, ref output); return;
                    }
                    if (plan.GroupStage == 1 && touch.Actions == plan.GroupAction)
                    { Target(view.FocusPlayer, false, ref output); return; }
                    if (plan.GroupStage == 1)
                    {
                        if (plan.GroupReadyAt == 0) plan.GroupReadyAt = view.Time + 2.5f;
                        if (view.Time < plan.GroupReadyAt) return;
                    }
                    if (plan.GroupStage == 6 && view.Time < plan.GroupReadyAt) return;
                    if (plan.GroupStage == 2 && touch.TargetId == -20005 && touch.Actions > plan.GroupAction && view.SelectionVisible)
                    {
                        // A clipped rectangle can select only the visible half of an army.
                        // In that case order every squad card, including the off-screen troops,
                        // instead of treating a small selection as the whole assault.
                        plan.GroupStage = view.SelectedCount >= UnityEngine.Mathf.Max(8, UnityEngine.Mathf.CeilToInt(view.Infantry * .75f)) ? 3 : 4;
                        plan.RegroupAt = view.Time + 40;
                    }
                    else if (HasSelectionRectangle(view))
                    {
                        // Select only arms rectangle selection; it never selects a squad.
                        // Require both clear corners before entering that mode.
                        if (!view.SelectionMode) { Target(view.Select, false, ref output); return; }
                        plan.GroupStage = 2; plan.GroupAction = touch.Actions;
                        Target(view.GroupStart, true, ref output); output.Drag = 1; output.DragEnd = view.GroupEnd.Position; return;
                    }
                    else
                    {
                        if (view.Time < plan.GroupReadyAt + 5) return;
                        // A crowded/occluded view cannot safely fit a box; use a visible squad card.
                        if (!view.SelectionVisible) { Target(view.Squad(plan.Slot), false, ref output); return; }
                        // A card selects only one squad: retain normal squad rotation.
                        plan.GroupStage = 4; plan.RegroupAt = view.Time + 40;
                    }
                }
            }
            for (int i = 0; i < 5 && (view.AvailableSquads & (1 << plan.Slot)) == 0; i++) plan.Slot = (plan.Slot + 1) % 5;
            if (view.AvailableSquads == 0) { plan.Intent = AriaSkirmishIntent.ObserveBattle; return; }
            if (plan.GroupStage != 3 && (!view.SelectionVisible || view.SelectedSlot != plan.Slot))
            { plan.Intent = AriaSkirmishIntent.SelectSquad; Target(view.Squad(plan.Slot), false, ref output); return; }
            if (view.AssaultAtBase && view.EnemyBase.Available)
            {
                // The base is the win objective. A gathered force must not chase
                // every new recruit or logistics contact away from that objective.
                if (!view.AttackMode)
                { plan.Intent = AriaSkirmishIntent.Attack; Target(view.Attack, false, ref output); return; }
                plan.Intent = AriaSkirmishIntent.TargetBase;
                Target(view.EnemyBase, true, ref output);
                plan.TargetPending = 1; plan.ActionsAtTarget = touch.Actions;
                return;
            }
            // Attack Move handles enemies along the route. Retain the approach goal
            // instead of repeatedly pulling the army toward incidental structures.
            if (view.AdvancePreferred &&
                (view.AdvanceGround.Available || view.FocusAdvance.Available || !view.EnemyBase.Available))
            {
                if (!view.AdvanceGround.Available)
                {
                    plan.Intent = AriaSkirmishIntent.FindBase;
                    if (view.FocusAdvance.Available)
                    {
                        // Match FindThreat: one map trip per settle window. Re-opening
                        // immediately after Close Map is a no-progress gesture loop.
                        if (view.FocusAdvance.Id == -20010)
                        {
                            if (view.Time < plan.MapNavigationReadyAt)
                            {
                                if (view.FocusEnemy.Available)
                                    Target(view.FocusEnemy, false, ref output);
                                return;
                            }
                            plan.AdvanceNavigation = 1; plan.MapNavigationStage = 1;
                        }
                        Target(view.FocusAdvance, false, ref output);
                    }
                    else Target(view.FocusEnemy, false, ref output);
                    return;
                }
                if (!view.AttackMode)
                { plan.Intent = AriaSkirmishIntent.Attack; Target(view.Attack, false, ref output); return; }
                plan.Intent = AriaSkirmishIntent.Advance;
                Target(view.AdvanceGround, true, ref output);
                plan.TargetPending = 1; plan.ActionsAtTarget = touch.Actions;
                return;
            }
            bool threat = view.Threat.Available;
            if (!threat && view.FocusThreat.Available)
            {
                plan.Intent = AriaSkirmishIntent.FindThreat;
                if (view.Time >= plan.MapNavigationReadyAt)
                {
                    plan.MapNavigationStage = 1;
                    Target(view.FocusThreat, false, ref output);
                }
                return;
            }
            if (!threat && !view.EnemyBase.Available)
            { plan.Intent = AriaSkirmishIntent.FindBase; Target(view.FocusEnemy, false, ref output); return; }
            if (!view.AttackMode)
            { plan.Intent = AriaSkirmishIntent.Attack; Target(view.Attack, false, ref output); return; }
            plan.Intent = threat ? AriaSkirmishIntent.TargetThreat : AriaSkirmishIntent.TargetBase;
            Target(threat ? (view.ThreatGround.Available ? view.ThreatGround : view.Threat) : view.EnemyBase, true, ref output);
            plan.ActionsAtTarget = touch.Actions; plan.TargetPending = 1;
        }
        private static bool OpeningDefense(in AriaSkirmishObservation view, ref AriaSkirmishPlanComponent plan,
            ref AriaPlaySessionComponent touch, ref AriaPlayObservationComponent output)
        {
            if (view.OwnDefenseTowers >= 2 && plan.DefenseStage == 0)
                plan.DefenseStage = 4;
            if (plan.DefenseStage == 4) return false;
            // Recruit before opening construction: the initial force must survive
            // the first raid while the player is occupied with placement.
            if (plan.DefenseStage == 0 && view.Infantry < 16) return false;
            if (plan.DefenseStage == 0)
            {
                // Only attempt construction when its normal visible controls exist.
                if (!view.DefenseBuild.Available || !view.FocusPlayer.Available)
                { plan.DefenseStage = 4; return false; }
                plan.DefensesPlaced = view.OwnDefenseTowers;
                plan.DefenseStage = 1; plan.DefenseActions = touch.Actions;
                plan.DefenseDeadline = view.Time + 75;
            }
            plan.Intent = AriaSkirmishIntent.BuildDefense;
            if (view.Time > plan.DefenseDeadline)
            {
                if (view.PlacementOpen) { Target(view.PlacementCancel, false, ref output); return true; }
                if (view.DrawerOpen) { Target(view.CloseDrawer, false, ref output); return true; }
                plan.DefenseStage = 4; plan.Intent = AriaSkirmishIntent.Recruit; return false;
            }
            if (plan.DefenseStage == 1)
            {
                if (touch.Actions == plan.DefenseActions) { Target(view.FocusPlayer, false, ref output); return true; }
                if (plan.DefenseReadyAt == 0) plan.DefenseReadyAt = view.Time + 2;
                if (view.Time < plan.DefenseReadyAt) return true;
                plan.DefenseStage = 2;
            }
            if (plan.DefenseStage == 3)
            {
                if (view.PlacementOpen) { Target(view.PlacementConfirm, false, ref output); return true; }
                if (touch.Actions <= plan.DefenseActions) return true;
                // A completed tap alone is not a purchased firing tower. Wait for
                // the public own-building census before advancing construction.
                if (view.ExpandedSession)
                {
                    if (view.OwnDefenseTowers <= plan.DefensesPlaced) return true;
                    plan.DefensesPlaced = view.OwnDefenseTowers;
                }
                else plan.DefensesPlaced++; // Legacy observations have no building census.
                plan.DefensePositioned = 0; plan.DefenseSite++;
                if (plan.DefensesPlaced < 2) { plan.DefenseStage = 2; plan.DefenseReadyAt = view.Time + 1; }
                else { plan.DefenseStage = 4; plan.OpeningUntil = view.Time + 180; plan.Intent = AriaSkirmishIntent.Recruit; return false; }
            }
            if (view.Time < plan.DefenseReadyAt) return true;
            if (view.PlacementOpen)
            {
                if (plan.DefenseSitePending != 0)
                {
                    if (touch.Actions <= plan.DefenseSiteAction && view.Site(plan.DefenseSite).Available)
                    { Target(view.Site(plan.DefenseSite), true, ref output); return true; }
                    plan.DefenseSitePending = 0;
                    if (touch.Actions > plan.DefenseSiteAction)
                    {
                        plan.DefensePositioned = 1;
                        plan.DefenseReadyAt = view.Time + .5f; return true;
                    }
                    // Placement can recenter the camera while the hand approaches.
                    // A site hidden by the HUD is no longer a touchable destination.
                    // Try another visible site, then the normal valid preview/cancel controls.
                    plan.DefenseSite++; plan.DefensePositioned = 0;
                }
                // Reposition through an ordinary visible ground touch; the placement UI
                // remains the authority for terrain, footprint, roads and affordability.
                if (plan.DefensePositioned == 0 || !view.PlacementConfirm.Available)
                {
                    if (plan.DefensePositioned != 0) { plan.DefenseSite++; plan.DefensePositioned = 0; }
                    while (plan.DefenseSite < 6 && !view.Site(plan.DefenseSite).Available) plan.DefenseSite++;
                    if (plan.DefenseSite < 6)
                    {
                        plan.DefenseSitePending = 1; plan.DefenseSiteAction = touch.Actions;
                        Target(view.Site(plan.DefenseSite), true, ref output); return true;
                    }
                }
                if (view.PlacementConfirm.Available)
                {
                    plan.DefenseStage = 3; plan.DefenseActions = touch.Actions;
                    Target(view.PlacementConfirm, false, ref output);
                }
                // Never force an invalid site or bypass normal affordability checks.
                else { plan.DefenseDeadline = view.Time; Target(view.PlacementCancel, false, ref output); }
                return true;
            }
            Target(view.DefenseBuild, false, ref output); return true;
        }
        private static bool HasSelectionRectangle(in AriaSkirmishObservation view)
        {
            var size = view.GroupEnd.Position - view.GroupStart.Position;
            return view.GroupStart.Available && view.GroupEnd.Available &&
                UnityEngine.Mathf.Abs(size.x) >= 20 && UnityEngine.Mathf.Abs(size.y) >= 20;
        }
        private static void StepHomePadPlacement(in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan, ref AriaPlaySessionComponent touch,
            ref AriaPlayObservationComponent output)
        {
            plan.Intent = plan.PadStage == 8 ? AriaSkirmishIntent.WaitForAirPadSite : AriaSkirmishIntent.BuildAirPad;
            if (plan.PadStage == 8)
            {
                // No legal visible site was found in the bounded search. Wait for
                // the player or a fresh ARIA start rather than using camera position.
                if (view.PlacementOpen) Target(view.PlacementCancel, false, ref output);
                else output.Kind = AriaPlayObservationKind.Waiting;
                return;
            }
            if (view.Time > plan.PadDeadline)
            {
                plan.PadStage = 8;
                plan.Intent = AriaSkirmishIntent.WaitForAirPadSite;
                if (view.PlacementOpen) Target(view.PlacementCancel, false, ref output);
                return;
            }
            if (plan.PadStage == 1)
            {
                if (view.PlacementOpen) { plan.PadStage = 8; Target(view.PlacementCancel, false, ref output); return; }
                if (!view.FocusPlayer.Available) { plan.PadStage = 8; return; }
                plan.PadAction = touch.Actions;
                plan.PadStage = 2;
                Target(view.FocusPlayer, false, ref output);
                return;
            }
            if (plan.PadStage == 2)
            {
                if (view.PlacementOpen) { plan.PadStage = 8; Target(view.PlacementCancel, false, ref output); return; }
                if (touch.Actions <= plan.PadAction) { Target(view.FocusPlayer, false, ref output); return; }
                plan.PadStage = 3;
                plan.PadReadyAt = view.Time + .5f;
            }
            if (plan.PadStage == 3)
            {
                if (view.Time < plan.PadReadyAt) return;
                if (view.PlacementOpen) { plan.PadStage = 8; Target(view.PlacementCancel, false, ref output); return; }
                if (!view.AirPad.Available) return;
                plan.PadAction = touch.Actions;
                plan.PadTargetId = view.AirPad.Id;
                plan.PadStage = 10;
                Target(view.AirPad, false, ref output);
                return;
            }
            if (plan.PadStage == 10)
            {
                if (touch.Actions <= plan.PadAction)
                {
                    if (view.AirPad.Id == plan.PadTargetId) Target(view.AirPad, false, ref output);
                    return;
                }
                if (touch.TargetId != plan.PadTargetId) { plan.PadStage = 8; return; }
                if (!view.PlacementOpen)
                { plan.PadStage = 3; plan.PadReadyAt = view.Time + .2f; return; }
                plan.PadStage = 4;
                plan.PadSiteIndex = 0;
            }
            if (plan.PadStage == 4)
            {
                if (!view.PlacementOpen) { plan.PadStage = 8; return; }
                while (plan.PadSiteIndex < 4 && !view.PadSite(plan.PadSiteIndex).Available)
                    plan.PadSiteIndex++;
                if (plan.PadSiteIndex == 4)
                {
                    // Refocus once after construction changes the camera. The
                    // remaining deadline bounds the retry and eventual cancel.
                    if (plan.PadReadyAt >= 0)
                    {
                        plan.PadReadyAt = -1;
                        plan.PadSiteIndex = 0;
                        if (!view.FocusPlayer.Available) { plan.PadStage = 8; return; }
                        plan.PadAction = touch.Actions;
                        plan.PadStage = 9;
                        Target(view.FocusPlayer, false, ref output);
                        return;
                    }
                    plan.PadStage = 8;
                    plan.Intent = AriaSkirmishIntent.WaitForAirPadSite;
                    Target(view.PlacementCancel, false, ref output);
                    return;
                }
                plan.PadAction = touch.Actions;
                plan.PadStage = 5;
                Target(view.PadSite(plan.PadSiteIndex), true, ref output);
                return;
            }
            if (plan.PadStage == 5)
            {
                if (!view.PlacementOpen) { plan.PadStage = 8; return; }
                if (touch.Actions <= plan.PadAction)
                { Target(view.PadSite(plan.PadSiteIndex), true, ref output); return; }
                if (touch.TargetId != view.PadSite(plan.PadSiteIndex).Id)
                { plan.PadSiteIndex++; plan.PadStage = 4; return; }
                plan.PadFeedbackFrame = view.Frame;
                plan.PadStage = 6;
                return;
            }
            if (plan.PadStage == 6)
            {
                if (!view.PlacementOpen) { plan.PadStage = 8; return; }
                if (view.Frame <= plan.PadFeedbackFrame) return;
                if (!view.PlacementConfirm.Available)
                { plan.PadSiteIndex++; plan.PadStage = 4; return; }
                plan.PadAction = touch.Actions;
                plan.PadStage = 7;
                Target(view.PlacementConfirm, false, ref output);
                return;
            }
            if (plan.PadStage == 7)
            {
                if (touch.Actions <= plan.PadAction)
                { Target(view.PlacementConfirm, false, ref output); return; }
                if (!view.PlacementOpen && !view.PadPresent) plan.PadStage = 8;
            }
            if (plan.PadStage == 9)
            {
                if (touch.Actions <= plan.PadAction)
                { Target(view.FocusPlayer, false, ref output); return; }
                plan.PadStage = 4;
            }
        }

        private static void StepExpandedBaseAssault(in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan, ref AriaPlaySessionComponent touch,
            ref AriaPlayObservationComponent output)
        {
            // Public visible controls only. No gameplay Entity mutation from this planner.
            if (view.Finished)
            {
                plan.Intent = AriaSkirmishIntent.Handback;
                output.Kind = AriaPlayObservationKind.Finished;
                return;
            }
            if (touch.Phase == AriaPlayPhase.Touching) return;
            // NEXT reuses its button identity across pages. A changed visible
            // page proves the tap succeeded; do not count later inspections as
            // retries of that completed action. Paging is not battle progress.
            if (plan.ObservedPageIndex != view.ExpandedPageIndex)
            {
                plan.ObservedPageIndex = view.ExpandedPageIndex;
                touch.Attempts = 0;
            }
            // Supply and construction are public progress, but each milestone
            // counts once. Repeated taps and spending/earning loops cannot
            // indefinitely refresh the watchdog.
            int milestones = (view.LogisticsTruckCommitted ? 1 : 0) |
                (view.ReadinessEligible ? 2 : 0) | (view.PadPresent ? 4 : 0);
            bool newMilestone = view.AirProfile && (milestones & ~plan.EconomicMilestones) != 0;
            if (newMilestone) plan.MaterialsHighWater = view.OwnMaterials;
            bool savingForAir = view.AirProfile && view.LogisticsTruckCommitted && !view.AirQueueOffered;
            int savedMaterials = UnityEngine.Mathf.Min(view.OwnMaterials, 300);
            bool supplyProgress = savingForAir && savedMaterials > plan.MaterialsHighWater;
            plan.EconomicMilestones |= milestones;
            if (supplyProgress) plan.MaterialsHighWater = savedMaterials;
            // Only a new closest approach on the player's presented minimap
            // counts. Paging, jitter and retreat/re-advance cannot mask a stall.
            bool assaultAdvance = false;
            if (plan.AssaultIssued != 0 && view.AssaultDistanceVisible &&
                view.NearestFriendlyObjectiveDistance >= 0f &&
                !float.IsNaN(view.NearestFriendlyObjectiveDistance) &&
                !float.IsInfinity(view.NearestFriendlyObjectiveDistance))
            {
                if (plan.AssaultDistanceObserved == 0)
                {
                    plan.AssaultDistanceObserved = 1;
                    plan.BestAssaultDistance = view.NearestFriendlyObjectiveDistance;
                }
                else if (view.NearestFriendlyObjectiveDistance <= plan.BestAssaultDistance - 2f)
                {
                    plan.BestAssaultDistance = view.NearestFriendlyObjectiveDistance;
                    assaultAdvance = true;
                }
            }
            if (plan.LastProgressAt == 0 || plan.EnemyHealth != view.EnemyHealth ||
                plan.PlayerHealth != view.PlayerHealth || plan.Infantry != view.Infantry ||
                newMilestone || supplyProgress || assaultAdvance)
            {
                plan.LastProgressAt = view.Time;
                plan.EnemyHealth = view.EnemyHealth; plan.PlayerHealth = view.PlayerHealth; plan.Infantry = view.Infantry;
                touch.LastProgressAt = view.Time;
                touch.LastObjectiveProgressAt = view.Time;
            }
            if (view.Time - plan.LastProgressAt > 180f)
            {
                touch.Phase = AriaPlayPhase.Blocked;
                touch.GestureRequested = 0;
                return;
            }
            if (StepPresentedHomeDefense(view, ref plan, ref touch, ref output)) return;
            // An air-capable starting force cannot leave its base undefended.
            // Reuse the visible, bounded construction sequence used by legacy
            // skirmishes after the first reinforcement squad arrives.
            if (view.AirProfile && plan.AssaultStarted == 0 &&
                OpeningDefense(view, ref plan, ref touch, ref output)) return;
            if (view.PadPresent) plan.PadStage = 0;
            if (plan.PadStage != 0)
            {
                StepHomePadPlacement(view, ref plan, ref touch, ref output);
                return;
            }
            if (view.PlacementOpen)
            {
                // A placement opened outside this plan has no proven home site.
                plan.Intent = AriaSkirmishIntent.Inspect;
                Target(view.PlacementCancel, false, ref output);
                return;
            }
            // Preserve a viable base-assault force, then establish physical
            // Oil and Fuel delivery before research or repeated aircraft sorties.
            // These are visible paid catalog controls, with queue/capacity eligibility.
            bool openingNeedsInfantry = !view.CombinedArmsField && plan.AssaultStarted == 0 && view.Infantry < 20 &&
                (plan.OpeningUntil == 0 || view.Time < plan.OpeningUntil);
            bool supplyReady = view.AirProfile && !openingNeedsInfantry &&
                (!view.CombinedArmsField || view.OwnStructureAttackUnits >= 8);
            // The opening force or its existing deadline is complete before
            // a supply touch can return from this frame.
            if (supplyReady && !view.CombinedArmsField) plan.AssaultStarted = 1;
            if (supplyReady && !view.LogisticsTruckCommitted && view.CanAffordLogisticsTruck &&
                view.RecruitLogisticsTruck.Available)
            {
                plan.Intent = AriaSkirmishIntent.Recruit;
                Target(view.RecruitLogisticsTruck, false, ref output);
                return;
            }
            if (supplyReady && view.LogisticsTruckCommitted && view.TankersCommitted < 2 &&
                view.CanAffordTanker && view.RecruitTanker.Available)
            {
                plan.Intent = AriaSkirmishIntent.Recruit;
                Target(view.RecruitTanker, false, ref output);
                return;
            }
            if (StepAircraftCycle(view, ref plan, ref touch, ref output)) return;
            if (view.AttackMode && view.SelectionVisible)
            {
                if (view.EnemyBase.Available)
                {
                    plan.Intent = AriaSkirmishIntent.TargetBase;
                    Target(view.EnemyBase, true, ref output);
                }
                else if (view.AdvanceGround.Available)
                {
                    // The labelled objective is public; a hidden base is not a precision target.
                    // Offer the already presented terrain approach for a separate normal Attack Move touch.
                    // Camera focus alone cannot reveal a contact and must never issue this order.
                    plan.Intent = AriaSkirmishIntent.Advance;
                    Target(view.AdvanceGround, true, ref output);
                }
                else
                {
                    plan.Intent = AriaSkirmishIntent.FindBase;
                    Target(view.FocusEnemy, false, ref output);
                }
                return;
            }
            if (view.ExpandedRetries >= 3)
            {
                if (view.Hold.Available && plan.Intent == AriaSkirmishIntent.Attack)
                {
                    plan.Intent = AriaSkirmishIntent.Hold;
                    Target(view.Hold, false, ref output);
                    return;
                }
                plan.Intent = AriaSkirmishIntent.Handback;
                output.Kind = AriaPlayObservationKind.Waiting;
                return;
            }
            if (view.VisibleHostileAir > 0 && !view.AntiAirCommitted && view.CanAffordAntiAir && view.RecruitAntiAir.Available)
            {
                plan.Intent = AriaSkirmishIntent.Recruit;
                Target(view.RecruitAntiAir, false, ref output);
                return;
            }
            // Combined Arms needs a viable structure force before spending
            // its remaining materials on rifles that cannot hurt the base.
            if (view.CombinedArmsField && view.OwnStructureAttackUnits < 8 && view.Infantry < 24)
            {
                if (view.RocketeerRecruitPending)
                {
                    plan.Intent = AriaSkirmishIntent.ObserveBattle;
                    if (view.DrawerOpen) Target(view.CloseDrawer, false, ref output);
                    return;
                }
                if (view.CanAffordRocketeer && view.RecruitRocketeer.Available)
                {
                    plan.Intent = AriaSkirmishIntent.Recruit;
                    Target(view.RecruitRocketeer, false, ref output);
                    return;
                }
            }
            if (view.AirProfile && plan.AssaultStarted == 0)
            {
                if (plan.OpeningUntil == 0) plan.OpeningUntil = view.Time + 75f;
                if (view.Infantry < 20 && view.Time < plan.OpeningUntil)
                {
                    if (view.RifleRecruitPending)
                    {
                        plan.Intent = AriaSkirmishIntent.ObserveBattle;
                        if (view.DrawerOpen) Target(view.CloseDrawer, false, ref output);
                        else output.Kind = AriaPlayObservationKind.Waiting;
                        return;
                    }
                    if (view.CanAffordRifle)
                    {
                        plan.Intent = AriaSkirmishIntent.Recruit;
                        // Drawer/category transitions can briefly hide their next
                        // control. Keep the bounded opening instead of treating
                        // one unavailable frame as an unaffordable reinforcement.
                        if (view.Recruit.Available) Target(view.Recruit, false, ref output);
                        else output.Kind = AriaPlayObservationKind.Waiting;
                        return;
                    }
                }
                plan.AssaultStarted = 1;
            }
            if (!view.ReadinessEligible && view.CanUpgradeReadiness && view.UpgradeReadiness.Available &&
                plan.AssaultIssued != 0)
            {
                plan.Intent = AriaSkirmishIntent.Inspect;
                Target(view.UpgradeReadiness, false, ref output);
                return;
            }
            if (view.ReadinessEligible && !view.PadPresent && view.CanBuildAirPad && view.AirPad.Available)
            {
                plan.Intent = AriaSkirmishIntent.Inspect;
                plan.PadStage = 1;
                plan.PadDeadline = view.Time + 45f;
                StepHomePadPlacement(view, ref plan, ref touch, ref output);
                return;
            }
            if (view.AirQueueOffered && !view.AirRecruitPending && view.OwnAttackAirLive == 0 && view.RecruitAir.Available)
            {
                plan.Intent = AriaSkirmishIntent.Recruit;
                Target(view.RecruitAir, false, ref output);
                return;
            }
            if (view.DrawerOpen)
            {
                if (!view.AirProfile && !view.RifleRecruitPending && plan.Intent == AriaSkirmishIntent.Recruit && view.Infantry < 16 &&
                    view.CanAffordRifle && view.Recruit.Available &&
                    view.VisibleHostileAir == 0 && !view.AirQueueOffered)
                {
                    Target(view.Recruit, false, ref output);
                    return;
                }
                // Once a purchase/research action is accepted, return to the
                // visible army controls before interpreting their page state.
                plan.Intent = AriaSkirmishIntent.Inspect;
                Target(view.CloseDrawer, false, ref output);
                return;
            }
            if (plan.AssaultIssued != 0 &&
                (view.ExpandedAssaultMask & ~view.ExpandedAttackOrderMask) != 0)
            {
                plan.AssaultIssued = 0;
                plan.PagesOrdered = 0;
                plan.PagedToAssault = 0;
            }
            if (TryExpandedGroundAssault(view, ref plan, ref output))
                return;
            // The tank and rocketeers are already ordered. Do not replace that
            // column with the rifle card on page 0.
            if (plan.AssaultIssued != 0 && plan.StructureOrdered != 0)
            {
                // New reinforcements can arrive on another page. Inspect the
                // public tray periodically without replacing existing orders.
                if (plan.MapNavigationStage == 1 && view.ExpandedPageIndex != plan.AssaultPageSeen)
                {
                    plan.MapNavigationStage = 0;
                    plan.ObserveUntil = view.Time + 12f;
                }
                if (view.NextSquadPage.Available &&
                    (plan.MapNavigationStage == 1 || view.Time >= plan.ObserveUntil))
                {
                    if (plan.MapNavigationStage == 0)
                    { plan.MapNavigationStage = 1; plan.AssaultPageSeen = view.ExpandedPageIndex; }
                    plan.Intent = AriaSkirmishIntent.Inspect;
                    Target(view.NextSquadPage, false, ref output);
                    return;
                }
                plan.Intent = AriaSkirmishIntent.ObserveBattle;
                output.Kind = AriaPlayObservationKind.Waiting;
                return;
            }
            // Rifles cannot hurt a Barracks. Do not spend the attack button on them
            // while a later page still holds the tank and rocketeers.
            if (view.EnemyDesignatedAlive && plan.AssaultIssued == 0 &&
                view.ExpandedAssaultMask == 0 && view.NextSquadPage.Available)
            {
                plan.Intent = AriaSkirmishIntent.Inspect;
                output.Kind = AriaPlayObservationKind.Waiting;
                return;
            }
            if (!view.AirProfile && !view.RifleRecruitPending && view.Infantry < 16 && view.CanAffordRifle && view.Recruit.Available)
            {
                plan.Intent = AriaSkirmishIntent.Recruit;
                Target(view.Recruit, false, ref output);
                return;
            }
            if (!view.SelectionVisible && view.Squad0.Available &&
                SelectionCanDamageDesignatedBase(view, squad0WithoutSelection: true))
            {
                plan.Intent = AriaSkirmishIntent.SelectSquad;
                Target(view.Squad0, false, ref output);
                return;
            }
            // Rifles and cars cannot damage a Barracks. Attack only when the
            // visible selection includes a structure card (tank, rocketeer,
            // breacher, siege), or when this observation has no page model.
            if (view.EnemyDesignatedAlive && view.Attack.Available && view.SelectionVisible &&
                SelectionCanDamageDesignatedBase(view, squad0WithoutSelection: false))
            {
                plan.Intent = AriaSkirmishIntent.Attack;
                Target(view.Attack, false, ref output);
                return;
            }
            // A visible Hold button is not an actionable order without a living
            // selection. Let an already-issued assault continue toward the base
            // instead of spending three touch retries on an unselected command.
            if (view.Hold.Available && view.SelectionVisible && view.ExpandedSelectedGroups > 0)
            {
                plan.Intent = AriaSkirmishIntent.Hold;
                Target(view.Hold, false, ref output);
                return;
            }
            plan.Intent = AriaSkirmishIntent.ObserveBattle;
            output.Kind = AriaPlayObservationKind.Waiting;
        }

        private static bool StepPresentedHomeDefense(in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan, ref AriaPlaySessionComponent touch,
            ref AriaPlayObservationComponent output)
        {
            if (!view.PresentedHomeThreat)
            {
                if (plan.HomeDefenseStage != 0)
                {
                    plan.HomeDefenseStage = 0;
                    // Defensive orders do not prove the enemy-base sweep was issued.
                    plan.AssaultIssued = plan.PagedToAssault = plan.AssaultSelecting = plan.StructureOrdered = 0;
                    plan.PagesOrdered = plan.AssaultPageSeen = 0;
                }
                return false;
            }
            plan.Intent = AriaSkirmishIntent.DefendBase;
            // Finish through the same player controls before selecting defenders.
            if (view.PlacementOpen) { Target(view.PlacementCancel, false, ref output); return true; }
            if (view.DrawerOpen) { Target(view.CloseDrawer, false, ref output); return true; }
            if (view.MapOpen) { Target(view.CloseMap, false, ref output); return true; }
            if (plan.HomeDefenseStage == 0)
            {
                if (!view.FocusPlayer.Available) return true;
                plan.DefenseStage = 4;
                plan.HomeDefenseAction = touch.Actions;
                plan.HomeDefenseStage = 1;
                Target(view.FocusPlayer, false, ref output);
                return true;
            }
            if (plan.HomeDefenseStage == 1)
            {
                if (touch.Actions <= plan.HomeDefenseAction)
                { Target(view.FocusPlayer, false, ref output); return true; }
                if (view.ExpandedPageIndex > 0)
                { Target(view.PreviousSquadPage, false, ref output); return true; }
                plan.HomeDefensePage = 0;
                plan.HomeDefenseStage = 2;
            }
            if (plan.HomeDefenseStage == 2)
            {
                if (TryDeselectSquads(view, ref output)) return true;
                // Deselecting an off-screen squad may have moved the roster.
                // Restore this sweep's window, including later defense windows.
                if (view.ExpandedPageIndex != plan.HomeDefensePage)
                {
                    Target(view.ExpandedPageIndex < plan.HomeDefensePage
                        ? view.NextSquadPage : view.PreviousSquadPage, false, ref output);
                    return true;
                }
                plan.HomeDefenseStage = 3;
            }
            if (plan.HomeDefenseStage == 3)
            {
                int pending = view.ExpandedAssaultMask & ~view.ExpandedSelectedMask;
                if (pending != 0)
                { Target(view.Squad(LowestSetBit(pending)), false, ref output); return true; }
                plan.HomeDefenseStage = view.ExpandedAssaultMask == 0 ? 6 : 4;
            }
            if (plan.HomeDefenseStage == 4)
            {
                if (!view.AttackMode) { Target(view.Attack, false, ref output); return true; }
                var threat = view.ThreatGround.Available ? view.ThreatGround : view.Threat;
                if (!threat.Available) { Target(view.FocusPlayer, false, ref output); return true; }
                plan.HomeDefenseAction = touch.Actions;
                plan.HomeDefenseStage = 5;
                Target(threat, true, ref output);
                return true;
            }
            if (plan.HomeDefenseStage == 5)
            {
                if (touch.Actions <= plan.HomeDefenseAction || view.AttackMode)
                { Target(view.ThreatGround.Available ? view.ThreatGround : view.Threat, true, ref output); return true; }
                plan.HomeDefenseStage = 6;
            }
            if (plan.HomeDefenseStage == 6)
            {
                if (view.NextSquadPage.Available)
                {
                    plan.HomeDefensePage = view.ExpandedPageIndex;
                    plan.HomeDefenseStage = 7;
                    Target(view.NextSquadPage, false, ref output);
                    return true;
                }
                plan.HomeDefenseObserveUntil = view.Time + 8f;
                plan.HomeDefenseStage = 8;
            }
            if (plan.HomeDefenseStage == 7)
            {
                if (view.ExpandedPageIndex == plan.HomeDefensePage)
                    Target(view.NextSquadPage, false, ref output);
                else
                {
                    plan.HomeDefensePage = view.ExpandedPageIndex;
                    plan.HomeDefenseStage = 2;
                }
                return true;
            }
            if (view.Time >= plan.HomeDefenseObserveUntil) plan.HomeDefenseStage = 0;
            return true;
        }

        private static bool StepAircraftCycle(in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan, ref AriaPlaySessionComponent touch,
            ref AriaPlayObservationComponent output)
        {
            if (!view.AirProfile || plan.AirCycleCount != 0) return false;
            if (plan.AirCycleStage == 0)
            {
                if (view.OwnAttackAirActive == 0 || plan.AssaultIssued == 0)
                { plan.AirSortieObservedAt = 0; return false; }
                if (plan.AirSortieObservedAt == 0) plan.AirSortieObservedAt = view.Time;
                if (view.Time - plan.AirSortieObservedAt < 45f) return false;
                plan.AirCycleStage = 1;
                plan.AirCycleDeadline = view.Time + 120f;
            }
            if (view.OwnAttackAirLive == 0 || !view.PadPresent || view.Time >= plan.AirCycleDeadline)
            {
                plan.AirCycleStage = 0;
                plan.AirCycleCount = 2; // Bounded recovery; normal assault remains available.
                return false;
            }
            if (plan.AirCycleStage == 1)
            {
                plan.Intent = AriaSkirmishIntent.ReturnAircraft;
                if (view.DrawerOpen) { Target(view.CloseDrawer, false, ref output); return true; }
                if (view.SelectedAircraft && view.ExpandedSelectedGroups <= 1) { plan.AirCycleStage = 2; }
                else
                {
                    if (TryDeselectSquads(view, ref output)) return true;
                    for (int slot = 0; slot < 5; slot++)
                        if ((view.ExpandedAirMask & (1 << slot)) != 0 && view.Squad(slot).Available)
                        { Target(view.Squad(slot), false, ref output); return true; }
                    if (TryDeselectSquads(view, ref output)) return true;
                    if (view.NextSquadPage.Available)
                        Target(view.NextSquadPage, false, ref output);
                    else output.Kind = AriaPlayObservationKind.Waiting;
                    return true;
                }
            }
            if (plan.AirCycleStage == 2)
            {
                plan.Intent = AriaSkirmishIntent.ReturnAircraft;
                if (!view.SelectedAircraft) { plan.AirCycleStage = 1; return true; }
                if (!view.ReturnAircraft.Available)
                {
                    if (view.OpenAircraftActions.Available) Target(view.OpenAircraftActions, false, ref output);
                    else output.Kind = AriaPlayObservationKind.Waiting;
                    return true;
                }
                plan.AirCycleAction = touch.Actions;
                plan.AirCycleStage = 3;
                Target(view.ReturnAircraft, false, ref output);
                return true;
            }
            if (plan.AirCycleStage == 3)
            {
                plan.Intent = AriaSkirmishIntent.ReturnAircraft;
                if (touch.Actions <= plan.AirCycleAction)
                {
                    if (view.ReturnAircraft.Available) Target(view.ReturnAircraft, false, ref output);
                    else output.Kind = AriaPlayObservationKind.Waiting;
                    return true;
                }
                if (view.OwnAttackAirActive == 0 && view.OwnAttackAirLanded > 0)
                {
                    plan.AirCycleStage = 4;
                    plan.AirServiceReadyAt = view.Time + 5f;
                }
                else { output.Kind = AriaPlayObservationKind.Waiting; return true; }
            }
            plan.Intent = AriaSkirmishIntent.ServiceAircraft;
            if (view.Time < plan.AirServiceReadyAt || view.OwnAirFuel <= 0)
            { output.Kind = AriaPlayObservationKind.Waiting; return true; }
            // The landed aircraft is serviced by shared home/fuel owners. Allow
            // the visible squad-card attack sequence to issue a second sortie.
            plan.AirCycleStage = 0;
            plan.AirCycleCount = 1;
            plan.AssaultIssued = 0;
            plan.PagesOrdered = 0;
            plan.StructureOrdered = 0;
            plan.ObserveUntil = view.Time + 1f;
            output.Kind = AriaPlayObservationKind.Waiting;
            return true;
        }

        private static bool SelectionCanDamageDesignatedBase(
            in AriaSkirmishObservation view,
            bool squad0WithoutSelection)
        {
            bool pageModel = view.ExpandedTotalGroups > 0 || view.ExpandedStructureMask != 0 || view.ExpandedAssaultMask != 0;
            if (!pageModel)
                return true;
            if (squad0WithoutSelection)
                return (view.ExpandedStructureMask & 1) != 0;
            return (view.ExpandedStructureMask & view.ExpandedSelectedMask) != 0;
        }

        private static bool TryExpandedGroundAssault(
            in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan,
            ref AriaPlayObservationComponent output)
        {
            if (!view.EnemyDesignatedAlive || plan.AssaultIssued != 0)
                return false;
            // Older public-control observations have no page projection. Keep
            // their existing Attack/Hold path; a live expanded roster always
            // reports at least one page, including when it has zero groups.
            if (view.ExpandedPageCount <= 0 && view.ExpandedTotalGroups == 0 &&
                view.ExpandedAssaultMask == 0 && view.ExpandedStructureMask == 0 &&
                !view.ExpandedCanPreviousPage && !view.ExpandedCanNextPage)
                return false;
            // Begin every bounded sweep at page zero. Page changes are acknowledged only
            // when a later observation reports a different PageIndex.
            if (plan.PagedToAssault == 0 && view.ExpandedPageIndex > 0)
            {
                if (view.PreviousSquadPage.Available)
                { plan.Intent = AriaSkirmishIntent.Inspect; Target(view.PreviousSquadPage, false, ref output); }
                else output.Kind = AriaPlayObservationKind.Waiting;
                return true;
            }
            if (plan.PagedToAssault == 0) plan.PagedToAssault = 1;
            // Rifles screen the structure column against enemy troops. Visit
            // every assault page, then require a tank or rocketeer Attack order
            // before treating the Barracks assault as issued.
            return TryStructureColumn(view, ref plan, ref output);
        }

        private static bool TryStructureColumn(
            in AriaSkirmishObservation view,
            ref AriaSkirmishPlanComponent plan,
            ref AriaPlayObservationComponent output)
        {
            if (plan.AssaultSelecting == 0 && view.ExpandedSelectedGroups > 0)
            {
                plan.SelectionResetPage = view.ExpandedPageIndex;
                plan.AssaultSelecting = 2;
            }
            if (plan.AssaultSelecting == 2)
            {
                if (TryDeselectSquads(view, ref output)) return true;
                // Resume the intended assault window after normal card/swipe input.
                if (view.ExpandedPageIndex != plan.SelectionResetPage)
                {
                    plan.Intent = AriaSkirmishIntent.Inspect;
                    Target(view.ExpandedPageIndex < plan.SelectionResetPage
                        ? view.NextSquadPage : view.PreviousSquadPage, false, ref output);
                    return true;
                }
                plan.AssaultSelecting = 0;
            }
            int pending = view.ExpandedAssaultMask & ~view.ExpandedAttackOrderMask & ~view.ExpandedSelectedMask;
            if (pending != 0)
            {
                int slot = LowestSetBit(pending);
                AriaTouchTarget card = view.Squad(slot);
                if (!card.Available)
                    return false;
                plan.AssaultSelecting = 1;
                plan.Intent = AriaSkirmishIntent.SelectSquad;
                Target(card, false, ref output);
                return true;
            }

            if ((view.ExpandedStructureMask & view.ExpandedAttackOrderMask) != 0)
                plan.StructureOrdered = 1;

            bool assaultOrdered = view.ExpandedAssaultMask == 0 ||
                (view.ExpandedAssaultMask & ~view.ExpandedAttackOrderMask) == 0;
            // Already accepted groups keep fighting while the remaining cohort is selected.
            // Selection above deliberately excludes their AttackOrder bits, so requiring them
            // selected here would prevent the next explicit Attack command from ever arming.
            int remainingAssault = view.ExpandedAssaultMask & ~view.ExpandedAttackOrderMask;
            bool assaultSelected = remainingAssault != 0 &&
                (remainingAssault & ~view.ExpandedSelectedMask) == 0;
            if (!assaultOrdered && assaultSelected)
            {
                // Keep pressing Attack until the drawer shows the order.
                // Latching on the request left the tank unselected when the tap missed.
                // Paging away while Attack is covered clears that selection.
                if (!view.Attack.Available)
                {
                    plan.Intent = AriaSkirmishIntent.Inspect;
                    output.Kind = AriaPlayObservationKind.Waiting;
                    return true;
                }

                plan.Intent = AriaSkirmishIntent.Attack;
                Target(view.Attack, false, ref output);
                return true;
            }

            bool pageInspected = assaultOrdered;
            if (pageInspected && plan.AssaultPageSeen != view.ExpandedPageIndex + 1)
            {
                plan.PagesOrdered++;
                plan.AssaultPageSeen = view.ExpandedPageIndex + 1;
            }
            if (plan.PagedToAssault == 2)
            {
                if (view.ExpandedPageIndex > 0 && view.PreviousSquadPage.Available)
                { plan.Intent = AriaSkirmishIntent.Inspect; Target(view.PreviousSquadPage, false, ref output); return true; }
                if (view.ExpandedPageIndex == 0 && plan.StructureOrdered != 0 &&
                    plan.PagesOrdered >= (view.ExpandedPageCount > 0 ? view.ExpandedPageCount : 1))
                { plan.AssaultIssued = 1; return false; }
            }
            if (view.NextSquadPage.Available)
            {
                plan.PagedToAssault = 1;
                plan.AssaultSelecting = 0;
                plan.Intent = AriaSkirmishIntent.SelectSquad;
                Target(view.NextSquadPage, false, ref output);
                return true;
            }
            if (view.PreviousSquadPage.Available)
            {
                plan.PagedToAssault = 2;
                plan.AssaultSelecting = 0;
                plan.Intent = AriaSkirmishIntent.Inspect;
                Target(view.PreviousSquadPage, false, ref output);
                return true;
            }
            // A one-page roster completes in place. Multi-page sweeps complete only
            // after the observed Previous actions have returned the tray to page zero.
            if (view.ExpandedPageIndex == 0 && plan.StructureOrdered != 0 && plan.PagesOrdered >= view.ExpandedPageCount)
            { plan.AssaultIssued = 1; return false; }
            if (!pageInspected || plan.StructureOrdered == 0)
            {
                plan.Intent = AriaSkirmishIntent.Inspect;
                output.Kind = AriaPlayObservationKind.Waiting;
                return true;
            }
            return false;
        }

        private static bool TryDeselectSquads(in AriaSkirmishObservation view,
            ref AriaPlayObservationComponent output)
        {
            if (view.ExpandedSelectedGroups <= 0) return false;
            if (view.SelectedSquadToToggle.Available)
                Target(view.SelectedSquadToToggle, false, ref output);
            else output.Kind = AriaPlayObservationKind.Waiting;
            return true;
        }

        private static int LowestSetBit(int mask)
        {
            int bit = 0;
            int value = mask;
            while ((value & 1) == 0)
            {
                value >>= 1;
                bit++;
            }

            return bit;
        }

        private static void Target(AriaTouchTarget target, bool world, ref AriaPlayObservationComponent output)
        {
            if (!target.Available) { output.Kind = AriaPlayObservationKind.Unavailable; return; }
            output.Kind = world ? AriaPlayObservationKind.WorldTarget : AriaPlayObservationKind.Control;
            output.TargetId = target.Id; output.Position = target.Position;
            output.Drag = target.Drag ? (byte)1 : (byte)0;
            output.DragEnd = target.DragEnd;
            output.ScrollTargetId = target.ScrollTargetId;
            output.ScrollDistanceViewports = target.ScrollDistanceViewports;
        }
    }
}
