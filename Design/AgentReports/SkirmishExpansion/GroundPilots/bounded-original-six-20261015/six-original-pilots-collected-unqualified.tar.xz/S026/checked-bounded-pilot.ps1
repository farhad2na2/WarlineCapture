﻿param($ProjectPath,$UnityExe,$LogFile,$RawOutput,$CatalogId,$Marker,$TimeoutSeconds)
$ErrorActionPreference='Stop'
$env:WARLINE_MATERIALIZED_PILOT_ID=$CatalogId
$env:WARLINE_MATERIALIZED_PILOT_OUTPUT=$RawOutput
$ownedExit=1
try {
 & (Join-Path $ProjectPath 'Tools/CI/InvokeUnityExecuteMethodValidation.ps1') -UnityExe $UnityExe -ProjectPath $ProjectPath -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.RunBoundedMaterializedPilot' -LogFile $LogFile -RequiredPassMarker $Marker -GuiLicensing -TimeoutSeconds $TimeoutSeconds
 if($global:LASTEXITCODE -ne 0){throw 'Checked bounded pilot returned nonzero'}
 $ownedExit=0
} catch {[Console]::Error.WriteLine($_.ToString())}
finally {[IO.File]::WriteAllText((Join-Path (Split-Path -Parent $LogFile) 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
