from pathlib import Path
import ast, difflib, hashlib, json, re, shutil

ROOT = Path('/Users/farhad/Projects/WarlineCapture')
REPORT = ROOT / 'Design/AgentReports/SkirmishExpansion/S005'
BASE = Path('/private/tmp/s005-repaired-aria-matrix1263-1268')
OLD = Path('/private/tmp/s005-current-aria-matrix-prep')
FULL = REPORT / 'final-1262-normal-manual-r2-recovery-pre-dispatch-source-manifest.json'
FP = FULL.with_name(FULL.name.replace('-source-manifest.json', '-independent-fingerprint.json'))
SOURCE = '60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
snapshot = json.loads(FULL.read_text())
assert json.loads(FP.read_text())['sourceHash'] == SOURCE
menu = (ROOT/'Assets/Game/Scripts/Editor/Skirmish/SkirmishS002AriaRunHarness.MenuProbe.cs').read_text()
failure = REPORT/'native1253-normal-aria-failure.json'
failed = json.loads(failure.read_text())
failedtrace = REPORT/failed['trace']
failedtouch = failedtrace.with_name(failedtrace.name+'.touch.jsonl')
assert any(json.loads(l).get('kind')=='PhysicalTakeover' for l in failedtouch.read_text().splitlines() if l.strip())
preserved = BASE/'preserved-lineage'
assert not preserved.exists()
preserved.mkdir()
for p in (FULL, FP, failure, failedtouch, REPORT/failed['log']):
    shutil.copy2(p, preserved/p.name)

physical_guard = '''def verify_aria_no_physical_takeover(log_text, touch_rows):
 if '[AriaTouchInput] physicalTakeover' in log_text or 'ariaStopped:Manual' in log_text:
  raise ValueError('Physical input takeover/Manual abort cannot qualify an ARIA baseline')
 if not touch_rows or any(row.get('kind')=='PhysicalTakeover' or any(row.get(key)!=0 for key in ('unexpected','interventions','receiptViolations')) for row in touch_rows):
  raise ValueError('Every ARIA native Touch row must have zero unexpected/interventions/receipt violations and no physical takeover')
'''
plans=[]
for old in range(1250,1256):
    new=old+13
    for p in REPORT.iterdir():
        assert not re.match(r'(?:native-?'+str(new)+r'[-.]|load'+str(new)+r'[-.]|final-'+str(new)+r'-|compile'+str(new)+r'-)',p.name), 'Destination collision '+p.name
    original=OLD/str(old)
    dest=BASE/str(new)
    assert not dest.exists()
    dest.mkdir()
    oldprep=json.loads((original/'manifest.json').read_text())
    srcfixture=original/f'S005NormalAria{old}Observer.cs'
    srcrunner=original/f's005-run-normal-aria-{old}.py'
    lineage=preserved/str(old)
    lineage.mkdir()
    for p in (srcfixture,srcrunner,original/'manifest.json'):
        shutil.copy2(p,lineage/p.name)
    fixture=dest/f'S005NormalAria{new}Observer.cs'
    runner=dest/f's005-run-normal-aria-{new}.py'
    prepfile=dest/'manifest.json'
    cs=srcfixture.read_text().replace(str(old),str(new))
    fixture.write_text(cs)
    normalized=cs.replace(str(new),str(old))
    assert normalized==srcfixture.read_text()
    entry=oldprep['publicEntry'].split('.')[-1]
    assert re.search(r'public static void '+entry+r'\(\)',menu)
    assert 'SkirmishS002AriaRunHarness.'+entry+'();' in cs
    py=srcrunner.read_text().replace(str(old),str(new))
    py=py.replace(str(OLD/str(new)),str(dest))
    assert py.count('def native_idle(tag):')==1
    py=py.replace('def native_idle(tag):',physical_guard+'\ndef native_idle(tag):')
    anchor=" if not rawtouch or any(any(row.get(k)!=0 for k in ('unexpected','interventions','receiptViolations')) for row in rawtouch):errors.append('Every actual raw Touch row must retain zero unexpected/interventions/receipt violations')"
    assert py.count(anchor)==1
    py=py.replace(anchor,anchor+'\n verify_aria_no_physical_takeover(text,rawtouch)')
    # Preserve inherited complete raw-row gate; explicit takeover guard only strengthens it.
    ast.parse(py)
    runner.write_text(py)
    contracts={name:sha(ROOT/name) for name in oldprep['sourceContracts']}
    repairs=['Assets/Game/Scripts/Systems/TransportBoardingCommandDisembarkApplication.cs',
             'Assets/Game/Scripts/Systems/UnitDeathSystem.cs',
             'Assets/Tests/Editor/SkirmishExpansion/SkirmishGroundCarrierDeathTests.cs',
             'Assets/Tests/Editor/SkirmishExpansion/SkirmishGroundCarrierDeathTests.cs.meta']
    for name in repairs:
        contracts[name]=sha(ROOT/name)
    for name,digest in contracts.items():
        if name in snapshot['files']:
            assert snapshot['files'][name]==digest, 'Actual source differs from approved manifest '+name
    m=dict(oldprep)
    m.update(runId=new,status='PreparedRootReviewUniqueNativeDryCompileAndExclusiveReleaseRequired',
        fixture=str(fixture),fixtureSha256=sha(fixture),runner=str(runner),runnerSha256=sha(runner),
        entry=f'S005NormalAria{new}Observer.RunValidation',loadOnlyEntry=f'S005NormalAria{new}Observer.Run',
        currentCandidateSourceHash=SOURCE,expectedFullSourceManifest=FULL.name,expectedFullSourceManifestSha256=sha(FULL),
        sourceContracts=contracts,nativeExecuted=False,nativeCompiled=False,playerReady=False,
        predecessor={'runId':old,'fixtureSha256':sha(srcfixture),'runnerSha256':sha(srcrunner),'preparedSha256':sha(original/'manifest.json'),'sourceHash':oldprep['currentCandidateSourceHash'],'qualificationNotTransferred':True},
        observerChange='Only unique ID strings; strict actual rendered binding, normal flags, Victory/result→AdjustSetup gates unchanged.',
        runnerChanges=['Only unique IDs/preparation paths and new candidate/repair source pins','Explicit log/raw PhysicalTakeover and Manual-abort rejection added; inherited all-row zero-interventions gate retained'],
        physicalInputRule='No physical Mouse/keyboard/touch takeover during ARIA. Preserve native physical takeover behavior; any such evidence fails qualification. Operator must leave native lane untouched; do not disable physical input in game.',
        preservedFailure={'report':failure.name,'reportSha256':sha(failure),'rawTouch':failedtouch.name,'rawTouchSha256':sha(failedtouch),'originalSource':failed['sourceHash'],'actualWrapperExit':failed['actualWrapperExit'],'actualNativeExit':failed['nativeBridgeExit'],'cause':'Actual PhysicalTakeover device=Mouse and ariaStopped:Manual; no pass claimed.'})
    m['compileInstruction']=f'rtk proxy unity command run_script --file {fixture} --entry S005NormalAria{new}Observer.Run --dry_run true --timeout_ms 30000 --project-path {ROOT} --format json'
    m['runInstruction']=f'rtk proxy python3 {runner} {FULL.name} --dry-compile-proof {REPORT}/compile{new}-normal-aria-reviewed-dry-run.json --heavy-lane-owner main{new}'
    prepfile.write_text(json.dumps(m,indent=2)+'\n')
    (dest/'fixture-normalized-clone-diff.patch').write_text(''.join(difflib.unified_diff(srcfixture.read_text().splitlines(True),normalized.splitlines(True),fromfile='predecessor',tofile='new-ID-normalized')))
    (dest/'runner-normalized-review.diff').write_text(''.join(difflib.unified_diff(srcrunner.read_text().splitlines(True),py.replace(str(new),str(old)).splitlines(True),fromfile='predecessor',tofile='new-ID-normalized')))
    plans.append({'id':new,'locale':m['normalDefaults']['locale'],'seed':m['normalDefaults']['seed'],'publicEntry':m['publicEntry'],'fixture':str(fixture),'fixtureSha256':sha(fixture),'runner':str(runner),'runnerSha256':sha(runner),'prep':str(prepfile),'prepSha256':sha(prepfile),'contracts':len(contracts),'fixtureNormalizedDiffEmpty':True,'compileInstruction':m['compileInstruction'],'runInstruction':m['runInstruction']})
(BASE/'matrix-manifest.json').write_text(json.dumps({'candidateHash':SOURCE,'candidateManifest':FULL.name,'candidateManifestSha256':sha(FULL),'sourceFiles':json.loads(FP.read_text())['sourceFiles'],'sourceBytes':json.loads(FP.read_text())['sourceBytes'],'runs':plans,'executionPerformed':False,'physicalInputTakeoverProhibitedForQualification':True,'nativePhysicalTakeoverPolicyChanged':False,'preserved1253Failure':{'path':str(failure),'sha256':sha(failure)},'gaps':['Root review and actual unique native drycompile for six external classes','Explicit exclusive release after active native1262 closes','Six independent native Victory/result/return closures with wrapper/native0, zero intervention raw Touch and whole-source equality','Any later source change requires repinning and review; old wins remain historical','Visual direction/human-device/performance and remaining manual gates are separate']},indent=2)+'\n')
print(json.dumps({'matrix':str(BASE/'matrix-manifest.json'),'sha256':sha(BASE/'matrix-manifest.json'),'runs':[{k:v for k,v in row.items() if k in ('id','locale','seed','contracts')} for row in plans]},indent=2))
