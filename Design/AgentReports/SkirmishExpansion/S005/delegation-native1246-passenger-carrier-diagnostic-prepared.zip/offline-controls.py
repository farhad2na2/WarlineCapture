import copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
R=pathlib.Path('/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005')
def load(name):
 s=importlib.util.spec_from_file_location(name,P/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
fog=load('manual-fog-fallback-qualifier');paid=load('paid-recovery-qualifier');checks=[]
def check(name,fn,passed):
 try:fn();actual=True
 except (ValueError,KeyError,IndexError,TypeError):actual=False
 assert actual==passed,(name,actual,passed)
 checks.append({'name':name,'expectedAccepted':passed,'actualAccepted':actual})
for run in (1235,1243):
 rows=[json.loads(l) for l in (R/f'native{run}-manual-fog-fallback.jsonl').read_text().splitlines()]
 check(f'original{run} failure remains rejected',lambda rows=rows:fog.qualify(rows,[],rows[0]['attempt']),False)
def row(stage,r=1,**extra):
 d=dict(stage=stage,round=r,attempt='attempt',candidate=0,timeScale=1,frame=1);d.update(extra);return d
rows=[row('Protocol',0)]
for r in (1,2):
 rows += [row('LeaseStarted',r,sameDriver=True,markerVisible=False,targetVisible=False,reason='WaitingForUnavailablePublicTarget',members=1,originalDue=3,enemyObjectiveX=100,enemyObjectiveZ=0,playerObjectiveX=0,playerObjectiveZ=0),row('GroundTouch',r,goalX=88,goalZ=-6,safeArea=True,noUiHit=True),row('NativeReceipt',r,operation='AttackMove',receipt=r,verified=True,frame=2),row('NativeReceiptAlias',r,operation='ArmyAttack',receipt=r,verified=True,reason='PairedSameFrameAttackMoveScope',frame=2),row('AdvanceAccepted',r,goalX=88,goalZ=-6,receipt=r,frame=3),row('Actor',r,id='actor',elapsed=1,x=6,z=0,startX=0,startZ=0,displacement=6,speed=5,alive=True,selected=True,markerVisible=True,targetVisible=True,receipt=r,frame=4)]
 if r==1:rows += [row('NaturalVisibility',r,markerVisible=True,targetVisible=True,receipt=r,frame=4),row('LeaseRestored',r,sameDriver=True,originalDue=3,restoredExact=True,reason='NaturalVisibleMarkerThenUnchangedManualAttack',frame=5)]
 else:rows += [row('TerminalClosure',r,originalDue=3,restoredExact=True,reason='VerifiedNativeFrozenVictory',nativeFinished=True,nativeVictory=True,resultFrozen=True,oldBusy=False,oldCompleted=4,oldDispatched=4,frame=5,timeScale=0)]
rows += [row('Closed',0,restoredExact=True,sameDriver=False)]
commands=[dict(frame=2,receipt=r,operation=op,verified=True) for r in (1,2) for op in ('AttackMove','ArmyAttack')]
terminal=dict(renderedVictoryPassed=True,sameAttemptReturnPassed=True,strictContactAudit=True)
def fq(rs=rows,cs=commands,tp=terminal):return fog.qualify(rs,cs,'attempt',True,terminal_proof=tp)
check('paired alias and terminal following natural visibility accepted',fq,True)
for key,val in [('frame',9),('receipt',9),('verified',False),('candidate',2)]:
 rs=copy.deepcopy(rows);next(r for r in rs if r['stage']=='NativeReceiptAlias')[key]=val
 check('alias invalid '+key,lambda rs=rs:fq(rs),False)
for key in terminal:
 tp=dict(terminal);tp[key]=False;check('terminal missing '+key,lambda tp=tp:fq(tp=tp),False)
rs=copy.deepcopy(rows);next(r for r in rs if r['stage']=='TerminalClosure')['oldBusy']=True;check('terminal busy',lambda:fq(rs),False)
rs=[r for r in copy.deepcopy(rows) if r['round']!=1 or r['stage'] not in ('NaturalVisibility','LeaseRestored')]
rs.insert(-1,row('TerminalClosure',1,originalDue=3,restoredExact=True,reason='VerifiedNativeFrozenVictory',nativeFinished=True,nativeVictory=True,resultFrozen=True,oldBusy=False,oldCompleted=4,oldDispatched=4,frame=5,timeScale=0))
# Keep ordered restores and valid round sequence, only no successful natural observation.
rs.sort(key=lambda r:(r['round'] if r['round'] else (0 if r['stage']=='Protocol' else 3),r['frame']))
check('terminal without natural visibility',lambda:fq(rs),False)
facts=dict(reservation=10,faction=1,role='ApcHeavy',producer='home',materialsPaid=280,members=1,deliveredMembers=1,supplyCost=6,actorStableId='paid',attempt='attempt')
def pr(stage,**kw):d=dict(facts,stage=stage);d.update(kw);return d
runtime=lambda **kw:dict(stage='NativeManualRuntime',reservation=10,actorCount=1,actorHealth=360,actorStableId='paid',recoveredNativeComplete=False,paused=False,elapsed=1,**kw)
base=[runtime(),dict(runtime(),elapsed=5,paused=True),pr('NativeSavedPaidReceipt',phase='Live',remainingMembers=1,paused=True,elapsed=5),pr('NativePaidReceiptState',phase='Live',remainingMembers=1,recoveredNativeComplete=False,elapsed=1),pr('NativePaidReceiptState',phase='Live',remainingMembers=1,recoveredNativeComplete=True,elapsed=6)]
snap=dict(Actors=[dict(Id='paid')]);purchase=dict(reservation=10,producer='home',materialsPaid=280);restored=dict(attempt='attempt',runtimeReadiness='Established',elapsed=6,reservation=10,actorStableId='paid',actorCount=1,actorHealth=360);binding=dict(attempt='attempt');cp=dict(savedElapsed=5)
def pq(rs=base,ss=snap,rr=restored):return paid.qualify(rs,ss,purchase,rr,binding,cp)
check('live recovery accepted',pq,True)
check('live saved actor missing',lambda:pq(ss={'Actors':[]}),False)
rr=dict(restored,actorStableId='wrong');check('live restored identity changed',lambda:pq(rr=rr),False)
cas=copy.deepcopy(base);cas[1].update(actorCount=0,actorHealth=0,actorStableId='',reservation=0)
cas[2].update(phase='Released',remainingMembers=0);cas[4].update(phase='Released',remainingMembers=0)
cas.insert(1,pr('NativePaidReceiptState',phase='Released',remainingMembers=0,recoveredNativeComplete=False,elapsed=3))
cas += [dict(runtime(),recoveredNativeComplete=True,elapsed=6,actorCount=0,actorHealth=0,actorStableId='',reservation=0),pr('NativePaidActorState',elapsed=3,actorHealth=0,capacityReleased=1)]
rr=dict(restored,actorCount=0,actorStableId='',reservation=0,actorHealth=0)
def cq(rs=cas,ss={'Actors':[]},rec=rr):return pq(rs,ss,rec)
check('casualty accepted and never counts live recovery',lambda: (cq() if not cq()['countsForLivePaidActorRecovery'] else (_ for _ in ()).throw(ValueError())),True)
check('dead actor checkpoint presence',lambda:cq(ss=snap),False)
rs=copy.deepcopy(cas);rs[-2].update(actorCount=1,actorStableId='paid',reservation=10);check('dead actor resurrection',lambda:cq(rs),False)
rs=copy.deepcopy(cas);next(r for r in rs if r['stage']=='NativePaidReceiptState' and r['recoveredNativeComplete'])['phase']='Live';check('receipt revival',lambda:cq(rs),False)
rs=copy.deepcopy(cas);next(r for r in rs if r['stage']=='NativeSavedPaidReceipt')['materialsPaid']=0;check('cost lost',lambda:cq(rs),False)
rs=copy.deepcopy(cas);next(r for r in rs if r['stage']=='NativePaidReceiptState' and r['phase']=='Released' and not r['recoveredNativeComplete'])['elapsed']=7;check('casualty only after save',lambda:cq(rs),False)
assert len(checks)==21,len(checks)
with (P/'offline-parser-controls.json').open('x') as f:json.dump({'scope':'Synthetic parser controls only; no Unity1246 execution; original1235/1243 failures unchanged','count':len(checks),'checks':checks},f,indent=2);f.write('\n')
print('PASS21 offline parser controls; no Unity invocation')
