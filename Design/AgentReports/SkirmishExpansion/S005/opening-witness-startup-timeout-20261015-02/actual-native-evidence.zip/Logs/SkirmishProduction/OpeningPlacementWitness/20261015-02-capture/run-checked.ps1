$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\OpeningPlacementWitness\20261015-02-capture'
$ownedExit=1
try {
    if(-not (Test-Path -LiteralPath (Join-Path $run 'source-before.json') -PathType Leaf)){throw 'Post-warmup complete source/DLL snapshot required'}
    $env:WARLINE_S005_OPENING_GROUP_OUTPUT=Join-Path $run 'opening-placement-witness.jsonl'
    $env:WARLINE_S005_EXIT_DIAGNOSTIC_OUTPUT=Join-Path $run 'startup-exit.jsonl'
    $env:WARLINE_ARIA_BACKGROUND_VALIDATION='1'
    $env:WARLINE_SKIRMISH_STARTUP_ONLY=$null
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    $arguments=@('-buildTarget','Android','-warlineProfilerMarkers','-executeMethod','Game.Editor.SkirmishS002AriaRunHarness.RunS005OpeningPlacementWitnessDiagnostic')
    & (Join-Path $project 'Tools\CI\InvokeUnity.ps1') -UnityExe $unity -ProjectPath $project -LogFile (Join-Path $run 'unity.log') -NoProcessExit -GuiLicensing -TimeoutSeconds 900 -UnityArguments $arguments
    if($LASTEXITCODE -ne 0){throw 'Checked opening placement/profiler capture failed'}
    $log=[IO.File]::ReadAllText((Join-Path $run 'unity.log'))
    $required=@(
        '[S005OpeningPlacementWitness] result=CapturedUnqualified views=4 geometryOnly=1 placementAccepted=0 occlusionAccepted=0 wrapperExitStillRequired=1',
        '[S005MeasuredOpeningCandidates] result=CapturedUnqualified views=4 profileChanged=0 commandsIssued=0 selectionChanged=0 runtimeGateAtQuitRequired=1',
        '[S005MeasuredOpeningRuntimeGate] result=Passed errors=0 viewsCompleted=4 wrapperExitStillRequired=1',
        '[S005StartupExitDiagnostic] result=ObservedStartupAndEditMode diagnosticOnly=1 wrapperExitStillRequired=1',
        '[SkirmishS003Startup] result=Passed reason=sharedStartupDiagnostic'
    )
    foreach($marker in $required){if(-not $log.Contains($marker)){throw "Missing required witness marker: $marker"}}
    if($log.Contains('result=Failed')){throw 'Witness log contains failure marker'}
    $ownedExit=0
}catch{[Console]::Error.WriteLine($_.ToString())}
finally{[IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
