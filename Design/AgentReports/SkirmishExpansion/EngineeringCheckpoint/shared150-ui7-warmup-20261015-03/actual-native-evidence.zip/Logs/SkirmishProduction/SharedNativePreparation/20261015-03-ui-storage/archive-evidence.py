from pathlib import Path
import hashlib,json,zipfile
root=Path.cwd();run=root/'Logs/SkirmishProduction/SharedNativePreparation/20261015-03-ui-storage'
assert (run/'checked-child-exit.txt').read_text()=='0'
facts=json.loads((run/'ACTUAL_NATIVE_RESULT.json').read_text())
snapshot=json.loads((run/'post-wrapper-source-and-dll.json').read_text())
target=root/'Design/AgentReports/SkirmishExpansion/EngineeringCheckpoint/shared150-ui7-warmup-20261015-03'
target.mkdir(parents=True,exist_ok=True);archive=target/'actual-native-evidence.zip'
cachefiles=[r for r in snapshot['source_manifest'] if r['path'].startswith('Assets/SceneDependencyCache/')]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(run.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(root).as_posix())
    for row in cachefiles:
        p=root/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];z.write(p,row['path'])
receipt={'archive':archive.relative_to(root).as_posix(),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'wrapperExit':0,'requiredMarkersVerified':18,'sharedControls':150,'actualFullUiRootControls':7,'warmupScenes':2,'sourceFiles':len(snapshot['source_manifest']),'candidateSha256':snapshot['candidate_sha256'],'buildSha256':snapshot['build_sha256'],'cameraAccepted':False,'normalMissionReady':False,'interpretation':'Engineering controls and post-wrapper source/DLL snapshot; actual normal runtime and camera evidence follow separately'}
(target/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
