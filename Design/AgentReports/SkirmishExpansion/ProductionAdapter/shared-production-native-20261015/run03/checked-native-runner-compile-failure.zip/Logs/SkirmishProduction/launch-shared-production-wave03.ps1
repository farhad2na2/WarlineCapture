$ErrorActionPreference = 'Stop'
$env:WARLINE_GROUND_SOURCE_SURVEY_OUTPUT = 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/ground-source-fit-20261015-05.json'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:/Projects/WarlineCapture/Tools/CI/InvokeUnityExecuteMethodValidation.ps1' -UnityExe 'D:/Program Files/Unity/6000.5.2f1/Editor/Unity.exe' -ProjectPath 'D:/Projects/WarlineCapture' -ExecuteMethod 'Game.Tests.Editor.SkirmishSharedProductionWaveValidation.PrepareLogicalAssetsAndRunFocusedValidation' -LogFile 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/shared-production-wave-20261015-03.log' -RequiredPassMarker '[SkirmishSharedProductionWaveValidation] result=Passed objectiveWave=128 repair=55 enemyRepair=9 publicHud=13 unload=11 repairHud=15 posedMesh=11 framing=7 normalZoom=3 normalTouch=30 pagingReceipt=9 sourceSurvey=4 normalMissionReadiness=Pending' -TimeoutSeconds 1200 -GuiLicensing
$taskExit = $LASTEXITCODE
Set-Content -LiteralPath 'D:/Projects/WarlineCapture/Logs/SkirmishProduction/shared-production-wave-20261015-03.wrapper-exit.txt' -Value $taskExit
exit $taskExit
