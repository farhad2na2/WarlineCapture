$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\SharedNativePreparation\20261015-04-legacy-logical-witness'
$ownedExit=1
try {
    if(-not (Test-Path -LiteralPath (Join-Path $run 'IMPORT_RECEIPT.json'))){throw 'Reviewed coherent import receipt required'}
    $env:WARLINE_S005_SCENE_WARMUP_OUTPUT=Join-Path $run 'scene-warmup.json'
    $required=@(
        '[SkirmishLegacyProductionControls] result=Passed presets=3 ordinaryQueues=3 identityMutations=15 savedResultMutations=7 nativeJobs=0 samplingCoverageCredit=0',
        '[BoundedLogicalFrameControls] result=Passed controls=6 frameCandidates=4 physicalSourceChanged=0 sourceFitCertified=0',
        '[PilotStaticPlacementPrefixControls] result=Passed controls=6 rectangleComparisons=900 nativeSearchParity=1 sourceFitCertified=0',
        '[S005OpeningPlacementWitnessPreparation] result=Passed original=11 measured=3 witness=4 warmup=1 gameplayCertified=0',
        '[S005SceneArtifactWarmup] result=Passed scenes=2 keySource=NativeEditorSceneSystem defaultWorldPreserved=1 playStarted=0 missionCertified=0 snapshotAfterWrapperExit=1',
        '[LegacyAndOpeningWitnessPreparation] result=Passed legacyPresets=3 logicalFrameControls=6 prefixControls=6 openingControls=18 warmup=1 nativeJobs=0 samplingCoverageCredit=0'
    )
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    & (Join-Path $project 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unity -ProjectPath $project -ExecuteMethod 'Game.Editor.SkirmishLegacyProductionControls.RunLegacyAndOpeningWitnessPreparation' -LogFile (Join-Path $run 'unity.log') -RequiredPassMarker $required[-1] -BuildTarget Android -GuiLicensing -TimeoutSeconds 900
    if($LASTEXITCODE -ne 0){throw 'Checked coherent engineering preparation failed'}
    $log=[IO.File]::ReadAllText((Join-Path $run 'unity.log'))
    foreach($marker in $required){if(-not $log.Contains($marker)){throw "Missing marker: $marker"}}
    if(-not $log.Contains('[UnityInvoke] ExitCode: 0')){throw 'Actual wrapper exit0 absent'}
    if($log.Contains('result=Failed')){throw 'Preparation has failed marker'}
    $ownedExit=0
}catch{[Console]::Error.WriteLine($_.ToString())}
finally{[IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
