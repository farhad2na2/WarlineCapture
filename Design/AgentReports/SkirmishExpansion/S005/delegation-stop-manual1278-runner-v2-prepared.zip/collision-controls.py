"""Pure offline collision oracle controls; no Unity/native calls."""
import ast,hashlib,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('runner_v2',P/'runner.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
report=m.REPORT;approved=report/'compile1278-stop-manual-reviewed-dry-run.json'
cases=[]
def check(name,files,expected):
 actual=m.artifact_collisions([report/f for f in files],approved)
 assert actual==expected,(name,actual,expected)
 cases.append({'name':name,'collisions':actual,'expected':expected})
check('allow only exact approved dry proof',[approved.name],[])
for name in ['compile1278-other.json','compile1278-stop-manual-reviewed-dry-run.json.stderr.json','load1278-stop-manual.json','native1278-runner-start.json','native-1278-normal-stop-manual-en155926.log','final-1278-normal-stop-preflight-source-manifest.json','native1278-unclosed-ownership.json']:
 check('reject preserved '+name,[approved.name,name],[name])
check('ignore unrelated runs',['native1279-pass.json',approved.name],[])
assert m.artifact_collisions([pathlib.Path('/private/tmp')/approved.name],approved)==[approved.name]
cases.append({'name':'same basename at different path is not exempt','passed':True})
prep=json.loads((P/'prepared.json').read_text())
assert str(approved)==prep['approvedDryProofPath'] and m.sha(approved)==prep['approvedDryProofSha256']
assert m.sha(m.FIXTURE)==prep['fixtureSha256'] and m.sha(m.IDLE)==prep['originalIdleHelperSha256']
for file in P.glob('*.py'):ast.parse(file.read_text(),filename=str(file))
output=P/'collision-controls-results.json'
with output.open('x') as f:json.dump({'result':'Passed','controls':len(cases),'cases':cases,'currentReportCollisions':m.artifact_collisions(report.iterdir(),approved),'sourceOrNativeCalls':False},f,indent=2);f.write('\n')
print(json.dumps({'result':'Passed','controls':len(cases),'currentReportCollisions':m.artifact_collisions(report.iterdir(),approved)}))
