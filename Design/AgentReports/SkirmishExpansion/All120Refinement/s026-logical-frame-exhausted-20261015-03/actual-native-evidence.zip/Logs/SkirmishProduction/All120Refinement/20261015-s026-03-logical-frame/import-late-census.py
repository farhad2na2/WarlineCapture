import hashlib
import json
from pathlib import Path

root = Path.cwd()
run = root / 'Logs/SkirmishProduction/All120Refinement/20261015-s026-03-logical-frame'
folder = root / 'Tools/CI/SkirmishProductionDrafts/LateEcsRecorderCensus'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pins = {
    folder/'manifest.json': '5c54f24413331dab552c5f2add662cea628dac3cb8fce1d05ba2352f5227e26c',
    folder/'META_SUPPLEMENT.json': '7b63d4a1ab00cd85e91f9acb974e1b0340e9f07662f0afb61c7610505af71b56',
    folder/'INDEPENDENT_SOURCE_REVIEW.json': '9ca0644864e2f5e2c0dc0557b6e14eb484209017f4d5e8892883a1798b688b7b',
    folder/'INDEPENDENT_META_AND_PROOF_REVIEW.json': 'a6d21d424a106ca295c76c8e69f3d37723bf157112fe24aa93c0699d0191f73f',
    root/'Logs/SkirmishProduction/Offline/late-ecs-5ea4p5ng/result.json': '478326206245b3a26fc421806fbefba268d79be7c3e42d07554600096e6d276b'
}
for p, expected in pins.items():
    assert sha(p) == expected, p
rows = []
for name in ['manifest.json', 'META_SUPPLEMENT.json']:
    rows.extend(json.loads((folder/name).read_text(encoding='utf-8-sig'))['files'])
assert len(rows) == 2
for row in rows:
    assert row['before_sha256'] is None
    assert not (root / row['target']).exists()
    assert sha(root / row['source']) == row['sha256']
for row in rows:
    target = root / row['target']
    with target.open('xb') as stream:
        stream.write((root / row['source']).read_bytes())
    assert sha(target) == row['sha256']
(run/'LATE_CENSUS_IMPORT.json').write_text(json.dumps(dict(status='ImportedExactReviewedTwoNewEditorFiles', pins={p.relative_to(root).as_posix(): s for p,s in pins.items()}, files=rows, nativePending=True, nextEngineeringRunExpectedEditorCompilation=True, gameplayChanged=False), indent=2)+'\n', encoding='utf-8')
print('[LateCensusImport] result=Passed files=2 nativePending=1 gameplayChanged=0')
