import copy,importlib.util,json,pathlib,ast
P=pathlib.Path(__file__).parent
s=importlib.util.spec_from_file_location('qualifier',P/'qualifier.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
checks=[]
def check(name,fn,expected):
 try:fn();actual=True
 except (ValueError,KeyError,IndexError,TypeError):actual=False
 assert actual==expected,(name,actual,expected)
 checks.append({'name':name,'accepted':actual,'expectedAccepted':expected})
def row(stage,frame,**fields):
 r=dict(stage=stage,frame=frame,attempt='attempt',timeScale=1,elapsed=frame/10,step=0,moveNumber=1);r.update(fields);return r
rows=[row('Protocol',0,attempt=''),row('StopDispatched',10,owner='WatchAriaPlay',active=True,oldRunning=True,oldBusy=False,pressed=False,gestureRequested=False,dueMargin=.8,stopBefore=0,completed=10,commands=1),row('AcceptedOrderBeforeStop',10,groupId=10,order='Attack'),row('AcceptedOrderAfterStop',12,groupId=10,order='Attack'),row('StopVerified',12,active=False,oldRunning=False,oldBusy=False,stopBefore=0,stopAfter=1,completed=11,dispatched=11,commands=1,auditMeasured=True,violations=0,unexpected=0,interventions=0),row('ManualOwnershipHandoff',13,qaOnly=True,sameAttempt=True),row('SelectedWholeCohort',14,groupId=10,members=4,allAlive=True,sameAttempt=True)]
def actor(id,frame,n,hold=False):
 return row('Actor',frame,moveNumber=n,id=id,groupId=10,role='Rifle',allAlive=True,allHeld=hold,oldIntentCleared=hold,receipt=2 if n==1 else 4,receiptFrame=20 if n==1 else 36,x=3,y=0,z=0,qx=0,qy=0,qz=0,qw=1,scale=1,startX=0,startZ=0,displacement=3)
def move(n,g,t,a,m,distance,side):
 rs=[row('PublicMoveGoal',g,moveNumber=n,groupId=10,enemyX=100,enemyZ=0,playerX=0,playerZ=0,x=0,z=0,goalX=distance,goalZ=-side),row('NativeMoveTerrainTouch',t,moveNumber=n,groupId=10,safeArea=True,noUiHit=True),row('MoveAccepted',a,moveNumber=n,groupId=10,receipt=2 if n==1 else 4,receiptFrame=a)]
 rs.extend(actor('rifle'+str(i),m,n) for i in range(4));rs.append(row('MoveVerified',m,moveNumber=n,groupId=10,receipt=2 if n==1 else 4,members=4,allMoved=True));return rs
rows+=move(1,15,19,20,22,18,6)
rows += [row('HoldTouchDispatched',23,owner='HoldButton',completed=5),row('HoldNativeEnded',24,owner='HoldButton',completed=6,dispatched=6,unexpected=0,interventions=0)]
rows += [actor('rifle'+str(i),24,1,True) for i in range(4)]
rows += [row('HoldVerified',24,groupId=10,members=4,allHeld=True,oldIntentCleared=True,receipt=0,receiptFrame=24),row('PauseOwnershipHandoff',24,qaOnly=True,sameAttempt=True)]
rows += [actor('rifle'+str(i),25,1,True) for i in range(4)]
rows += [row('PausedSnapshot',25,elapsed=2.5,pausedElapsed=2.5,timeScale=0)]
rows += [dict(actor('rifle'+str(i),27,1,True),elapsed=2.5,timeScale=0) for i in range(4)]
rows += [row('PausedConserved',27,elapsed=2.5,pausedElapsed=2.5,pausedWallSeconds=1,timeScale=0,clockConserved=True,poseConserved=True,allHeld=True),row('PauseOwnerRestored',30,qaOnly=True,sameAttempt=True,restoredExact=True),row('HoldNoResurrection',33,elapsed=5,pausedElapsed=3,allHeld=True,oldIntentCleared=True,noOldOrderResurrection=True,normalSpeed=True)]
rows+=move(2,34,35,36,38,12,-6)
rows += [row('ControlsPassed',39,auditMeasured=True,violations=0,completed=12,dispatched=12,unexpected=0,interventions=0),row('ManualOwnerRestored',40,qaOnly=True,sameAttempt=True,restoredExact=True),row('Closed',45,controlsPassed=True,restoredExact=True)]
commands=[dict(operation='AttackMove',frame=5,receipt=1,verified=True),dict(operation='Move',frame=20,receipt=2,verified=True),dict(operation='Move',frame=36,receipt=4,verified=True)]
def qualify(rs=rows,cs=commands):return q.qualify_controls(rs,cs,'attempt')
check('full native controls schema accepted',qualify,True)
for stage,key,value in [('StopDispatched','oldBusy',True),('StopDispatched','dueMargin',.2),('StopVerified','stopAfter',0),('StopVerified','commands',2),('StopVerified','interventions',1),('AcceptedOrderAfterStop','order','Hold'),('SelectedWholeCohort','sameAttempt',False),('MoveAccepted','receipt',0),('MoveVerified','allMoved',False),('HoldVerified','oldIntentCleared',False),('HoldNativeEnded','completed',99),('HoldVerified','receipt',999),('PausedConserved','poseConserved',False),('HoldNoResurrection','elapsed',3.2),('PauseOwnerRestored','restoredExact',False),('ManualOwnerRestored','restoredExact',False),('ControlsPassed','violations',1),('Closed','restoredExact',False)]:
 rs=copy.deepcopy(rows);next(r for r in rs if r['stage']==stage)[key]=value;check(stage+'/'+key,lambda rs=rs:qualify(rs),False)
rs=copy.deepcopy(rows);next(r for r in rs if r['stage']=='Actor' and r['moveNumber']==2)['id']='replacement';check('same cohort replacement rejected',lambda:qualify(rs),False)
rs=copy.deepcopy(rows);next(r for r in rs if r['stage']=='Actor' and r['frame']==27)['qx']=.1;check('raw native paused quaternion change rejected',lambda:qualify(rs),False)
rs=copy.deepcopy(rows);next(r for r in rs if r['stage']=='PublicMoveGoal')['goalX']=999;check('hidden alternative move goal rejected',lambda:qualify(rs),False)
cs=copy.deepcopy(commands);cs[1]['verified']=False;check('unverified actual native Move receipt rejected',lambda:qualify(cs=cs),False)
check('empty controls failed without index exception',lambda:q.qualify_controls([],[],'attempt'),False)
check('empty visual proof failed without index exception',lambda:q.qualify_visual([],'attempt'),False)
visual=[dict(stage='NativeBoundText',role=role,exactBoundReference=True,samplingPhase='CanvasWillRenderCanvases',activeText=True,culledText=False,textAlpha=1,ancestorAlpha=1,visibleGlyphs=5,safeAreaOverlap=True,renderedBody=True) for role in ('SetupTitle','SetupObjective','HudPurposeTitle','HudPurposeBody','PlayerBaseCaption','EnemyBaseCaption','CurrentMatchClock','AriaControl','ResultText','MainMenuSkirmishControl')]
visual += [dict(stage='RenderedViewportContext',nativeViewportMatched=True,canvasWidth=2400,screenWidth=2400,canvasHeight=1080,screenHeight=1080),dict(stage='NativeAriaControl',ariaActive=True,localizedStopCopy=True,presentedControl=True,renderedBody=True),dict(stage='NativeAriaControl',ariaActive=False,presentedControl=True,renderedBody=True),dict(stage='NativeObjectiveStrip',finished=False,renderedPlayerBase=True,renderedEnemyBase=True,renderedClock=True,exactPlayerBinding=True,exactEnemyBinding=True,exactClockBinding=True,clockNumberPresentAndCurrent=True,expectedPlayerCaption='YOUR BASE',expectedEnemyCaption='ENEMY BASE',modelClockNumber='10:00',nativeClockNumber='10:00'),dict(stage='NativeSetupBriefing',seed=155926,renderedTitle=True,renderedObjective=True,localizedObjectiveCopy=True),dict(stage='NativeHudPurpose',renderedTitle=True,renderedBody=True,localizedPurposeCopy=True),dict(stage='NativeRenderedResultText',frame=100,finished=True,frozenVictory=True,renderedTitle=True,renderedVictoryWitnessed=True,outcome='Victory',attempt='attempt',title='VICTORY'),dict(stage='NativeMainMenuDestination',frame=110,attempt='attempt',shellRoute='MainMenu',outcome='Victory',finished=True,frozenVictory=True,renderedVictoryWitnessed=True,presentedControl=True,renderedBody=True,unobscuredDestination=True,destinationSessionAbsent=True,exactMainMenuOwner=True,exactMainMenuTitle=True,mainMenuIntent='OpenMenuRoute',mainMenuRoute='QuickCustomSetup',controlPath='/Card_Skirmish/Hotspot',mainMenuTitlePath='/Card_Skirmish/Title'),dict(stage='ClosedObserver',setupSeen=True,bindingSeen=True,purposeSeen=True,activeControlSeen=True,manualPlaySeen=True,resultSeen=True,returnSeen=True)]
check('full native visual schema accepted',lambda:q.qualify_visual(visual,'attempt'),True)
for stage,key,value in [('NativeRenderedResultText','frozenVictory',False),('NativeMainMenuDestination','attempt','foreign'),('NativeMainMenuDestination','exactMainMenuOwner',False),('NativeAriaControl','localizedStopCopy',False),('ClosedObserver','activeControlSeen',False)]:
 rs=copy.deepcopy(visual);next(r for r in rs if r['stage']==stage)[key]=value;check('visual '+stage+'/'+key,lambda rs=rs:q.qualify_visual(rs,'attempt'),False)
for f in P.glob('*.py'):ast.parse(f.read_text())
with (P/'offline-parser-controls.json').open('x') as f:json.dump({'scope':'Synthetic proof-schema/negative controls only, no Unity execution, no native win certification','count':len(checks),'checks':checks},f,indent=2);f.write('\n')
print('PASS',len(checks),'offline controls; PythonAST PASS; no Unity')
