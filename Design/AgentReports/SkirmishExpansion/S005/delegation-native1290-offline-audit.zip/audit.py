"""Independent immutable1290 audit; never invokes Unity or rewrites original evidence."""
import hashlib,importlib.util,json,math,pathlib,re
P=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
ORIGINAL=pathlib.Path('/private/tmp/s005-stop-manual-takeover1290')
def require(value,message):
 if not value:raise ValueError(message)
def read(path):return json.loads(path.read_text())
def rows(path):return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,file);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def audit_terminal_exception(fog,commands,touch,diagnostic,observations,terminal,attempt):
 failures=[r for r in fog if r['stage']=='Failure']
 require(len(failures)==1,'Only one exact terminal observer failure may be audited')
 failure=failures[0]
 require(failure['reason'].startswith('System.InvalidOperationException: Unverified native phase change during fallback lease\n'),'Unrelated failure cannot qualify')
 starts=[r for r in fog if r['stage']=='LeaseStarted'];restores=[r for r in fog if r['stage']=='LeaseRestored']
 require(len(starts)==len(restores)==2 and failure['round']==2,'Exact two-round immutable lifecycle required')
 start,restore=starts[-1],restores[-1]
 group=[r for r in fog if r['round']==2 and r['stage'] not in ('Closed','Protocol')]
 require([r['stage'] for r in group]==['LeaseStarted','Actor','Failure','LeaseRestored'],'Interrupted round must contain no terrain gesture/receipt/advance or camera order')
 require(all(r['attempt']==attempt for r in group),'Terminal cleanup crossed attempt')
 require(start['reason']=='WaitingForUnavailablePublicTarget' and start['sameDriver'] is True and start['members']==1 and start['markerVisible'] is False and start['targetVisible'] is False,'Exact selected unavailable-target lease required')
 actor=group[1]
 require(actor['alive'] is True and actor['selected'] is True and actor['id'] and actor['role']=='ApcArmored' and actor['receipt']==0,'Native same selected living cohort missing')
 require(all(math.isfinite(actor[k]) for k in ['elapsed','x','z','startX','startZ','speed','displacement']) and actor['speed']>0 and abs(actor['displacement']-math.hypot(actor['x']-actor['startX'],actor['z']-actor['startZ']))<.05,'Own-cohort displacement inconsistent')
 require(all(r['receipt']==0 and r['timeScale']==1 for r in group),'Interrupted round contains fabricated receipt/speed change')
 require(start['frame']<failure['frame']==restore['frame'] and restore['reason']=='CompanionFailure' and restore['sameDriver'] is True and restore['restoredExact'] is True and restore['originalDue']==start['originalDue'],'Actual exact lease cleanup absent')
 require(fog[-1]['stage']=='Closed' and fog[-1]['restoredExact'] is True and fog[-1]['reason'].startswith('NativeClosed;Failed:'+failure['reason']),'Original failed closure must remain explicit')
 require(not any(c['frame']>=start['frame'] for c in commands),'Any new native gameplay command after interrupted lease prevents offline exception')
 require(terminal['phase']=='Finished' and terminal['outcome']=='Victory' and terminal['reason']=='MainBaseDestroyed' and terminal['clockPaused']==1 and terminal['simulationActive']==0 and terminal['enemyBaseHp']==0 and terminal['playerBaseHp']>0 and 0<terminal['elapsed']<=1080,'Actual native terminal Victory missing')
 at=[r for r in diagnostic if r['stage']=='ManualDriverState' and r['frame']==failure['frame']]
 require(len(at)==1,'Exact native driver sample at rejected terminal boundary missing')
 at=at[0]
 require(at['attempt']==attempt and at['paused'] is True and abs(at['elapsed']-terminal['elapsed'])<.01 and at['driverRunning'] is True and at['driverBusy'] is True and at['completed']+1==at['dispatched'] and at['due']==start['leasedDue'],'Actual busy terminal boundary not established')
 require(at['unexpected']==at['interventions']==0,'Input violation at terminal boundary')
 number=at['dispatched']
 contact=[r for r in touch if r['phase']=='Manual' and r['dispatched']==number and r['kind'] in ('Dispatched','Began','Ended')]
 require([r['kind'] for r in contact]==['Dispatched','Began','Ended'],'Interrupted final contact must actually complete, never be reconstructed')
 dispatched,began,ended=contact
 require(dispatched['frame']<failure['frame']==began['frame']<ended['frame'] and ended['frame']-began['frame']<=4 and ended['time']-began['time']<1 and ended['completed']==number and ended['matchFinished'] is True,'Actual terminal release chronology missing')
 require(len({r['acceptedCommands'] for r in contact})==1 and all(r['unexpected']==r['interventions']==r['receiptViolations']==0 for r in contact),'Final UI gesture accepted gameplay commands or violated audit')
 idle=[r for r in diagnostic if r['stage']=='ManualDriverState' and r['frame']>=ended['frame'] and r['driverBusy'] is False and r['completed']==r['dispatched']==number and r['paused'] is True and abs(r['elapsed']-terminal['elapsed'])<.01]
 require(idle and all(r['attempt']==attempt and r['unexpected']==r['interventions']==0 for r in idle),'Actual drained post-Victory driver missing')
 victories=[r for r in observations if r['stage']=='NativeRenderedResultText' and r['attempt']==attempt and all(r.get(k) is True for k in ['finished','frozenVictory','renderedVictoryWitnessed','renderedTitle']) and r['outcome']=='Victory']
 require(victories and ended['frame']<=min(r['frame'] for r in victories)<=failure['frame']+4,'Independent same-attempt frozen rendered Victory did not follow actual release')
 return {'round':2,'failureRow':failure,'startRow':start,'restoreRow':restore,'groupRows':group,'actualNativeVictoryBoundaryFrame':failure['frame'],'actualContactNumber':number,'actualEndedFrame':ended['frame'],'noPostLeaseAcceptedGameplayOrder':True,'noTerminalClosureRowFabricated':True}
def audit():
 pins=read(P/'input-pins.json')
 for name,h in pins['reportInputs'].items():require(sha(REPORT/name)==h,'Immutable raw evidence changed '+name)
 for name,h in pins['originalCandidateInputs'].items():require(sha(ORIGINAL/name)==h,'Original frozen candidate changed '+name)
 require(sha(ROOT/'Tools/CI/audit_skirmish_native_contacts.py')==pins['contactAuditorSha256'],'Contact audit owner changed')
 original=read(REPORT/'native1290-normal-stop-manual-failure.json')
 require(original['result']=='Failed' and original['errors']==['Missing/malformed actual proof ValueError: Fallback companion failed or QA lease unclosed'],'Original failure envelope differs')
 require(original['wrapperExit']==original['nativeExit']==0 and original['fullSourceUnchanged'] is True,'Actual closure/source failed')
 require(sha(REPORT/'native1290-observer.cs.txt')==pins['originalFixtureSha256'] and sha(ORIGINAL/'runner.py')==pins['originalRunnerSha256'],'Executed fixture/runner provenance differs')
 for suffix in ['.exit','.wrapper-exit']:require((REPORT/(original['log']+suffix)).read_text().strip()=='0','Native/wrapper receipt nonzero')
 manifests=[read(REPORT/original[k]) for k in ['preManifest','preflightManifest','preDispatchManifest','postManifest']]
 require(all(m==manifests[0] for m in manifests),'Full source/material manifests differ')
 for k in ['preManifest','preflightManifest','preDispatchManifest','postManifest']:
  require(read(REPORT/original[k].replace('-source-manifest.json','-independent-fingerprint.json'))['sourceHash']==pins['sourceHash'],'Full source fingerprint differs')
 idle=read(REPORT/'native1290-after-close-idle.json')
 require(idle['success'] is True and idle['data']['success'] is True and idle['data']['result']['success'] is True and idle['data']['result']['result']=='False|False|False|False|False|'+str(ROOT/'Assets'),'Actual idle closure absent')
 log=(REPORT/original['log']).read_text()
 native_runner=load('original1290runner',ORIGINAL/'runner.py')
 markers=['[ExistingEditorValidation] result=Passed executeMethod='+native_runner.METHOD,'[S005CandidateAvailability] fixture=EditorMemoryOnly publication=InProgress shippedCatalogModified=0','[S004MenuProfileFixture] chapter1Completed=5 progressionGate=Preserved isolatedProfile=1','[S004MenuJourney] result=Passed input=Touch controls=Skirmish,Scroll,S005,Launch seedFixture=155926 nativeSessionObserved=1','[S004AriaConsent] result=Passed input=Touch','[SkirmishS002AriaRun] watchStarted=1 seed=155926 locale=en','[S004ManualReceiptAudit] result=Passed measured=1','[S004ManualNative] result=Passed outcome=Victory','[SkirmishTerminalProbe] result=Passed reason=frozenResultAnd:MAIN MENU','[SkirmishValidationExit] result=Requested code=0']
 require(all(marker in log for marker in markers),'Original substantive native marker absent')
 require(not re.search(r'error CS\d+|Compilation failed|observerFailure=1',log),'Native compilation/main observer failed')
 obs=rows(REPORT/native_runner.OBS);bindings=[r for r in obs if r['stage']=='ActualResolvedBinding'];require(len(bindings)==1,'Exactly one actual binding required')
 binding=bindings[0];attempt=binding['attempt']
 expected=dict(catalog='S005',definition='skirmish.s005',seed=155926,size='Standard',difficulty='Regular',army='CombinedArms',start='FieldBase',readiness='Field',readinessValue=1,deadline=1080,objective='BaseAssault',sharedFog=True,developmentFullVision=False,locale='en')
 require(all(binding[k]==v for k,v in expected.items()) and attempt,'Actual public normal setup differs')
 require(any(r['stage']=='NormalDriverFlags' and r['normalDriverFlags'] is True for r in obs),'Public native launch flags absent')
 trace=pathlib.Path(binding['tracePath']);require(trace.parent==REPORT and re.fullmatch(r's005-aria-live-155926-en-[0-9a-f]{32}\.jsonl',trace.name),'Native attempt trace path differs')
 actual=rows(trace);touch=rows(pathlib.Path(str(trace)+'.touch.jsonl'));commands=rows(pathlib.Path(str(trace)+'.commands.jsonl'))
 require(actual and touch and commands,'Raw native trace/input missing')
 require(all(all(r[k]==0 for k in ['unexpected','interventions','receiptViolations']) for r in touch),'Any raw input violation')
 require(all(c['verified'] is True and c['receipt']>0 for c in commands),'Actual native receipt violation')
 contacts=load('contacts1290audit',ROOT/'Tools/CI/audit_skirmish_native_contacts.py').audit(touch)
 require(not contacts['errors'] and all(contacts[k] for k in ['strictRecordedContacts','nativeMenuContactsRecorded','terminalContactsRecorded']),'Complete original paired contact gate fails')
 q=load('original1290proofs',P/'original-qualifier.py');controls=rows(REPORT/native_runner.CONTROLS)
 control=q.qualify_controls(controls,commands,attempt);fresh=q.qualify_fresh_manual(controls,attempt);visual=q.qualify_visual(obs,attempt)
 diagnostics=rows(REPORT/native_runner.DIAGNOSTIC);driver=load('original1290driver',P/'original-driver-qualifier.py').qualify(diagnostics)
 fog=rows(REPORT/native_runner.FOG);exception=audit_terminal_exception(fog,commands,touch,diagnostics,obs,actual[-1],attempt)
 fogproof=load('audited1290fog',P/'fog-qualifier-audited.py').qualify(fog,commands,attempt,required=True,terminal_proof={'renderedVictoryPassed':True,'sameAttemptReturnPassed':True,'strictContactAudit':True},exception_proof=exception)
 return {'result':'PassedScopedOfflineAuditedNative1290','sourceHash':pins['sourceHash'],'originalFailurePreserved':True,'originalFailureProof':'native1290-normal-stop-manual-failure.json','originalFailureSha256':pins['reportInputs']['native1290-normal-stop-manual-failure.json'],'nativeReplayPerformed':False,'wrapperExit':0,'nativeExit':0,'fullSourceUnchanged':True,'attempt':attempt,'actualResolvedSetup':binding,'terminal':actual[-1],'inputAudit':contacts,'controlProof':control,'freshManualDriverProof':fresh,'visualProof':visual,'passiveDriverDiagnostic':driver,'fogProof':fogproof,'terminalObserverRaceAudit':exception,'countsForNormalStopManualControls':True,'countsForAriaSeedBaseline':False,'countsForPhysicalTakeover':False,'playerReady':False,'realHumanDeviceAcceptance':False,'limits':['Hybrid automated explicit Stop/manual journey; no human/device, physical automatic takeover or additional unattendedARIA seed qualification.','Native TerminalClosure row was not emitted. Actual exact lease restoration, input drain, native frozen Victory and rendered return establish the separate offline observer-race qualification.','QA carry census observed no pending flag in1290, so the foreign-carry cleanup branch was not exercised natively.'],'errors':[]}
if __name__=='__main__':
 proof=audit()
 with (REPORT/'native1290-offline-audited-stop-manual-proof.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
 print(json.dumps({k:proof[k] for k in ['result','sourceHash','wrapperExit','nativeExit','fullSourceUnchanged','nativeReplayPerformed','playerReady']}))
