$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\All120Refinement\20261015-s026-03-logical-frame'
$ownedExit=1
try {
    if(-not (Test-Path -LiteralPath (Join-Path $run 'source-before.json'))){throw 'Fresh post-preparation complete source/DLL snapshot required'}
    if(Test-Path -LiteralPath (Join-Path $run 'S026.json')){throw 'Preserve prior collection; fresh output required'}
    $env:WARLINE_ALL120_REFINEMENT_CATALOG='S026'
    $env:WARLINE_ALL120_REFINEMENT_OUTPUT=Join-Path $run 'S026.json'
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    $marker='[All120SimultaneousLogicalRefinement] result=Collected catalog=S026 sourceFitCertified=0'
    & (Join-Path $project 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unity -ProjectPath $project -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.RunAll120BoundedLogicalFrameRefinement' -LogFile (Join-Path $run 'unity.log') -RequiredPassMarker $marker -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if($LASTEXITCODE -ne 0){throw 'Checked S026 logical-frame collection failed'}
    $log=[IO.File]::ReadAllText((Join-Path $run 'unity.log'))
    if(-not $log.Contains('[BoundedLogicalFrameControls] result=Passed controls=6 frameCandidates=4 physicalSourceChanged=0 sourceFitCertified=0')){throw 'Logical-frame controls marker absent'}
    if(-not $log.Contains('[UnityInvoke] ExitCode: 0')){throw 'Actual wrapper exit0 absent'}
    if($log.Contains('result=Failed')){throw 'Collection has failed marker'}
    $ownedExit=0
}catch{[Console]::Error.WriteLine($_.ToString())}
finally{[IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
