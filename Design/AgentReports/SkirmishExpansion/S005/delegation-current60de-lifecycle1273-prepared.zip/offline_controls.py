"""Offline controls use retained real1226 evidence; never create native proof."""
import ast, copy, hashlib, importlib.util, json, pathlib, re
P=pathlib.Path(__file__).parent
R=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=R/'Design/AgentReports/SkirmishExpansion/S005'
spec=importlib.util.spec_from_file_location('lifecycle_parser',P/'qualify_lifecycle.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
obs='native1226-lifecycle-observation.jsonl';touch='native1226-lifecycle-touch.jsonl'
actual=module.load_rows(REPORT/obs);checks=[]
base=module.qualify(REPORT,obs,touch,False)
assert base['genuineDefeats']==10 and base['countedWins']==0
checks.append('Exact real1226 closed evidence passes scoped old-source parser without a new-source claim')
def rejects(label, fn):
    try:fn()
    except ValueError:checks.append(label);return
    raise AssertionError('Negative control accepted: '+label)
rejects('Old1226 missing current typed state rejected for current1273',lambda:module.qualify(REPORT,obs,touch,True))
original=module.load_rows
def mutate(label, mutation):
    rows=copy.deepcopy(actual);mutation(rows)
    module.load_rows=lambda path: rows if pathlib.Path(path)==REPORT/obs else original(path)
    try:rejects(label,lambda:module.qualify(REPORT,obs,touch,False))
    finally:module.load_rows=original
def first(rows, stage):return next(r for r in rows if r['stage']==stage)
for field,value in [('sameBudget',False),('playerMaterials',451),('oldPhysical',1),('selected',1),('hold',1),('productionRows',1),('researchRows',1),('deliveredActors',1),('sharedFog',False),('developmentFullVision',True),('markers',-1),('elapsed',999)]:
    mutate('Reject altered actual fresh '+field,lambda rows,k=field,v=value:first(rows,'FreshNativeAttempt').update({k:v}))
mutate('Reject repeated fresh attempt',lambda rows:[r.update(attempt='duplicate') for r in rows if r['stage']=='FreshNativeAttempt'])
mutate('Reject missing fresh attempt',lambda rows:rows.remove(first(rows,'FreshNativeAttempt')))
mutate('Reject mismatched typed marker owner',lambda rows:first(rows,'NativeSelectedMarker').update(markerParentMatches=False))
mutate('Reject pause snapshot delta',lambda rows:first(rows,'NativePauseComparison').update(snapshot='changed'))
mutate('Reject pause clock delta',lambda rows:first(rows,'NativePauseComparison').update(elapsed=999))
mutate('Reject unheld selected body',lambda rows:first(rows,'NativePausedBaseline').update(snapshot=first(rows,'NativePausedBaseline')['snapshot'].replace('|hold=True','|hold=False',1)))
for field,value in [('saveAcknowledged',0),('outcome','Victory'),('reason','EnemyBaseDestroyed'),('resultSession','foreign'),('visibleGlyphs',0),('viewportMatches',False),('sourceCopy','incorrect')]:
    mutate('Reject malformed actual rendered Defeat '+field,lambda rows,k=field,v=value:first(rows,'NativeFrozenRenderedDefeat').update({k:v}))
mutate('Reject native result action before rendered outcome',lambda rows:next(r for r in rows if r['stage']=='NativeControlTouch' and r['action']=='Replay').update(frame=0))
mutate('Reject wrong Replay ancestry',lambda rows:first(rows,'NativeReplayDestination').update(priorAttempt='foreign'))
mutate('Reject fake MainMenu binding',lambda rows:first(rows,'NativeMainMenuDestination').update(exactMainMenuOwner=False))
mutate('Reject failed closed summary',lambda rows:first(rows,'ClosedLifecycle').update(passed=False))
mutate('Reject final native input count mismatch',lambda rows:first(rows,'NativeLifecycleSummary').update(completed=60))
raw=original(REPORT/touch)
for field,value in [('unexpected',1),('interventions',1),('receiptViolations',1),('kind','PhysicalTakeover')]:
    bad=copy.deepcopy(raw);bad[0][field]=value
    module.load_rows=lambda path,bad=bad:bad if pathlib.Path(path)==REPORT/touch else original(path)
    try:rejects('Reject earlier native raw '+field+' even clean last row',lambda:module.qualify(REPORT,obs,touch,False))
    finally:module.load_rows=original
runner=ast.parse((P/'runner.py').read_text())
def gate(message):
    matches=[n for n in ast.walk(runner) if isinstance(n,ast.If) and any(isinstance(k,ast.Constant) and k.value==message for k in ast.walk(n))]
    assert len(matches)==1
    return compile(ast.fix_missing_locations(ast.Module(body=matches,type_ignores=[])),'actual-runner-guard','exec')
g=gate('Actual wrapper/native exit must both be0')
for wrapper,native in [(0,0),(0,1),(1,0)]:
    env=dict(wrapper=wrapper,native=native,errors=[]);exec(g,env);assert bool(env['errors'])==(wrapper!=0 or native!=0);checks.append('Actual wrapper/native guard '+str((wrapper,native)))
g=gate('Full source/material manifests changed')
for same,h in [(True,'current'),(False,'current'),(True,'different')]:
    env=dict(same=same,h=h,prep={'currentCandidateSourceHash':'current'},errors=[]);exec(g,env);assert bool(env['errors'])==(not same or h!='current');checks.append('Actual full source/hash guard '+str((same,h)))
prep=json.loads((P/'manifest.json').read_text());sha=lambda path:hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
for key in ('fixture','runner','parser','sourceManifestHelper','nativeIdleHelper'):assert sha(prep[key])==prep[key+'Sha256']
for name,h in prep['sourceContracts'].items():assert sha(R/name)==h
fixture=(P/'S005Lifecycle1273.cs').read_text()
assert 'SkirmishS002AriaRunHarness.RunS005EditorManualFa();' in fixture
assert 'AppendEnemyState(em,s,rows);' in fixture and 'ObserveFreshEnemyState(em,setup,id);' in fixture
assert 'SkirmishEnemyPlannerService.EnsureSession(' not in fixture
assert 'public int plannerVersion,capabilityVersion,operationRows,transportRows,assignmentRows,productionIntentState,constructionPhase;' in fixture
checks.append('Current fixture mandatory new state fields are primitive Serializable fields; no initializer mutation')
out=dict(result='Passed',scope='Offline real retained1226 parser compatibility, mutation rejection and current guarded runner/hash/schema controls only. No Unity call/native1273 proof.',cases=len(checks),checks=checks,sourceHash=prep['currentCandidateSourceHash'],nativeCompiled=False,nativeExecuted=False,playerReady=False)
with (P/'offline-controls-result.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('result','cases','scope')}))
