from pathlib import Path
import hashlib,json
root=Path.cwd();run=root/'Logs/SkirmishProduction/BatchMatrixControls/20261015-01'
manifest=root/'Tools/CI/SkirmishProductionDrafts/ProductionBaselineBatchRuntimeGate/manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(manifest)=='4a58b00ac386720a7ecf63464b2431b6b42ee3a0ea564b5df489dc06646fc812'
review=manifest.parent/'INDEPENDENT_REVIEW.4a58b00a.json'
assert sha(review)=='49906b6ba5bc2cb1f7a397f5ca9d92ff7f2df2a83249829c412f95124d59328e'
d=json.loads(manifest.read_text());rows=d['files']+d['tools']
for r in rows:
    t=root/r['target'];assert (sha(t) if t.exists() else None)==r['before_sha256'],r['target'];assert sha(root/r['source'])==r['sha256'],r['source']
for r in rows:
    t=root/r['target']
    if t.exists():
        backup=run/'before'/r['target'];backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(t.read_bytes())
    t.write_bytes((root/r['source']).read_bytes());assert sha(t)==r['sha256']
(run/'IMPORT_RECEIPT.json').write_text(json.dumps({'result':'ImportedExactReviewedNineSourcesFourTools','manifest_sha256':sha(manifest),'files':rows,'native_pending':True,'queue_success_enabled':False},indent=2)+'\n')
print('[BatchMatrixImport] result=Passed sources=9 tools=4 nativePending=1 queueQualified=0')
