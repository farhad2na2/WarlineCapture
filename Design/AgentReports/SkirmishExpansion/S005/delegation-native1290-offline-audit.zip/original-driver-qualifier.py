"""Fail-closed passive QA state schema; no outcomes reconstructed."""
import math
FIELDS=('frame','step','slot','verifiedAttackMoves','beforeOrder','attackReceipts','retries','page','selectedMask','assaultMask','structureMask','attackOrderMask','selectedGroups','completed','dispatched','unexpected','interventions','elapsed','due','deadline')
def qualify(rows):
 states=[r for r in rows if r.get('stage')=='ManualDriverState']
 if not states or len([r for r in rows if r.get('stage')=='Closed'])!=1:raise ValueError('Actual passive state and exact closed observer required')
 attempts={r.get('attempt') for r in states}
 if len(attempts)!=1 or not next(iter(attempts)):raise ValueError('Mixed or missing actual attempt')
 for r in rows:
  if r.get('stage')=='Closed':continue
  if r.get('attempt') not in attempts:raise ValueError('Foreign passive row')
  if r.get('stage')=='SelectedActor':
   if not r.get('id') or not r.get('role') or not r.get('groupId') or not r.get('selected'):raise ValueError('Missing current selected identity')
   continue
  for k in FIELDS:
   v=r.get(k)
   if not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v):raise ValueError('Missing/nonfinite primitive '+k)
  if r['unexpected']!=0 or r['interventions']!=0 or r['completed']>r['dispatched']:raise ValueError('Passive input ownership violation')
  if r.get('stage')=='AcceptedReceipt' and (r.get('verified') is not True or not r.get('receipt') or not r.get('operation')):raise ValueError('Unverified real receipt')
 return {'result':'PassedReadOnlySchemaOnly','attempt':next(iter(attempts)),'stateSamples':len(states),'receiptSamples':sum(r.get('stage')=='AcceptedReceipt' for r in rows),'maxAcknowledgedManualAttacks':max(r['attackReceipts'] for r in states),'gameplayCorrectionProven':False,'syntheticResults':False}
