import hashlib
import json
from pathlib import Path

root = Path.cwd()
run = root / 'Logs/SkirmishProduction/All120Refinement/20261015-s026-03-logical-frame'
folder = root / 'Tools/CI/SkirmishProductionDrafts/ParallelSourceSnapshot'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(folder/'manifest.json') == '5f401dd01f9d677a019c040853ae87992273a165854be43da24171a86d469061'
assert sha(folder/'INDEPENDENT_REVIEW.json') == 'cb1238b41a07f32a7a20713170d8946e606765e0a802b5a0de12360796e41577'
parity_path = run/'snapshot-host-parity-result.json'
assert sha(parity_path) == '7bb5898bb0b0222bcd7ca83c4f01a2e644c41b1a85c5758568dce8a212dd651d'
old_capture, new_capture = run/'source-after.json', run/'source-after-parallel.json'
assert old_capture.read_bytes() == new_capture.read_bytes()
assert sha(old_capture) == '56c5f2c6b26f830c1f8c61bdfa5f3eb1569483203881fdac6e4d161dfdbe10df'
row = json.loads((folder/'manifest.json').read_text())['files'][0]
target, source = root/row['target'], root/row['source']
assert sha(target) == row['before_sha256']
assert sha(source) == row['sha256']
backup = run/'before-tools'/row['target']
backup.parent.mkdir(parents=True, exist_ok=True)
with backup.open('xb') as stream:
    stream.write(target.read_bytes())
target.write_bytes(source.read_bytes())
assert sha(target) == row['sha256']
(run/'PARALLEL_TOOL_IMPORT.json').write_text(json.dumps(dict(status='AdoptedExactReviewedParallelSnapshotTool', file=row, smallFixtureMethods=7, fullSourceCount=41598, fullDllCount=192, fullCliOutputsByteIdentical=True, paritySha256=sha(parity_path), sourceCandidateUnaffectedBecauseToolsOutsideSourceManifest=True, cacheOrOmissions=False, isolatedSpeedupMeasured=False, qualificationClaim=False), indent=2)+'\n', encoding='utf-8')
print('[ParallelSnapshotToolImport] result=Passed files=1 fullCliByteParity=1 sourceFiles=41598 dllFiles=192 cacheUsed=0')
