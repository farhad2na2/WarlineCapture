﻿param($ProjectPath,$UnityExe,$LogFile,$RawOutput,$Checkpoints,$Group,$Marker,$TimeoutSeconds)
$ErrorActionPreference='Stop'
$env:WARLINE_GROUND30_CHUNK_GROUP=$Group
$env:WARLINE_GROUND30_CHUNK_OUTPUT=$RawOutput
$env:WARLINE_GROUND30_CHUNK_CHECKPOINTS=$Checkpoints
$ownedExit=1
try {
 & (Join-Path $ProjectPath 'Tools/CI/InvokeUnityExecuteMethodValidation.ps1') -UnityExe $UnityExe -ProjectPath $ProjectPath -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.RunGroundObjective30SourceChunk' -LogFile $LogFile -RequiredPassMarker $Marker -GuiLicensing -TimeoutSeconds $TimeoutSeconds
 if($global:LASTEXITCODE -ne 0){throw 'Checked source chunk returned nonzero'}
 $ownedExit=0
} catch {[Console]::Error.WriteLine($_.ToString())}
finally {[IO.File]::WriteAllText((Join-Path (Split-Path -Parent $LogFile) 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
