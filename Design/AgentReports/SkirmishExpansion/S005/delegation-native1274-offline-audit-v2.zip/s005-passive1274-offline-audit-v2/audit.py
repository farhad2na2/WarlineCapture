"""Independent immutable1274 audit; no Unity, gameplay or readiness writes."""
import ast,hashlib,importlib.util,json,pathlib,re
P=pathlib.Path(__file__).parent
ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
SOURCE='60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9'
METHOD='S005PassivePerformance1274.RunValidation'
LEGACY='[SkirmishValidationExit] result=Requested code=0'
FAILURE='native1274-passive-pressure-performance-failure.json'
def require(ok,message):
 if not ok:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def load(name):
 spec=importlib.util.spec_from_file_location(name,P/(name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def cli_success(d):
 require(d.get('success') is True and d.get('data',{}).get('success') is True and d['data'].get('result',{}).get('success') is True,'Native outer/data/nested success absent')
 require(d['data'].get('target',{}).get('projectPath')==str(ROOT),'Native target differs')
 require(not any(str(x.get('severity','')).lower()=='error' for x in d['data']['result'].get('diagnostics',[])),'Native compiler error')
def core(f,text,wrapper,native,idles):
 require(f['result']=='Failed' and f['sourceHash']==SOURCE and f['fullSourceUnchanged'] is True,'Original immutable failure/source differs')
 require(f['errors']==['Missing native marker '+LEGACY],'Original failure contains a substantive or different error')
 require(wrapper==native==f['wrapperExit']==f['nativeExit']==0,'Actual wrapper/native receipt must be zero')
 require(f['normalResourcesPosesDamageVisibilityClocksOutcomeInjected'] is False and f['enemyAIOrNativeDefensiveCombatDisabled'] is False,'Native passive gameplay scope changed')
 require(f['countedPlayerWins']==0 and f['normalMissionWinCertified'] is False and f['deviceCertified'] is False and f['performanceBudgetPassed'] is False and f['playerReady'] is False,'Scoped limits changed')
 tree=ast.parse((P/'runner.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MARKERS' for t in n.targets));markers=ast.literal_eval(node.value)
 require(markers.count(LEGACY)==1 and LEGACY not in text,'Exactly the stale marker is the audited exception')
 for marker in markers:
  if marker!=LEGACY:require(marker in text,'Original substantive native marker missing: '+marker)
 require(text.count('[ExistingEditorValidation] result=Passed executeMethod='+METHOD)==1,'Exact Task<int> native bridge completion not unique')
 require(not re.search(r'error CS\d+|Compilation failed|\[S005PassivePressure1274\] result=Failed|\[ExistingEditorValidation\] result=Failed',text),'Native failure exists')
 for bad in ('[S004AriaConsent] result=Passed','[S004ManualNative] result=Passed outcome=Victory','reason=ariaStopped:'):
  require(bad not in text,'Unexpected ARIA/player-win marker')
 for d in idles:
  cli_success(d);require(d['data']['result'].get('result')=='False|False|False|False|False|'+str(ROOT/'Assets'),'Native idle ownership unclosed')
def audit():
 pins=read(P/'pins.json')
 for n,h in pins['report'].items():require(sha(REPORT/n)==h,'Immutable raw file changed: '+n)
 for n,h in pins['external'].items():require(sha(P/n)==h,'Frozen executed dependency changed: '+n)
 f=read(REPORT/FAILURE);text=(REPORT/f['log']).read_text()
 idles=[read(REPORT/('native1274-'+tag+'-idle.json')) for tag in ('before-load','before-dispatch','after-close')]
 wrapper=int((REPORT/(f['log']+'.wrapper-exit')).read_text());native=int((REPORT/(f['log']+'.exit')).read_text());core(f,text,wrapper,native,idles)
 require(sha(REPORT/f['log'])==f['logSha256'],'Log provenance mismatch')
 require(sha(P/'runner.py')==f['runnerSha256'] and sha(REPORT/'native1274-fixture.cs.txt')==sha(P/'S005PassivePerformance1274.cs')==f['fixtureSha256'],'Actual executed runner/fixture bytes differ')
 for k,h in [('observation','observationSha256'),('performanceRaw','performanceRawSha256'),('dryCompileProof','dryCompileProofSha256')]:require(sha(REPORT/f[k])==f[h],'Original '+k+' hash differs')
 prep=read(P/'prepared.json');start=read(REPORT/'native1274-runner-start.json')
 require(prep['sourceHash']==start['sourceHash']==SOURCE and start['method']==METHOD and start['fixtureSha256']==f['fixtureSha256'] and start['runnerSha256']==f['runnerSha256'],'Actual dispatch identity differs')
 require(start['normalInput'] is True and start['gameplayStateInjected'] is False and start['playerOrdersBeforeTerminalReturn']==0 and start['readOnlyPerformanceProbe'] is True,'Startup scope is not native passive')
 for n in [f['dryCompileProof'],'load1274-passive-performance.json']:
  d=read(REPORT/n);cli_success(d);params=d['data']['parameters'];require(params['entry']=='S005PassivePerformance1274.Run' and params['file']=='/private/tmp/s005-passive-performance1274-v2/S005PassivePerformance1274.cs','Exact loaded/dry entry differs')
  if n==f['dryCompileProof']:require(params.get('dry_run') in (True,'true'),'Actual dry compile absent')
 manifests=[read(REPORT/f[k]) for k in ('preManifest','preflightManifest','preDispatchManifest','postManifest')]
 require(all(m==manifests[0] for m in manifests),'Full source pre/preflight/predispatch/post unequal')
 for k in ('preManifest','preflightManifest','preDispatchManifest','postManifest'):
  fp=read(REPORT/f[k].replace('-source-manifest.json','-independent-fingerprint.json'));require(fp['sourceHash']==SOURCE,'Independent fingerprint differs')
 require(sha(REPORT/f['preManifest'])==prep['referenceManifestSha256'],'Reviewed initial full source differs')
 obs=rows(REPORT/f['observation']);touch=rows(REPORT/'native1274-passive-pressure-touch.jsonl');coord=[r for r in obs if r['stage']=='QaPassiveCoordination'];require(len(coord)==1,'Exact passive handoff missing')
 trace=pathlib.Path(coord[0]['tracePath']);require(trace.parent==REPORT and str(trace)==f['tracePath'],'Profile-owned trace differs')
 contacts=load('audit_skirmish_native_contacts');pressure=load('pressure-qualifier').qualify({'observation':obs,'externalTouch':touch,'inheritedTouch':rows(pathlib.Path(str(trace)+'.touch.jsonl'))},contacts.audit)
 escort=load('escort-qualifier').qualify(obs);performance=load('performance-qualifier').qualify(rows(REPORT/f['performanceRaw']),obs,pressure['attempt'])
 require(pressure==f['pressureEvidence'] and escort==f['naturalPaidEscortEvidence'] and performance==f['editorPerformanceEvidence'],'Recomputed raw qualifications differ from original closed evidence')
 require(performance['measurementQualified'] is True and performance['deviceCertified'] is False and performance['performanceBudgetPassed'] is False and performance['observerOverheadIncluded'] is True,'Measurement limits changed')
 return {'result':'PassedScopedOfflineAuditedNative1274','sourceHash':SOURCE,'fullSourceUnchanged':True,'originalRunnerFailure':FAILURE,'originalRunnerFailurePreserved':True,'auditedException':'Legacy SkirmishValidationExit marker is absent on Task<int> ExistingEditorValidation path; exact bridge Passed, native exit0, wrapper0 and idle replace no gameplay/result/input gate.','wrapperExit':wrapper,'nativeExit':native,'nativePassiveDefeatCertified':True,'pressureEvidence':pressure,'naturalPaidEscortEvidence':escort,'editorPerformanceEvidence':performance,'nativeReplayPerformed':False,'normalResourcesPosesDamageVisibilityClocksOutcomeInjected':False,'enemyAIOrNativeDefensiveCombatDisabled':False,'countedPlayerWins':0,'allEnemyPlanStepsCertified':False,'normalMissionWinCertified':False,'deviceCertified':False,'performanceBudgetPassed':False,'fullX17MemoryQualified':False,'technicallyReady':False,'playerReady':False,'errors':[],'supersedesInvalidV1AuditFreeze':True,'originalV1ProofPreserved':'native1274-offline-audited-passive-pressure-performance-proof.json','auditSha256':sha(P/'audit.py'),'rawPins':pins['report'],'sourceContractPins':pins['sourceContractPins']}
if __name__=='__main__':
 result=audit()
 with (REPORT/'native1274-offline-audited-passive-pressure-performance-proof-v2.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({'result':result['result'],'nativeExit':result['nativeExit'],'wrapperExit':result['wrapperExit'],'nativePassiveDefeatCertified':True,'playerReady':False,'performanceBudgetPassed':False}))
