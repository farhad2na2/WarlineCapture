$ErrorActionPreference = 'Stop'
$deadline = [DateTime]::UtcNow.AddSeconds(45)
$lockPath = 'D:\Projects\WarlineCapture\.git\index.lock'
$env:GIT_LITERAL_PATHSPECS = '1'
while ([DateTime]::UtcNow -lt $deadline) {
    $gitProcesses = @(Get-CimInstance Win32_Process -Filter "Name = 'git.exe'")
    if ($gitProcesses.Count -ne 0) { Start-Sleep -Seconds 3; continue }
    if (Test-Path -LiteralPath $lockPath) {
        $lock = Get-Item -LiteralPath $lockPath
        if ($lock.Length -ne 0 -or $lock.LastWriteTimeUtc -gt [DateTime]::UtcNow.AddMinutes(-5)) { throw 'Lock is not verified stale' }
        $stream = [IO.File]::Open($lockPath, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        $stream.Dispose()
        Remove-Item -LiteralPath $lockPath
        Write-Output 'Removed verified stale empty index lock'
    }
    & rtk git add --pathspec-from-file=Logs/SkirmishProduction/SharedNativePreparation/20261015-02-verify-authoring-warmup/stage-current-paths.nul --pathspec-file-nul
    exit $LASTEXITCODE
}
Write-Output 'Git processes remain active; left index lock untouched'
exit 2
