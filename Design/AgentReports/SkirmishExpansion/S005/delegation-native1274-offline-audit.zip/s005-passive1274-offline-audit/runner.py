"""1274 normal passive enemy pressure with read-only Editor performance probe; no device/budget certification. Escalated root launch required."""
import argparse,hashlib,importlib.util,json,pathlib,re,subprocess,sys
ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture');REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005';P=pathlib.Path(__file__).parent
STATE=REPORT/'TECHNICAL_READINESS_CURRENT.json';PREP=P/'prepared.json';HELPER=pathlib.Path('/private/tmp/warline-s005-source-manifest.py');FIXTURE=P/'S005PassivePerformance1274.cs';IDLE=P/'S005PassiveIdle1274.cs'
LOG='native-1274-passive-pressure-performance-fa-seed104734.log';METHOD='S005PassivePerformance1274.RunValidation';TOUCH='native1274-passive-pressure-touch.jsonl'
MARKERS=['[S005CandidateAvailability] fixture=EditorMemoryOnly publication=InProgress shippedCatalogModified=0', '[S004MenuProfileFixture] chapter1Completed=5 progressionGate=Preserved isolatedProfile=1', '[S004MenuJourney] result=Passed input=Touch controls=Skirmish,Scroll,S005,Launch seedFixture=104734 nativeSessionObserved=1', '[S004ManualNative] started=1 input=Touch ariaStarted=0', '[S005PassivePressure1274] result=Passed scope=NormalNativePassiveEnemyPressure wins=0 playerReady=0', '[ExistingEditorValidation] result=Passed executeMethod=S005PassivePerformance1274.RunValidation', '[SkirmishValidationExit] result=Requested code=0']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def new_json(p,d):
 with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def load(name):
 s=importlib.util.spec_from_file_location(name,P/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def rows(p):
 if not p.is_file():raise ValueError('Missing native evidence '+p.name)
 return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
def manifest(prefix):
 for suffix in ('-source-manifest.json','-independent-fingerprint.json'):
  if (REPORT/(prefix+suffix)).exists():raise RuntimeError('Preserve existing source evidence '+prefix)
 subprocess.run(['rtk','proxy','python3',str(HELPER),prefix],cwd=ROOT,check=True)
 return prefix+'-source-manifest.json'
def cli(args,out):
 r=subprocess.run(['rtk','proxy','unity','command',*args,'--project-path',str(ROOT),'--format','json'],cwd=ROOT,capture_output=True,text=True)
 with out.open('x') as f:f.write(r.stdout)
 if r.stderr:new_json(out.with_name(out.name+'.stderr.json'),{'stderr':r.stderr,'exit':r.returncode})
 d=json.loads(r.stdout)
 if r.returncode or not d.get('success') or not d.get('data',{}).get('result',{}).get('success'):raise RuntimeError('Native CLI outer/nested failure '+out.name)
 return d['data']['result'].get('result')
def idle(tag):
 v=cli(['run_script','--file',str(IDLE),'--entry','S005PassiveIdle1274.Run','--timeout_ms','30000'],REPORT/('native1274-'+tag+'-idle.json'))
 if v!='False|False|False|False|False|'+str(ROOT/'Assets'):raise RuntimeError('Main native idle ownership differs '+repr(v))
def owner_idle():
 if read(STATE).get('activeRun') is not None:raise RuntimeError('Another main lane is owned')
def verify_dry(d):
 data=d.get('data',{});inner=data.get('result',{});params=data.get('parameters',{})
 if d.get('success') is not True or data.get('success') is not True or inner.get('success') is not True or any(str(v.get('severity','')).lower()=='error' for v in inner.get('diagnostics',[])) or params.get('file')!=str(FIXTURE) or params.get('entry')!='S005PassivePerformance1274.Run' or params.get('dry_run') not in ('true',True) or data.get('target',{}).get('projectPath')!=str(ROOT):raise RuntimeError('Exact current fixture native dry success/parameters/target not proven')

def verify_metadata(prep):
 expected={'runId':1274,'sourceHash':'60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9','fixture':FIXTURE.name,'loadOnlyEntry':'S005PassivePerformance1274.Run','method':METHOD,'publicEntry':'Game.Editor.SkirmishS002AriaRunHarness.RunS005EditorManualFa','executionOwner':'main1274','seed':104734,'locale':'fa-IR','wrapperTimeout':2100,'fixtureDeadline':1800,'authoredMatchDeadline':1080,'normalMissionWinCertified':False,'countedPlayerWins':0,'deviceCertified':False,'performanceBudgetPassed':False}
 if any(prep.get(k)!=v for k,v in expected.items()):raise RuntimeError('Frozen passive1274 metadata does not match actual executable scope')
 if prep.get('fixtureSha256')!=sha(FIXTURE) or prep.get('runnerSha256')!=sha(pathlib.Path(__file__)) or prep.get('sourceContractCount')!=len(prep.get('sourceContracts',{})):raise RuntimeError('Frozen passive1274 metadata hashes/count differ')

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('pre_manifest');ap.add_argument('--dry-compile-proof',required=True);ap.add_argument('--heavy-lane-owner',required=True,choices=['main1274']);a=ap.parse_args();prep=read(PREP)
 verify_metadata(prep)
 owner_idle()
 dryPath=pathlib.Path(a.dry_compile_proof)
 if dryPath.parent!=REPORT or not dryPath.name.startswith('compile1274-'):raise RuntimeError('Exact archived compile1274 dry-proof path required')
 verify_dry(read(dryPath))
 if pathlib.Path(a.pre_manifest).name!=a.pre_manifest or not (REPORT/a.pre_manifest).is_file() or sha(REPORT/a.pre_manifest)!=prep['referenceManifestSha256']:raise RuntimeError('Exact reviewed source-manifest basename/hash required')
 for rel,h in prep['files'].items():
  if sha(P/rel)!=h:raise RuntimeError('Frozen external bytes changed '+rel)
 if sha(HELPER)!=prep['sourceManifestHelperSha256']:raise RuntimeError('Source helper bytes changed')
 for rel,h in prep['sourceContracts'].items():
  if sha(ROOT/rel)!=h:raise RuntimeError('Reviewed current source changed '+rel)
 if any(re.match(r'(?:native-?|load|final-|compile)1274(?:\D|$)',x.name)  for x in REPORT.iterdir() if x!=dryPath):raise RuntimeError('Preserve previous1274 artifacts')
 pre=manifest('final-1274-passive-performance-preflight')
 if read(REPORT/a.pre_manifest)!=read(REPORT/pre) or read(REPORT/pre.replace('-source-manifest.json','-independent-fingerprint.json'))['sourceHash']!=prep['sourceHash']:raise RuntimeError('Current full source differs; native not called')
 try:idle('before-load')
 except Exception as e:
  new_json(REPORT/'native1274-preflight-failure.json',{'result':'Failed','stage':'NativeIdlePreflight','error':str(e),'nativeMissionDispatched':False,'preManifest':pre});raise
 with (REPORT/'native1274-fixture.cs.txt').open('xb') as f:f.write(FIXTURE.read_bytes())
 cli(['run_script','--file',str(FIXTURE),'--entry','S005PassivePerformance1274.Run','--timeout_ms','30000'],REPORT/'load1274-passive-performance.json')
 dispatch=manifest('final-1274-passive-performance-pre-dispatch')
 if read(REPORT/a.pre_manifest)!=read(REPORT/dispatch):raise RuntimeError('Source changed before dispatch')
 idle('before-dispatch');owner_idle();s=read(STATE);s.update(activeRun='native1274',activeLog=LOG,activeScope=METHOD,activePreManifest=a.pre_manifest);STATE.write_text(json.dumps(s,indent=2)+'\n')
 new_json(REPORT/'native1274-runner-start.json',{'explicitHeavyLaneOwner':a.heavy_lane_owner,'sourceHash':prep['sourceHash'],'preManifest':a.pre_manifest,'preflightManifest':pre,'preDispatchManifest':dispatch,'method':METHOD,'fixtureSha256':sha(FIXTURE),'runnerSha256':sha(pathlib.Path(__file__)),'normalInput':True,'playerOrdersBeforeTerminalReturn':0,'gameplayStateInjected':False,'readOnlyPerformanceProbe':True,'dryCompileProof':dryPath.name,'dryCompileProofSha256':sha(dryPath)})
 wrapper=subprocess.run(['rtk','proxy','Tools/CI/invoke_unity_macos.sh','--project',str(ROOT),'--reuse','--timeout','2100','--log',str(REPORT/LOG),'--','-executeMethod',METHOD],cwd=ROOT).returncode
 with (REPORT/(LOG+'.wrapper-exit')).open('x') as f:f.write(str(wrapper)+'\n')
 receipt=REPORT/(LOG+'.exit');native=None
 if receipt.is_file() and re.fullmatch(r'-?\d+\s*',receipt.read_text()):native=int(receipt.read_text())
 if native is None:
  new_json(REPORT/'native1274-unclosed-ownership.json',{'result':'Unclosed','reason':'Missing/malformed native exit receipt','wrapperExit':wrapper,'nativeExit':native,'ownershipPreserved':True,'playerReady':False});return 4
 try:idle('after-close')
 except Exception as e:
  new_json(REPORT/'native1274-unclosed-ownership.json',{'result':'Unclosed','reason':str(e),'wrapperExit':wrapper,'nativeExit':native,'ownershipPreserved':True,'playerReady':False});return 4
 post=manifest('final-1274-passive-performance-post');same=read(REPORT/a.pre_manifest)==read(REPORT/pre)==read(REPORT/dispatch)==read(REPORT/post);errors=[]
 text=(REPORT/LOG).read_text(errors='replace') if (REPORT/LOG).is_file() else ''
 if wrapper!=0 or native!=0:errors.append('Actual wrapper/native failure '+str(wrapper)+'/'+str(native))
 if not same:errors.append('Full source/material manifest changed')
 for marker in MARKERS:
  if marker not in text:errors.append('Missing native marker '+marker)
 if re.search(r'error CS\d+|Compilation failed|\[S005PassivePressure1274\] result=Failed',text):errors.append('Native compiler/fixture failure')
 touch=[];qualified=None;escort=None;performance=None;observation=[];perfRows=[];inheritedTouch=[];trace=None
 try:
  observation=rows(REPORT/'native1274-passive-pressure-observation.jsonl')
  coords=[r for r in observation if r['stage']=='QaPassiveCoordination']
  if len(coords)!=1:raise ValueError('Exactly one actual public passive handoff required; empty early failure stays failed')
  trace=pathlib.Path(coords[0]['tracePath'])
  if trace.parent!=REPORT or not re.fullmatch(r's005-aria-live-104734-fa-[0-9a-f]{32}\.jsonl',trace.name):raise ValueError('Actual native profile-owned trace path invalid')
  touch=rows(REPORT/TOUCH);inheritedTouch=rows(pathlib.Path(str(trace)+'.touch.jsonl'))
  spec=importlib.util.spec_from_file_location('contacts',ROOT/'Tools/CI/audit_skirmish_native_contacts.py');contacts=importlib.util.module_from_spec(spec);spec.loader.exec_module(contacts)
  qualified=load('pressure-qualifier').qualify({'observation':observation,'externalTouch':touch,'inheritedTouch':inheritedTouch},contacts.audit)
 except Exception as e:errors.append('Native passive pressure qualification failed '+type(e).__name__+': '+str(e))
 try:escort=load('escort-qualifier').qualify(observation)
 except Exception as e:errors.append('Native paid/escort qualification failed '+type(e).__name__+': '+str(e))
 try:
  perfRows=rows(REPORT/'native1274-passive-performance.jsonl')
  if qualified is None:raise ValueError('Actual pressure attempt must qualify before measurement can qualify')
  performance=load('performance-qualifier').qualify(perfRows,observation,qualified['attempt'])
 except Exception as e:errors.append('Native Editor measurement qualification failed '+type(e).__name__+': '+str(e))
 for bad in ('[S004AriaConsent] result=Passed','[S004ManualNative] result=Passed outcome=Victory','reason=ariaStopped:'):
  if bad in text:errors.append('Unexpected ARIA/manual takeover/win marker '+bad)
 proof={'result':'PassedScopedNormalPassivePressureAndEditorMeasurements' if not errors else 'Failed','sourceHash':prep['sourceHash'],'fullSourceUnchanged':same,'preManifest':a.pre_manifest,'preflightManifest':pre,'preDispatchManifest':dispatch,'postManifest':post,'wrapperExit':wrapper,'nativeExit':native,'log':LOG,'logSha256':sha(REPORT/LOG) if (REPORT/LOG).is_file() else None,'fixtureSha256':sha(FIXTURE),'runnerSha256':sha(pathlib.Path(__file__)),'dryCompileProof':dryPath.name,'dryCompileProofSha256':sha(dryPath),'tracePath':str(trace) if trace else None,'observation':'native1274-passive-pressure-observation.jsonl','observationSha256':sha(REPORT/'native1274-passive-pressure-observation.jsonl') if (REPORT/'native1274-passive-pressure-observation.jsonl').is_file() else None,'performanceRaw':'native1274-passive-performance.jsonl','performanceRawSha256':sha(REPORT/'native1274-passive-performance.jsonl') if (REPORT/'native1274-passive-performance.jsonl').is_file() else None,'pressureEvidence':qualified,'naturalPaidEscortEvidence':escort,'editorPerformanceEvidence':performance,'errors':errors,'normalResourcesPosesDamageVisibilityClocksOutcomeInjected':False,'enemyAIOrNativeDefensiveCombatDisabled':False,'qaOneWinWatcherAndManualAutoCombatCoordinated':True,'nativePassiveDefeatCertified':not errors,'countedPlayerWins':0,'allEnemyPlanStepsCertified':False,'normalMissionWinCertified':False,'deviceCertified':False,'performanceBudgetPassed':False,'playerReady':False}
 new_json(REPORT/('native1274-passive-pressure-performance-'+('failure' if errors else 'pass')+'.json'),proof)
 s=read(STATE)
 if s.get('activeRun')!='native1274':raise RuntimeError('Main owner changed; do not clear unrelated lane')
 s.update(activeRun=None,activeLog=None,activeScope=None,activePreManifest=None,latestPassivePressurePerformance1274='native1274-passive-pressure-performance-'+('failure' if errors else 'pass')+'.json');STATE.write_text(json.dumps(s,indent=2)+'\n')
 print(json.dumps({'result':proof['result'],'errors':errors,'wrapperExit':wrapper,'nativeExit':native,'playerReady':False}));return 1 if errors else 0
if __name__=='__main__':sys.exit(main())
