1245 is an ID-only successor of frozen1244. Native1244 stopped at sandbox Pipeline discovery preflight; no mission dispatch. Every executable normal-input, paidR2, recovery/casualty, native frozen result/return, completeTouch/source/ownership gate is unchanged. Qualifiers are byte-identical. Original1244 retained. Native compile/load/run of1245 remains root-owned and pending.

Root launch must use require_escalated so nested Unity CLI can discover the live Editor Pipeline. This is a tool execution permission context, not a production/script semantic change.

Dry compile through CLI run_script --file <observer> --entry S005NormalManualR2Recovery1245Observer.Run --dry-run --timeout_ms 30000 --project-path /Users/farhad/Projects/WarlineCapture --format json. Require outer/data/nested success + zero errors. Root then launch:
rtk proxy python3 /private/tmp/s005-normal-manual-recovery1245-reconstructed/s005-run-normal-manual-r2-recovery-1245.py native1242-two-fixture-post-source-manifest.json --heavy-lane-owner main1245
Runner loads Run (load-only) and dispatches RunValidation exclusively through repository GUI validation wrapper; explicit1800s timeout. No Unity executed by agent.

Offline21 controls passed; original1235 and1243 unmodified failed companion proofs remain rejected. Original128-contract list unrecovered, current121 exact pins plus whole-source equality retained.
