$ErrorActionPreference = 'Stop'
$projectPath = 'D:\Projects\WarlineCapture'
$runPath = Join-Path $projectPath 'Logs\SkirmishProduction\AircraftRootSupport\20261015-03-canonical-git'
$env:WARLINE_AIRCRAFT_ROOT_SUPPORT_OUTPUT = Join-Path $runPath 'aircraft-root-support.jsonl'
$ownedExit = 1
try {
    & (Join-Path $projectPath 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $runPath 'unity-editor.txt') -LogFile (Join-Path $runPath 'resolver.log')
    if ($LASTEXITCODE -ne 0) { throw 'Checked Editor resolution failed' }
    $unityPath = [IO.File]::ReadAllText((Join-Path $runPath 'unity-editor.txt')).Trim()
    & (Join-Path $projectPath 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unityPath -ProjectPath $projectPath -ExecuteMethod 'Game.Editor.SkirmishGroundSourceFitSurvey.CollectCanonicalAircraftRootProvenance' -LogFile (Join-Path $runPath 'unity.log') -RequiredPassMarker '[CanonicalAircraftRootSupportProvenance] result=Collected rolesExpected=7 templateOnly=1 defaultWorldPreserved=1 cameraAccepted=0' -BuildTarget Android -GuiLicensing -TimeoutSeconds 1800
    if ($LASTEXITCODE -ne 0) { throw 'Checked native provenance validation failed' }
    $ownedExit = 0
} catch {
    [Console]::Error.WriteLine($_.ToString())
} finally {
    [IO.File]::WriteAllText((Join-Path $runPath 'checked-child-exit.txt'), [string]$ownedExit)
}
exit $ownedExit
