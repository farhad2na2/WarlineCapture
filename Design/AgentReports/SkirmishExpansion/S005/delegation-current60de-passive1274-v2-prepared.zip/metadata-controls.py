"""Pure offline metadata/hash/dry-proof controls; no Unity or native execution."""
import ast,copy,importlib.util,json,pathlib
P=pathlib.Path(__file__).parent
spec=importlib.util.spec_from_file_location('runner_v2',P/'runner.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
prep=json.loads((P/'prepared.json').read_text());cases=[]
def check(name,call,success):
 try:call();actual=True
 except (RuntimeError,KeyError,TypeError):actual=False
 assert actual==success,(name,actual,success)
 cases.append({'name':name,'accepted':actual,'expectedAccepted':success})
check('correct exact1274 metadata',lambda:r.verify_metadata(prep),True)
for key in ['runId','sourceHash','fixture','loadOnlyEntry','method','publicEntry','executionOwner','seed','locale','wrapperTimeout','fixtureDeadline','authoredMatchDeadline','normalMissionWinCertified','countedPlayerWins','deviceCertified','performanceBudgetPassed','fixtureSha256','runnerSha256','sourceContractCount']:
 bad=copy.deepcopy(prep);bad[key]='wrong';check('reject mismatched '+key,lambda bad=bad:r.verify_metadata(bad),False)
old=json.loads((pathlib.Path('/private/tmp/s005-passive-performance1274')/'prepared.json').read_text());check('reject frozen stale cargo1272 metadata',lambda:r.verify_metadata(old),False)
valid={'success':True,'data':{'success':True,'parameters':{'file':str(r.FIXTURE),'entry':'S005PassivePerformance1274.Run','dry_run':'true'},'target':{'projectPath':str(r.ROOT)},'result':{'success':True,'diagnostics':[]}}}
check('exact current native dry schema',lambda:r.verify_dry(valid),True)
for name,location,key,value in [('outer false',[], 'success',False),('data false',['data'],'success',False),('native false',['data','result'],'success',False),('wrong file',['data','parameters'],'file','cargo1272.cs'),('wrong entry',['data','parameters'],'entry','S005PaidTransportPlane1272.Run'),('not dry',['data','parameters'],'dry_run','false'),('wrong target',['data','target'],'projectPath','wrong'),('missing target',['data'],'target',{}),('compiler error',['data','result'],'diagnostics',[{'severity':'error'}]),('missing native success',['data'],'result',{})]:
 bad=copy.deepcopy(valid);place=bad
 for field in location:place=place[field]
 place[key]=value;check('reject dry '+name,lambda bad=bad:r.verify_dry(bad),False)
for q in P.glob('*.py'):ast.parse(q.read_text(),filename=str(q))
with (P/'metadata-controls-results.json').open('x') as f:json.dump({'result':'Passed','controls':len(cases),'cases':cases,'noNativeCalls':True},f,indent=2);f.write('\n')
print('PASS',len(cases),'metadata/dry controls; Python AST PASS')
