"""Offline only. Requires all six closed native pass proofs; never calls Unity or readiness writers."""
import argparse, collections, csv, hashlib, importlib.util, json, pathlib, re

ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
SOURCE='60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9'
MATRIX=pathlib.Path(__file__).with_name('matrix-manifest.json')
MATRIX_SHA='a676a1d62e191bcc9f38b46db7ea0ab414372e4f8d49e718a3e28dd81e32e496'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
def require(value,message):
 if not value:raise ValueError(message)
def records(p):return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
def owned_path(name):
 require(isinstance(name,str) and pathlib.Path(name).name==name,'Evidence must be exact report basename')
 return REPORT/name
def validate_case(run,canonical_manifest,audit_module):
 rid=run['id'];locale=run['locale'];seed=run['seed'];proof_path=REPORT/f'native{rid}-normal-aria-pass.json'
 require(proof_path.is_file(),f'Closed pass proof missing for{rid}; no partial matrix qualification')
 proof=read(proof_path)
 require(proof.get('result')=='Passed' and proof.get('sourceHash')==SOURCE and proof.get('fullSourceUnchanged') is True and proof.get('errors')==[],f'{rid} actual pass/source/error gate')
 for field in ('normalInput','normalSpeedCertified','countedWinCertified','countsForAriaSeedBaseline'):
  require(proof.get(field) is True,f'{rid} {field} not certified')
 require(proof.get('fundingReadinessActorPoseDamageVisibilityOutcomeInjected') is False,f'{rid} synthetic gameplay is prohibited')
 require(proof.get('actualWrapperExit')==0 and proof.get('nativeBridgeExit')==0,f'{rid} wrapper/native exits')
 for field in ('preManifest','preflightManifest','preDispatchManifest','postManifest'):
  path=owned_path(proof[field]);require(read(path)==canonical_manifest,f'{rid} complete files/materials changed at{field}')
  fp=read(path.with_name(path.name.replace('-source-manifest.json','-independent-fingerprint.json')))
  require(fp.get('sourceHash')==SOURCE,f'{rid} actual whole-source fingerprint mismatch')
 log=owned_path(proof['log']);obs_path=owned_path(proof['observation']);fixture=owned_path(proof['fixture']);executed=REPORT/f'native{rid}-executed-runner.py.txt'
 require(sha(log)==proof['logSha256'] and sha(obs_path)==proof['observationSha256'],f'{rid} log/observer hash changed')
 require(sha(fixture)==proof['fixtureSha256']==run['fixtureSha256'],f'{rid} exact executed fixture mismatch')
 require(sha(executed)==proof['executedRunnerSha256']==run['runnerSha256'],f'{rid} exact executed runner mismatch')
 require(int(log.with_name(log.name+'.exit').read_text().strip())==0 and int(log.with_name(log.name+'.wrapper-exit').read_text().strip())==0,f'{rid} actual receipt files')
 text=log.read_text(errors='replace')
 require('[AriaTouchInput] physicalTakeover' not in text and 'ariaStopped:Manual' not in text,f'{rid} actual physical takeover')
 for marker in ('[S004AriaConsent] result=Passed input=Touch controls=Play,Confirm','[SkirmishTerminalProbe] frozen=1 returnInput=Touch target=ADJUST SETUP','[SkirmishTerminalProbe] result=Passed reason=frozenResultAnd:ADJUST SETUP','[SkirmishS002AriaRun] appended=1 countedWin=1 error=','[SkirmishValidationExit] result=Requested code=0'):
  require(marker in text,f'{rid} actual native marker missing:{marker}')
 require(re.search(r'\[SkirmishNormalSpeed\] latch=True .* counted=True',text),f'{rid} normal speed latch')
 require(not re.search(r'error CS\d+|Compilation failed',text),f'{rid} native compilation error')
 binding=proof['actualResolvedSetup'];attempt=binding['attempt']
 expected=dict(catalog='S005',definition='skirmish.s005',size='Standard',difficulty='Regular',army='CombinedArms',start='FieldBase',readiness='Field',readinessValue=1,seed=seed,deadline=1080,objective='BaseAssault',sharedFog=True,developmentFullVision=False,locale=locale)
 require(attempt and all(binding.get(k)==v for k,v in expected.items()),f'{rid} actual resolved configuration')
 obs=records(obs_path)
 require(len([r for r in obs if r.get('stage')=='ActualResolvedBinding'])==1,f'{rid} exact native session binding')
 require(not any(r.get('stage')=='ObserverFailure' for r in obs),f'{rid} observer failure')
 contexts=[r for r in obs if r.get('stage')=='RenderedViewportContext' and r.get('nativeViewportMatched') is True]
 require(contexts and all(r.get('samplingPhase')=='CanvasWillRenderCanvases' and abs(r['canvasWidth']-r['screenWidth'])<=1 and abs(r['canvasHeight']-r['screenHeight'])<=1 for r in contexts),f'{rid} native rendered viewport')
 for role in ('SetupTitle','SetupObjective','HudPurposeTitle','HudPurposeBody','ObjectiveStrip','AriaControl','ResultText','AdjustSetupTitle','AdjustSetupObjective'):
  require(any(r.get('stage')=='NativeBoundText' and r.get('role')==role and r.get('exactBoundReference') is True and r.get('samplingPhase')=='CanvasWillRenderCanvases' and r.get('activeText') is True and r.get('culledText') is False and r.get('textAlpha',0)>.01 and r.get('ancestorAlpha',0)>.01 and r.get('visibleGlyphs',0)>0 and r.get('safeAreaOverlap') is True and r.get('renderedBody') is True for r in obs),f'{rid} actual strict bound text:{role}')
 victories=[(i,r) for i,r in enumerate(obs) if r.get('stage')=='NativeRenderedResultText' and r.get('finished') is True and r.get('frozenVictory') is True and r.get('renderedTitle') is True and r.get('renderedVictoryWitnessed') is True and r.get('outcome')=='Victory' and r.get('attempt')==attempt and ((locale=='en' and r.get('title','').upper()=='VICTORY') or (locale=='fa-IR' and r.get('localizedVictoryCopy') is True))]
 require(victories,f'{rid} rendered same-attempt frozen localized Victory')
 returns=[(i,r) for i,r in enumerate(obs) if r.get('stage')=='NativeAdjustSetupDestination' and r.get('seed')==seed and r.get('renderedTitle') is True and r.get('renderedObjective') is True]
 require(returns and all(i>victories[0][0] and r.get('finished') is True and r.get('frozenVictory') is True and r.get('renderedVictoryWitnessed') is True and r.get('outcome')=='Victory' and r.get('attempt')==attempt and r['frame']>=victories[0][1]['frame'] for i,r in returns),f'{rid} post-result rendered AdjustSetup return')
 closed=[r for r in obs if r.get('stage')=='ClosedObserver']
 require(len(closed)==1 and all(closed[0].get(k) is True for k in ('setupSeen','bindingSeen','purposeSeen','activeControlSeen','resultSeen','returnSeen')),f'{rid} actual observer closure')
 trace=owned_path(proof['trace']);require(pathlib.Path(binding['tracePath'])==trace,f'{rid} exact native trace binding')
 trace_rows=records(trace);require(trace_rows,f'{rid} empty trace');terminal=trace_rows[-1]
 require(terminal==proof['terminal'] and terminal.get('phase')=='Finished' and terminal.get('outcome')=='Victory' and terminal.get('clockPaused')==1 and terminal.get('simulationActive')==0 and 0<terminal.get('elapsed',0)<=1080,f'{rid} actual frozen terminal trace')
 touch_path=trace.with_name(trace.name+'.touch.jsonl');touch=records(touch_path)
 require(touch and all(r.get('kind')!='PhysicalTakeover' and all(r.get(k)==0 for k in ('unexpected','interventions','receiptViolations')) for r in touch),f'{rid} every native touch row must be clean')
 audit=audit_module.audit(touch)
 require(audit['errors']==[] and audit['strictRecordedContacts'] and audit['nativeMenuContactsRecorded'] and audit['terminalContactsRecorded'],f'{rid} strict native Menu/Runtime/Terminal pairing')
 commands_path=trace.with_name(trace.name+'.commands.jsonl');commands=records(commands_path)
 require(commands and all(c.get('verified') is True and c.get('receipt') for c in commands),f'{rid} verified native accepted receipts')
 counted=proof['nativeCountedRow']
 require(len(counted)==20 and counted[1]=='S005' and counted[3]==SOURCE and counted[5:12]==['Standard','Regular',str(seed),locale,'Editor','aria','1'] and counted[13]=='Victory' and counted[16:18]==['0','0'],f'{rid} counted native CSV identity')
 native_csv=[row for line in text.splitlines() if len(row:=next(csv.reader([line])))==20 and row[1]=='S005' and row[7]==str(seed) and row[8]==locale]
 require(native_csv==[counted],f'{rid} exactly one actual native log CSV must match proof')
 copied=ROOT/counted[18];copied_log=ROOT/counted[19]
 require(copied.read_bytes()==trace.read_bytes() and '[SkirmishS002AriaRun] appended=1 countedWin=1 error=' in copied_log.read_text(),f'{rid} actual archived trace/log')
 idle=read(REPORT/f'native{rid}-after-close-native-idle.json')
 require(idle.get('success') is True and idle.get('data',{}).get('success') is True and idle['data']['result']['success'] is True,f'{rid} native idle outer/data/result')
 actual_idle=json.loads(idle['data']['result']['result'])
 require(all(actual_idle.get(k) is False for k in ('applicationIsPlaying','editorIsCompiling','editorIsUpdating','editorIsPlayingOrWillChangePlaymode')) and actual_idle.get('assemblyCompilationState')=='Idle' and actual_idle.get('dataPath')==str(ROOT/'Assets'),f'{rid} actual closed Editor state')
 evidence=[proof_path,log,obs_path,fixture,executed,trace,touch_path,commands_path]
 return dict(id=rid,locale=locale,seed=seed,attempt=attempt,victorySeconds=terminal['elapsed'],contacts=audit['recordedContacts'],paidObservations=proof.get('paidDeliveryObservationCount'),proof=proof_path.name,proofSha256=sha(proof_path),evidenceSha256={p.name:sha(p) for p in evidence})
def validate_retry_lineage(matrix, canonical):
 lineage=matrix['replacedInterruptedSlot'];original=lineage['original']
 require(original['id']==1267 and lineage['retry']==1276 and lineage['qualificationTransferred'] is False and lineage['sourceHash']==SOURCE,'Exact interrupted slot lineage required')
 for path,expected in ((REPORT/lineage['interruptedProof'],lineage['interruptedProofSha256']),(REPORT/lineage['fixtureArchived'],lineage['fixtureArchivedSha256']),(REPORT/lineage['runnerArchived'],lineage['runnerArchivedSha256'])):
  require(sha(path)==expected,'Original interrupted1267 evidence changed: '+path.name)
 interrupted=read(REPORT/lineage['interruptedProof'])
 require(interrupted.get('result')=='Interrupted_Unqualified' and interrupted.get('nativeCompletionReceiptPresent') is False and interrupted.get('countedWin') is False,'Interrupted1267 cannot be promoted')
 log=REPORT/'native-1267-normal-aria-fa-seed130368.log'
 require(not log.with_name(log.name+'.exit').exists() and int(log.with_name(log.name+'.wrapper-exit').read_text().strip())==143 and not (REPORT/'native1267-normal-aria-pass.json').exists(),'Original1267 missing native receipt/143 must remain unqualified')
 for phase in ('preflight','pre-dispatch'):
  name=f'final-1267-normal-aria-{phase}-source-manifest.json';require(read(REPORT/name)==canonical,'Interrupted1267 source differs from retried current candidate')
  require(read(REPORT/name.replace('-source-manifest.json','-independent-fingerprint.json'))['sourceHash']==SOURCE,'Interrupted1267 full source hash mismatch')
 retry=next(r for r in matrix['runs'] if r['id']==1276)
 prep_path=pathlib.Path(retry['prep']);require(sha(prep_path)==retry['prepSha256'],'Frozen retry preparation changed')
 prep=read(prep_path);require(prep['retryPredecessor']['runId']==1267 and prep['currentCandidateSourceHash']==SOURCE and prep['publicEntry']==original['publicEntry'],'Retry exact source/public method lineage mismatch')
 archived_fixture=(REPORT/lineage['fixtureArchived']).read_text();new_fixture=pathlib.Path(retry['fixture']).read_text()
 require(new_fixture.replace('1276','1267')==archived_fixture,'Retry observer changed beyond unique ID')
 old_runner=(REPORT/lineage['runnerArchived']).read_text();new_runner=pathlib.Path(retry['runner']).read_text()
 require(new_runner.replace('/private/tmp/s005-aria-retry1276','/private/tmp/s005-repaired-aria-matrix1263-1268/1267').replace('1276','1267')==old_runner,'Retry runner changed beyond ID/preparation path')
 require(sha(pathlib.Path(retry['fixture']))==retry['fixtureSha256'] and sha(pathlib.Path(retry['runner']))==retry['runnerSha256'],'Frozen retry bytes changed')
 return dict(interruptedRun=1267,retryRun=1276,interruptedQualification='Interrupted_Unqualified',originalEvidencePreserved=True,wrapperExit143=True,nativeCompletionReceiptAbsent=True,fixtureAndRunnerOnlyIdPathChanges=True)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',required=True);args=ap.parse_args()
 output=pathlib.Path(args.output);require(not output.exists(),'Preserve existing aggregate output')
 require(sha(MATRIX)==MATRIX_SHA,'Reviewed preparation matrix changed')
 matrix=read(MATRIX);require(matrix['candidateHash']==SOURCE,'Preparation candidate changed')
 runs=matrix['runs'];require([(r['locale'],r['seed']) for r in runs]==[('en',104734),('en',130368),('en',155926),('fa-IR',104734),('fa-IR',130368),('fa-IR',155926)],'Exactly six distinct locale/seed slots required')
 # Refuse incomplete active matrix before doing any qualification or writing output.
 require(all((REPORT/f"native{r['id']}-normal-aria-pass.json").is_file() for r in runs),'All six closed native pass artifacts required; wait for every selected closed case, including1268')
 require(sha(REPORT/matrix['candidateManifest'])==matrix['candidateManifestSha256'],'Reviewed complete candidate manifest bytes changed')
 canonical=read(REPORT/matrix['candidateManifest']);lineage=validate_retry_lineage(matrix,canonical)
 spec=importlib.util.spec_from_file_location('strict_native_contacts',ROOT/'Tools/CI/audit_skirmish_native_contacts.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
 results=[validate_case(r,canonical,audit) for r in runs]
 require(len({r['attempt'] for r in results})==6,'Six independently fresh attempts required')
 wins=collections.Counter(r['locale'] for r in results);require(wins=={'en':3,'fa-IR':3},'Distinct baseline wins per locale')
 proof=dict(result='PassedCurrentSourceStandardRegularAriaBaseline',sourceHash=SOURCE,caseCount=6,winsByLocale=dict(wins),cases=results,preparedMatrixSha256=MATRIX_SHA,retryLineage=lineage,offlineVerifierSha256=sha(pathlib.Path(__file__)),qualification='Six genuine native NORMAL INPUT ARIA journeys; complete source equality, native/wrapper0, all Touch, rendered localized frozenVictory thenAdjustSetup rechecked offline.',nativeCallsByVerifier=0,readinessEdited=False,playerReady=False,limitations=['Does not certify manual/takeover, complete role/air/cargo, balance/stress, Campaign, performance, owner visual or human/device acceptance.','Originalfailed1253 and all historical proofs remain preserved.'])
 with output.open('x') as f:f.write(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({'result':proof['result'],'output':str(output),'sha256':sha(output),'sourceHash':SOURCE},indent=2))
if __name__=='__main__':main()
