using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Game.Components;
using Game.Configs;
using Game.Editor;
using Game.Runtime;
using Game.UI.Runtime;
using TMPro;
using Unity.Entities;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

// External QA: existing public menu/ARIA launch, genuine native STOP touch, then native manual control.
// This adapter writes evidence, never entities, orders, clocks, controls or displayed text.
public static class S005NormalStopManual1278Observer
{
    const string Report = "/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/";
    const string Evidence = Report + "native1278-normal-stop-manual-observation.jsonl";
    static bool everPlaying, setupSeen, bindingSeen, purposeSeen, activeControlSeen, resultSeen, returnSeen;
    static double next, began;
    static bool finishedVictorySeen, manualPlaySeen, checkpointArchived, restoredSeen;
    static string initialAttempt="", saveRoot="", nativeSavePath="";
    static float lastPausedElapsed;
    static uint trackedPaidReceipt;
    static string trackedPaidStable="";
    const string CheckpointArchive=Report+"native1278-normal-manual-r2-native-checkpoint.json";
    static string witnessedAttempt="";
    static readonly HashSet<string> receiptStates = new();
    static readonly Dictionary<string,string> lastRows = new();
    static readonly FieldInfo NativePlayerLabel = typeof(SkirmishMatchView).GetField("player", BindingFlags.NonPublic | BindingFlags.Instance);
    static readonly FieldInfo NativeEnemyLabel = typeof(SkirmishMatchView).GetField("enemy", BindingFlags.NonPublic | BindingFlags.Instance);
    static readonly FieldInfo NativeClockLabel = typeof(SkirmishMatchView).GetField("clock", BindingFlags.NonPublic | BindingFlags.Instance);
    static readonly MethodInfo ReadPoint = typeof(SkirmishS002AriaRunHarness).GetMethod("TryPresentedButtonPoint", BindingFlags.NonPublic | BindingFlags.Static);
    static readonly MethodInfo TracePath = typeof(SkirmishS002AriaRunHarness).GetMethod("LiveTracePath", BindingFlags.NonPublic | BindingFlags.Static);

    [Serializable] public sealed class Row
    {
        public string stage="", catalog="", definition="", size="", difficulty="", army="", start="", readiness="", objective="", attempt="", locale="", tracePath="";
        public string title="", body="", roster="", economy="", intel="", summary="", modelObjective="", clock="", playerBase="", enemyBase="", controlText="", controlPath="", role="", phase="", reason="";
        public int frame, seed, deadline, faction, producer, materialsPaid, expectedCost, members, deliveredMembers, readinessValue,remainingMembers,supplyCost,capacityReleased;
        public uint reservation;
        public bool localizedObjectiveCopy, localizedPurposeCopy, localizedStopCopy, localizedVictoryCopy, sharedFog, developmentFullVision, renderedTitle, renderedBody, renderedObjective, renderedRoster, renderedEconomy, renderedIntel, renderedPlayerBase, renderedEnemyBase, renderedClock, presentedControl, ariaActive, finished, expanded, combinedArmsField, setupSeen, bindingSeen, purposeSeen, activeControlSeen, resultSeen, returnSeen, normalDriverFlags;
        public string expectedPlayerCaption="", expectedEnemyCaption="", actualPlayerCaption="", actualEnemyCaption="", actualClockText="", nativeClockSource="", modelClockNumber="", nativeClockNumber="";
        public bool exactPlayerBinding, exactEnemyBinding, exactClockBinding, clockNumberPresentAndCurrent;
        public string actorStableId="", researchKind="", researchPhase="", researchProducer="", runtimeReadiness="", nativeSavePath="", saveProfileRoot="", checkpointArchive="", shellRoute="";
        public uint researchId;
        public int infantryUpgrade, vehicleUpgrade, aircraftUpgrade, actorCount, actorHealth, actorEntityIndex, actorEntityVersion, bankCurrent, bankCapacity, lifetimeSpent, lifetimeFabricated, lifetimeImported, lifetimeRewarded, lifetimeExported;
        public float elapsed, researchRemainingSeconds, expectedResearchSeconds, savedElapsed;
        public bool paused, simulationActive, recoveredNativeComplete, inheritedProfileVerified, checkpointNativeValidated, unobscuredDestination, destinationSessionAbsent, manualPlaySeen;
        public string outcome="";
        public bool frozenVictory, renderedVictoryWitnessed;
        public float timeScale, screenWidth, screenHeight, safeX, safeY, safeWidth, safeHeight, canvasX, canvasY, canvasWidth, canvasHeight, textX, textY, textWidth, textHeight, textAlpha, ancestorAlpha;
        public int characterCount, visibleGlyphs;
        public bool activeText, culledText, safeAreaOverlap, nativeViewportMatched, exactBoundReference;
        public string samplingPhase="", textPath="", ownerPath="";
        public bool exactMainMenuOwner,exactMainMenuTitle;
        public string mainMenuIntent="",mainMenuRoute="",mainMenuTitlePath="",expectedMainMenuCaption="",actualMainMenuCaption="";
    }
    public static void Run() => Debug.Log("[S005NormalStopManual1278] loadedOnly=1 gameplayStarted=0");
    public static void RunValidation()
    {
        if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Idle main Editor required");
        if(ReadPoint==null||TracePath==null||NativePlayerLabel==null||NativeEnemyLabel==null||NativeClockLabel==null)throw new MissingMethodException("Native public observer bridge absent");
        if(File.Exists(Evidence))throw new IOException("Preserve1278 observation");
        using(File.Open(Evidence,FileMode.CreateNew,FileAccess.Write,FileShare.Read)){}
        everPlaying=setupSeen=bindingSeen=purposeSeen=activeControlSeen=resultSeen=returnSeen=manualPlaySeen=finishedVictorySeen=false;initialAttempt=witnessedAttempt="";lastRows.Clear();receiptStates.Clear();next=0;began=EditorApplication.timeSinceStartup;
        EditorApplication.update+=Observe;Canvas.willRenderCanvases+=ObserveRendered;
        S005StopManual1278.Start();S005ManualDriverDiagnostic1278.Start();
        try {SkirmishS002AriaRunHarness.RunS005EditorAriaEnSeed3();}
        catch(Exception e){S005StopManual1278.Fail(e);throw;}
        bool flags=Environment.GetEnvironmentVariable("WARLINE_SKIRMISH_CATALOG")=="S005"&&Environment.GetEnvironmentVariable("WARLINE_S002_LOCALE")=="en"&&Environment.GetEnvironmentVariable("WARLINE_S002_SEED")=="155926"&&Environment.GetEnvironmentVariable("WARLINE_S004_MENU_JOURNEY")=="1"&&string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WARLINE_S004_MANUAL_PROBE"))&&string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WARLINE_S004_STOP_PROBE"));
        Append(new Row{stage="NormalDriverFlags",normalDriverFlags=flags,reason="Public normal S005 ARIA launch; later explicit planned STOP/native manual handoff, not an unattended ARIA win"});
    }
    static void Append(Row row)
    {
        string key=row.stage+"|"+row.controlPath+"|"+row.reservation+"|"+(row.stage=="NativeRenderedResultText" ? row.title : "");
        string state=JsonUtility.ToJson(row);
        if(lastRows.TryGetValue(key,out var prior) && prior==state)return;
        lastRows[key]=state;
        row.frame=Time.frameCount;row.timeScale=Time.timeScale;
        row.locale=UiShellRuntimeGateway.Localization.CurrentLocaleCode;
        File.AppendAllText(Evidence,JsonUtility.ToJson(row)+"\n");
    }
    static string PathOf(Transform t) => t==null ? "" : t.parent==null ? t.name : PathOf(t.parent)+"/"+t.name;
    static bool Presented(Button b)
    {
        if (b==null) return false;
        return (bool)ReadPoint.Invoke(null,new object[]{b,default(Vector2)});
    }
    static bool CopyMatches(TMP_Text t,string localized)
    {
        if(t==null || string.IsNullOrEmpty(localized))return false;
        string expected=UiLocalizedText.CatalogLabel(localized);
        string raw=t is RTLTMPro.RTLTextMeshPro rtl ? rtl.OriginalText : t.text;
        return string.Equals(raw,expected,StringComparison.Ordinal) || string.Equals(raw,V3LocalizedTextBindingView.ShapeForRendering(expected),StringComparison.Ordinal);
    }
    static string ClockNumber(string source)
    {
        if(string.IsNullOrEmpty(source))return "";
        int separator=source.LastIndexOf("  ",StringComparison.Ordinal);
        string value=separator>=0 ? source.Substring(separator+2).Trim() : source.Trim();
        var parts=value.Split(':');
        if(parts.Length!=2 || !int.TryParse(parts[0],out int minutes) || !int.TryParse(parts[1],out int seconds) || minutes<0 || seconds<0 || seconds>=60)return "";
        return value;
    }
    static string Text(TMP_Text t) => t==null ? "" : t.text ?? "";
    static bool Rendered(TMP_Text t)
    {
        if(t==null || !t.isActiveAndEnabled || !t.gameObject.activeInHierarchy || string.IsNullOrWhiteSpace(t.text) || t.color.a<=.01f || t.canvasRenderer.cull) return false;
        foreach(var group in t.GetComponentsInParent<CanvasGroup>()) if(group.alpha<=.01f)return false;
        bool glyph=false;
        if(t.textInfo!=null)for(int i=0;i<t.textInfo.characterCount;i++)if(t.textInfo.characterInfo[i].isVisible){glyph=true;break;}
        if(!glyph)return false;
        var canvas=t.GetComponentInParent<Canvas>();
        var camera=canvas!=null && canvas.renderMode!=RenderMode.ScreenSpaceOverlay ? canvas.worldCamera : null;
        var corners=new Vector3[4];t.rectTransform.GetWorldCorners(corners);
        var low=RectTransformUtility.WorldToScreenPoint(camera,corners[0]);var high=RectTransformUtility.WorldToScreenPoint(camera,corners[2]);
        return new Rect(Mathf.Min(low.x,high.x),Mathf.Min(low.y,high.y),Mathf.Abs(high.x-low.x),Mathf.Abs(high.y-low.y)).Overlaps(Screen.safeArea);
    }
    static void BoundText(string role,TMP_Text text,Transform owner)
    {
        if(text==null){Append(new Row{stage="NativeBoundText",role=role,ownerPath=PathOf(owner),samplingPhase="CanvasWillRenderCanvases",reason="MissingExactNativeBoundLabel"});return;}
        var canvas=text.GetComponentInParent<Canvas>();
        var camera=canvas!=null && canvas.renderMode!=RenderMode.ScreenSpaceOverlay ? canvas.worldCamera : null;
        var corners=new Vector3[4];text.rectTransform.GetWorldCorners(corners);
        var lo=RectTransformUtility.WorldToScreenPoint(camera,corners[0]);var hi=RectTransformUtility.WorldToScreenPoint(camera,corners[2]);
        var rect=new Rect(Mathf.Min(lo.x,hi.x),Mathf.Min(lo.y,hi.y),Mathf.Abs(hi.x-lo.x),Mathf.Abs(hi.y-lo.y));
        float alpha=1;foreach(var group in text.GetComponentsInParent<CanvasGroup>())alpha=Mathf.Min(alpha,group.alpha);
        int visible=0;if(text.textInfo!=null)for(int i=0;i<text.textInfo.characterCount;i++)if(text.textInfo.characterInfo[i].isVisible)visible++;
        Rect safe=Screen.safeArea,viewport=canvas!=null?canvas.pixelRect:default;
        Append(new Row{stage="NativeBoundText",role=role,controlPath=PathOf(text.transform),textPath=PathOf(text.transform),ownerPath=PathOf(owner),exactBoundReference=owner!=null && text.transform.IsChildOf(owner),samplingPhase="CanvasWillRenderCanvases",body=Text(text),activeText=text.isActiveAndEnabled && text.gameObject.activeInHierarchy,culledText=text.canvasRenderer.cull,textAlpha=text.color.a,ancestorAlpha=alpha,characterCount=text.textInfo?.characterCount??0,visibleGlyphs=visible,safeAreaOverlap=rect.Overlaps(safe),textX=rect.x,textY=rect.y,textWidth=rect.width,textHeight=rect.height,screenWidth=Screen.width,screenHeight=Screen.height,safeX=safe.x,safeY=safe.y,safeWidth=safe.width,safeHeight=safe.height,canvasX=viewport.x,canvasY=viewport.y,canvasWidth=viewport.width,canvasHeight=viewport.height,renderedBody=Rendered(text)});
    }
    static TMP_Text Label(Transform parent,string path) => parent.Find(path)?.GetComponent<TMP_Text>();
    static void Observe()
    {
        if(EditorApplication.isPlaying)everPlaying=true;
        if(everPlaying&&!EditorApplication.isPlayingOrWillChangePlaymode)
        {
            S005ManualDriverDiagnostic1278.Close();S005ManualFogFallback1278.Stop("NativeClosed");S005StopManual1278.Close();EditorApplication.update-=Observe;Canvas.willRenderCanvases-=ObserveRendered;
            Append(new Row{stage="ClosedObserver",setupSeen=setupSeen,bindingSeen=bindingSeen,purposeSeen=purposeSeen,activeControlSeen=activeControlSeen,manualPlaySeen=manualPlaySeen,resultSeen=resultSeen,returnSeen=returnSeen,tracePath=(string)TracePath.Invoke(null,null)});
        }
        else if(EditorApplication.timeSinceStartup-began>1740)ObserverFailure(new TimeoutException("Observer deadline"));
    }
    static void ObserverFailure(Exception error)
    {
        Append(new Row{stage="ObserverFailure",reason=error.ToString()});Debug.LogError("[S005NormalStopManual1278] observerFailure=1");S005StopManual1278.Fail(error);
    }
    static void ObserveMainMenuDestination()
    {
        if(!resultSeen || !finishedVictorySeen || witnessedAttempt.Length==0 || !UiShellRuntimeGateway.TryReadShellState(out var shell) || shell.ActiveRoute!=Game.UI.Contracts.UIRoute.MainMenu || shell.IsTransitionRunning)return;
        var world=World.DefaultGameObjectInjectionWorld;if(world==null || !world.IsCreated)return;
        using(var query=world.EntityManager.CreateEntityQuery(typeof(SkirmishExpandedSessionComponent)))if(query.CalculateEntityCount()!=0)return;
        var shellView=UnityEngine.Object.FindAnyObjectByType<UIShellView>();
        bool obscured=shellView!=null && shellView.TryGetRegion(UIShellRegionId.LoadingLayer,out var loading) && loading.CanvasGroup!=null && loading.CanvasGroup.alpha>.01f;
        if(obscured)return;
        foreach(var route in UnityEngine.Object.FindObjectsByType<UIShellRouteButtonView>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
        {
            var button=route.GetComponent<Button>();var card=button?.transform.parent;
            if(button==null || card==null || card.name!="Card_Skirmish" || button.name!="Hotspot" || card.Find("Hotspot")!=button.transform ||
                route.Intent!=Game.UI.Contracts.UiShellRouteIntent.OpenMenuRoute || route.Route!=Game.UI.Contracts.UIRoute.QuickCustomSetup || !route.PushHistory || !Presented(button))continue;
            var text=card.Find("Title")?.GetComponent<TMP_Text>();
            if(text==null || text.transform.parent!=card || !Rendered(text) || !CopyMatches(text,"SKIRMISH"))continue;
            BoundText("MainMenuSkirmishControl",text,card);
            Append(new Row{stage="NativeMainMenuDestination",attempt=witnessedAttempt,finished=true,frozenVictory=true,renderedVictoryWitnessed=true,outcome="Victory",shellRoute=shell.ActiveRoute.ToString(),presentedControl=true,renderedBody=true,controlPath=PathOf(button.transform),controlText=Text(text),unobscuredDestination=true,destinationSessionAbsent=true,exactMainMenuOwner=true,exactMainMenuTitle=true,mainMenuIntent=route.Intent.ToString(),mainMenuRoute=route.Route.ToString(),mainMenuTitlePath=PathOf(text.transform),expectedMainMenuCaption=UiLocalizedText.CatalogLabel("SKIRMISH"),actualMainMenuCaption=text is RTLTMPro.RTLTextMeshPro rtl?rtl.OriginalText:text.text});returnSeen=true;
        }
    }

    static void ObserveRendered()
    {
        try
        {
            if(!EditorApplication.isPlaying)return;
            Canvas nativeCanvas=null;
            var matchView=UnityEngine.Object.FindAnyObjectByType<SkirmishMatchView>();
            if(matchView!=null)nativeCanvas=matchView.GetComponent<Canvas>();
            if(nativeCanvas==null)foreach(var candidate in UnityEngine.Object.FindObjectsByType<Canvas>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
                if(candidate.name=="GameUICanvas" && candidate.isRootCanvas){nativeCanvas=candidate;break;}
            if(nativeCanvas==null)return;
            Rect viewport=nativeCanvas.pixelRect,safe=Screen.safeArea;
            bool matched=Mathf.Abs(viewport.width-Screen.width)<=1f && Mathf.Abs(viewport.height-Screen.height)<=1f && safe.width>0 && safe.height>0;
            Append(new Row{stage="RenderedViewportContext",samplingPhase="CanvasWillRenderCanvases",ownerPath=PathOf(nativeCanvas.transform),nativeViewportMatched=matched,screenWidth=Screen.width,screenHeight=Screen.height,safeX=safe.x,safeY=safe.y,safeWidth=safe.width,safeHeight=safe.height,canvasX=viewport.x,canvasY=viewport.y,canvasWidth=viewport.width,canvasHeight=viewport.height});
            if(!matched)return; // Fail closed on foreign Editor-window coordinates; require a real native render viewport sample.
            if(EditorApplication.timeSinceStartup<next)return;
            next=EditorApplication.timeSinceStartup+.25d;
            foreach(var view in UnityEngine.Object.FindObjectsByType<QuickCustomScreenView>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
            {
                if(!view.IsBaseAssaultSetup || view.SelectedScenarioId!="S005")continue;
                var title=Label(view.transform,"SkirmishSetupComposition/OperationPreview/OperationName");
                var objective=Label(view.transform,"SkirmishSetupComposition/BaseAssaultRules/RulesScroll/Content/Objective");
                var roster=Label(view.transform,"SkirmishSetupComposition/BaseAssaultRules/RulesScroll/Content/Roster");
                var economy=Label(view.transform,"SkirmishSetupComposition/BaseAssaultRules/RulesScroll/Content/Economy");
                var intel=Label(view.transform,"SkirmishSetupComposition/BaseAssaultRules/RulesScroll/Content/Intel");
                var summary=Label(view.transform,"SkirmishSetupComposition/BaseAssaultRules/RulesScroll/Content/Opponent");
                BoundText("SetupTitle",title,view.transform); BoundText("SetupObjective",objective,view.transform);
                var config=view.ReadConfigFromControls();
                Append(new Row{stage="NativeSetupBriefing",finished=finishedVictorySeen,frozenVictory=finishedVictorySeen,renderedVictoryWitnessed=resultSeen,outcome=finishedVictorySeen?"Victory":"",attempt=finishedVictorySeen?witnessedAttempt:"",catalog=view.SelectedScenarioId,seed=config.MapSeed,title=Text(title),objective=Text(objective),roster=Text(roster),economy=Text(economy),intel=Text(intel),summary=Text(summary),localizedObjectiveCopy=CopyMatches(objective,"Destroy the original enemy Barracks and protect yours. If both survive until time runs out, the match is a draw."),renderedTitle=Rendered(title),renderedObjective=Rendered(objective),renderedRoster=Rendered(roster),renderedEconomy=Rendered(economy),renderedIntel=Rendered(intel)});
                if(Rendered(title) && Rendered(objective) && !bindingSeen)setupSeen=true;
            }
            ObserveMainMenuDestination();
            var world=World.DefaultGameObjectInjectionWorld;
            if(world==null || !world.IsCreated)return;
            var em=world.EntityManager;
            bool nativeFrozenVictory=false; string nativeAttempt="";
            using(var query=em.CreateEntityQuery(typeof(SkirmishResolvedSetupRecord),typeof(SkirmishExpandedSessionComponent)))
            {
                if(query.CalculateEntityCount()!=1)return;
                var session=query.GetSingletonEntity();var state=em.GetComponentData<SkirmishExpandedSessionComponent>(session);var setup=em.GetComponentObject<SkirmishResolvedSetupRecord>(session).Setup;
                if(setup.CatalogId!="S005")throw new InvalidOperationException("Observed foreign normal session");
                nativeAttempt=state.SessionId.ToString();
                if(initialAttempt.Length==0)initialAttempt=nativeAttempt;
                else if(initialAttempt!=nativeAttempt)throw new InvalidOperationException("Native Continue changed normal manual attempt identity.");
                if(em.HasComponent<SkirmishMatchState>(session) && em.HasComponent<SkirmishResultComponent>(session))
                {
                    var match=em.GetComponentData<SkirmishMatchState>(session);var result=em.GetComponentData<SkirmishResultComponent>(session);
                    nativeFrozenVictory=match.Phase==SkirmishPhase.Finished && match.Outcome==SkirmishOutcome.Victory && result.Frozen!=0 && result.Outcome==Game.Skirmish.Contracts.SkirmishOutcomeKind.Victory && result.SessionId.Equals(state.SessionId);
                }
                if(!bindingSeen)
                {
                    Append(new Row{stage="ActualResolvedBinding",catalog=setup.CatalogId,definition=setup.DefinitionId,size=setup.SizeId.ToString(),difficulty=setup.DifficultyId.ToString(),army=setup.ArmyProfileId.ToString(),start=setup.StartPackageId.ToString(),readiness=setup.Readiness.ToString(),readinessValue=(int)setup.Readiness,seed=setup.Seed,deadline=setup.DeadlineSeconds,objective=setup.ObjectiveKind.ToString(),sharedFog=setup.SharedFog,developmentFullVision=setup.DevelopmentFullVision,attempt=state.SessionId.ToString(),tracePath=(string)TracePath.Invoke(null,null)});
                    bindingSeen=true;
                }
                if(em.HasBuffer<SkirmishProductionReservation>(session))foreach(var receipt in em.GetBuffer<SkirmishProductionReservation>(session,true))
                {
                    string key=receipt.FactionId+":"+receipt.ReservationId+":"+receipt.Phase+":"+receipt.DeliveredMembers;
                    if(!receiptStates.Add(key))continue;
                    int cost=0;foreach(var overlay in setup.RoleOverlays)if(overlay.RoleKind==receipt.Role){cost=overlay.MaterialsCost;break;}
                    Append(new Row{stage="NativePaidReservation",attempt=state.SessionId.ToString(),reservation=receipt.ReservationId,faction=receipt.FactionId,role=receipt.Role.ToString(),phase=receipt.Phase.ToString(),producer=receipt.ProducerRuntimeId,materialsPaid=receipt.MaterialsPaid,expectedCost=cost,members=receipt.MemberCount,deliveredMembers=receipt.DeliveredMembers});
                }
            }
            if(!UiShellRuntimeGateway.TryReadSkirmish(out var model))return;
            bool active=UiShellRuntimeGateway.ReadAriaPlay().Active;

            foreach(var briefing in UnityEngine.Object.FindObjectsByType<AriaTutorialBriefingView>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
            {
                if(!briefing.IsPresentationVisible)continue;
                BoundText("HudPurposeTitle",briefing.TitleText,briefing.transform); BoundText("HudPurposeBody",briefing.BodyText,briefing.transform);
                bool title=Rendered(briefing.TitleText),body=Rendered(briefing.BodyText);
                Append(new Row{stage="NativeHudPurpose",localizedPurposeCopy=CopyMatches(briefing.BodyText,"Destroy the original enemy Barracks and defend yours. Advance with armor and infantry, or upgrade readiness and build a Helipad. Squad card → Attack → target."),title=Text(briefing.TitleText),body=Text(briefing.BodyText),renderedTitle=title,renderedBody=body,ariaActive=active,finished=model.Finished,modelObjective=model.Objective,expanded=model.Expanded,combinedArmsField=model.CombinedArmsField});
                if(title&&body&&!active)purposeSeen=true;
            }
            foreach(var button in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
            {
                if(button.name!="WatchAriaPlay" && button.name!="AriaInstantStop")continue;
                bool presented=Presented(button);var label=button.GetComponentInChildren<TMP_Text>();
                BoundText("AriaControl",label,button.transform);
                Append(new Row{stage="NativeAriaControl",localizedStopCopy=CopyMatches(label,active?"STOP ARIA":"PLAY ARIA"),controlPath=PathOf(button.transform),controlText=Text(label),presentedControl=presented,renderedBody=Rendered(label),ariaActive=active,finished=model.Finished});
                if(!active && presented && Rendered(label))manualPlaySeen=true; if(active && presented && Rendered(label) && CopyMatches(label,"STOP ARIA"))activeControlSeen=true;
            }
            foreach(var view in UnityEngine.Object.FindObjectsByType<SkirmishMatchView>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))
            {
                var strip=view.transform.Find("BaseObjectives");bool own=false,enemy=false,clock=false;
                if(strip!=null)foreach(var t in strip.GetComponentsInChildren<TMP_Text>()) BoundText("ObjectiveStrip",t,strip);
                var ownLabel=NativePlayerLabel.GetValue(view) as TMP_Text;
                var enemyLabel=NativeEnemyLabel.GetValue(view) as TMP_Text;
                var clockLabel=NativeClockLabel.GetValue(view) as TMP_Text;
                bool ownBinding=ownLabel!=null && view.PlayerFocusButton!=null && ownLabel.GetComponentInParent<Button>()==view.PlayerFocusButton;
                bool enemyBinding=enemyLabel!=null && view.EnemyFocusButton!=null && enemyLabel.GetComponentInParent<Button>()==view.EnemyFocusButton;
                bool clockBinding=clockLabel!=null && strip!=null && clockLabel.transform.parent==strip;
                string ownCaption=UiShellRuntimeGateway.Localization.IsRightToLeft ? "پایگاه شما" : "YOUR BASE";
                string enemyCaption=UiShellRuntimeGateway.Localization.IsRightToLeft ? "پایگاه دشمن" : "ENEMY BASE";
                string nativeClockSource=clockLabel?.GetComponent<V3LocalizedTextBindingView>()?.SourceValue??"";
                string modelNumeric=ClockNumber(model.Clock), nativeNumeric=ClockNumber(nativeClockSource);
                bool clockCurrent=modelNumeric.Length>0 && nativeNumeric==modelNumeric && CopyMatches(clockLabel,model.Clock);
                own=ownBinding && Rendered(ownLabel) && CopyMatches(ownLabel,ownCaption);
                enemy=enemyBinding && Rendered(enemyLabel) && CopyMatches(enemyLabel,enemyCaption);
                clock=clockBinding && Rendered(clockLabel) && clockCurrent;
                BoundText("PlayerBaseCaption",ownLabel,view.PlayerFocusButton?.transform);
                BoundText("EnemyBaseCaption",enemyLabel,view.EnemyFocusButton?.transform);
                BoundText("CurrentMatchClock",clockLabel,strip);
                Append(new Row{stage="NativeObjectiveStrip",ariaActive=active,finished=model.Finished,renderedPlayerBase=own,renderedEnemyBase=enemy,renderedClock=clock,playerBase=model.PlayerBase,enemyBase=model.EnemyBase,clock=model.Clock,modelObjective=model.Objective,exactPlayerBinding=ownBinding,exactEnemyBinding=enemyBinding,exactClockBinding=clockBinding,clockNumberPresentAndCurrent=clockCurrent,expectedPlayerCaption=ownCaption,expectedEnemyCaption=enemyCaption,actualPlayerCaption=Text(ownLabel),actualEnemyCaption=Text(enemyLabel),actualClockText=Text(clockLabel),nativeClockSource=nativeClockSource,modelClockNumber=modelNumeric,nativeClockNumber=nativeNumeric});
                if(model.Finished)
                {
                    var result=view.transform.Find("SkirmishResult/CampaignStyleResult");
                    if(result!=null)foreach(var text in result.GetComponentsInChildren<TMP_Text>())if(Rendered(text))
                    {BoundText("ResultText",text,result);bool victoryCopy=string.Equals(Text(text),"VICTORY",StringComparison.OrdinalIgnoreCase);Append(new Row{stage="NativeRenderedResultText",localizedVictoryCopy=victoryCopy,title=Text(text),renderedTitle=true,finished=model.Finished,frozenVictory=nativeFrozenVictory,outcome=nativeFrozenVictory?"Victory":"",attempt=nativeAttempt,renderedVictoryWitnessed=nativeFrozenVictory && victoryCopy});if(model.Finished && nativeFrozenVictory && victoryCopy){resultSeen=finishedVictorySeen=true;witnessedAttempt=nativeAttempt;}}
                }
            }
        }
        catch(Exception error)
        {
            ObserverFailure(error);
        }
    }
}

// External QA companion template. Instantiate unique class per immutable run.
// Same native manualTouch only; validation manualDue wall-schedule lease is restored exactly.
// No gameplay API, selection/component/order writes, simulation clock, resources, poses, vision or outcomes.
public static class S005ManualFogFallback1278
{
    const string Root="/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/";
    const string Evidence=Root+"native1278-manual-fog-fallback.jsonl";
    static readonly System.Reflection.FieldInfo Driver=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("manualTouch",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo Due=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("manualDue",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo Actions=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("manualActions",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo Step=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("manualStep",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo Slot=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("manualSlot",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.MethodInfo ReadPoint=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetMethod("TryPresentedButtonPoint",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo ResumeActive=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("playerResumeProbeActive",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo ResumeStep=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("playerResumeStep",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static readonly System.Reflection.FieldInfo ResumeTouch=typeof(Game.Editor.SkirmishS002AriaRunHarness).GetField("playerResumeTouch",System.Reflection.BindingFlags.NonPublic|System.Reflection.BindingFlags.Static);
    static Game.UI.Runtime.AriaTouchInputUiSystemHelper touch;
    static System.Func<bool> permitted;
    static readonly System.Collections.Generic.List<Unity.Entities.Entity> cohort=new();
    static readonly System.Collections.Generic.Dictionary<Unity.Entities.Entity,string> ids=new();
    static readonly System.Collections.Generic.Dictionary<Unity.Entities.Entity,UnityEngine.Vector3> starts=new();
    static bool lease,started,failed,saveHandoffRecorded,terminalClosureRecorded;
    static string attempt="",failure="";
    static int round,phase,candidate,cameraStep,cameraCommandsBefore,commandsBefore,acceptCount,acceptBefore,contactFrame;
    static uint receipt;
    static int lastMoveReceiptFrame;
    static double originalDue,deadline,next,sampleNext;
    static UnityEngine.Vector3 objective,player,site;
    [System.Serializable] public sealed class Row
    {
        public string stage="",attempt="",id="",role="",operation="",reason="",scope="ExternalScriptedNormalTouchFogApproachNotHumanAcceptance";
        public int frame,round,phase,candidate,commandsBefore,commandsAfter,members,resumeStep;
        public uint oldCompleted,oldDispatched;
        public uint receipt;
        public float elapsed,timeScale,x,z,startX,startZ,displacement,speed,goalX,goalZ,enemyObjectiveX,enemyObjectiveZ,playerObjectiveX,playerObjectiveZ;
        public double originalDue,leasedDue;
        public bool markerVisible,targetVisible,sameDriver,restoredExact,verified,cameraOnly,selected,alive,safeArea,noUiHit,oldStopped,oldBusy,newRunning,newBusy,resumeActive,manualAbsent,nativeFinished,nativeVictory,resultFrozen;
    }
    static void Write(Row r){r.frame=UnityEngine.Time.frameCount;r.timeScale=UnityEngine.Time.timeScale;r.attempt=attempt;r.round=round;r.candidate=candidate;System.IO.File.AppendAllText(Evidence,UnityEngine.JsonUtility.ToJson(r)+"\n");}
    public static void Start(System.Func<bool> gate)
    {
        if(started)throw new System.InvalidOperationException("Fallback already started");
        if(Driver==null||Due==null||Actions==null||Step==null||Slot==null||ReadPoint==null||ResumeActive==null||ResumeStep==null||ResumeTouch==null)throw new System.MissingMemberException("Existing manual QA input bridge absent");
        if(System.IO.File.Exists(Evidence))throw new System.IO.IOException("Preserve fallback evidence");
        using(System.IO.File.Open(Evidence,System.IO.FileMode.CreateNew,System.IO.FileAccess.Write,System.IO.FileShare.Read)){}
        permitted=gate;started=true;lease=failed=saveHandoffRecorded=terminalClosureRecorded=false;round=phase=candidate=cameraStep=acceptCount=0;failure="";attempt="";
        Game.Runtime.AriaCommandEvidence.Recorded+=OnReceipt;UnityEditor.EditorApplication.update+=Tick;
        Write(new Row{stage="Protocol",reason="WaitingForUnavailablePublicTarget actual public QA step3; objective geometry only; legal12/18/24m terrain AttackMove candidates; same manualTouch, exact wall-schedule restore"});
    }
    static void OnReceipt(string operation,uint id,bool verified)
    {
        if(!lease)return;
        if(operation=="ArmyAttack" && verified && id!=0 && id==receipt && UnityEngine.Time.frameCount==lastMoveReceiptFrame)
        {Write(new Row{stage="NativeReceiptAlias",operation=operation,receipt=id,verified=true,reason="PairedSameFrameAttackMoveScope"});return;}
        Write(new Row{stage="NativeReceipt",operation=operation,receipt=id,verified=verified});
        if(!verified||id==0||operation!="AttackMove"){failure="Unexpected/unverified native fallback receipt:"+operation;return;}
        acceptCount++;receipt=id;lastMoveReceiptFrame=UnityEngine.Time.frameCount;
    }
    static void Restore(string reason)
    {
        if(!lease)return;
        bool same=object.ReferenceEquals(Driver.GetValue(null),touch);Due.SetValue(null,originalDue);
        Write(new Row{stage="LeaseRestored",reason=reason,sameDriver=same,restoredExact=(double)Due.GetValue(null)==originalDue,originalDue=originalDue,receipt=receipt});
        lease=false;phase=cameraStep=0;next=UnityEditor.EditorApplication.timeSinceStartup+20;
        if(!same)failure="Input owner changed during fallback";
    }
    static bool TryReleaseVerifiedSaveHandoff(Game.Components.SkirmishExpandedSessionComponent state)
    {
        if(!lease||state.SessionId.ToString()!=attempt||(bool)ResumeActive.GetValue(null)!=true||(int)ResumeStep.GetValue(null)!=1||Driver.GetValue(null)!=null)return false;
        var successor=ResumeTouch.GetValue(null) as Game.UI.Runtime.AriaTouchInputUiSystemHelper;
        if(touch==null||touch.IsRunning||touch.IsBusy||touch.PlayerInterrupted||touch.UnexpectedSamples!=0||touch.PhysicalInterventions!=0||touch.DispatchedGestures!=touch.CompletedGestures||successor==null||object.ReferenceEquals(successor,touch)||!successor.IsRunning||successor.IsBusy||successor.PlayerInterrupted||successor.UnexpectedSamples!=0||successor.PhysicalInterventions!=0||!UnityEngine.Mathf.Approximately(UnityEngine.Time.timeScale,1)||Game.UI.Runtime.UiShellRuntimeGateway.ReadAriaPlay().Active)return false;
        // The native Save driver owns playerResumeDue; restore only the now-inactive manual scheduler.
        Due.SetValue(null,originalDue);
        Write(new Row{stage="SaveHandoff",reason="VerifiedNativeCombatSaveHandoff",sameDriver=false,restoredExact=(double)Due.GetValue(null)==originalDue,originalDue=originalDue,receipt=receipt,resumeActive=true,resumeStep=1,manualAbsent=true,oldStopped=true,oldBusy=false,newRunning=true,newBusy=false,oldCompleted=touch.CompletedGestures,oldDispatched=touch.DispatchedGestures});
        saveHandoffRecorded=true;lease=false;phase=cameraStep=0;next=UnityEditor.EditorApplication.timeSinceStartup+20;
        return true;
    }
    static bool TryReleaseVerifiedTerminal(Unity.Entities.EntityManager em,Unity.Entities.Entity entity,Game.Components.SkirmishExpandedSessionComponent state,Game.Components.SkirmishMatchState match)
    {
        if(!lease||state.CatalogId.ToString()!="S005"||state.SessionId.ToString()!=attempt||match.Phase!=Game.Components.SkirmishPhase.Finished||match.Outcome!=Game.Components.SkirmishOutcome.Victory||!em.HasComponent<Game.Components.SkirmishResultComponent>(entity)||phase!=4||receipt==0||acceptCount<=acceptBefore||failure.Length!=0||touch==null||touch.IsBusy||touch.PlayerInterrupted||touch.UnexpectedSamples!=0||touch.PhysicalInterventions!=0||touch.DispatchedGestures!=touch.CompletedGestures)return false;
        var result=em.GetComponentData<Game.Components.SkirmishResultComponent>(entity);if(result.Frozen==0||result.Outcome!=Game.Skirmish.Contracts.SkirmishOutcomeKind.Victory||!result.SessionId.Equals(state.SessionId))return false;
        var current=Driver.GetValue(null);if(current!=null&&!object.ReferenceEquals(current,touch))return false;
        if(current==null&&touch.IsRunning)return false;
        Due.SetValue(null,originalDue);
        Write(new Row{stage="TerminalClosure",reason="VerifiedNativeFrozenVictory",sameDriver=object.ReferenceEquals(current,touch),restoredExact=(double)Due.GetValue(null)==originalDue,originalDue=originalDue,receipt=receipt,oldBusy=false,oldCompleted=touch.CompletedGestures,oldDispatched=touch.DispatchedGestures,nativeFinished=true,nativeVictory=true,resultFrozen=true});
        terminalClosureRecorded=true;lease=false;phase=cameraStep=0;return true;
    }
    public static void Stop(string reason)
    {
        if(!started)return;Restore(reason);Game.Runtime.AriaCommandEvidence.Recorded-=OnReceipt;UnityEditor.EditorApplication.update-=Tick;
        Write(new Row{stage="Closed",reason=reason+(failed?";Failed:"+failure:""),sameDriver=!failed&&!saveHandoffRecorded&&!terminalClosureRecorded,restoredExact=!lease});started=false;
    }
    static bool Gesture(UnityEngine.Vector2 from,UnityEngine.Vector2 to,float travel=0)
    {
        if(!touch.TryGesture(from,to,.15f,travel,UnityEngine.Time.unscaledTime))return false;
        Actions.SetValue(null,(int)Actions.GetValue(null)+1);next=UnityEditor.EditorApplication.timeSinceStartup+.8;return true;
    }
    static bool Tap(UnityEngine.UI.Button b)
    {
        if(b==null)return false;var args=new object[]{b,default(UnityEngine.Vector2)};
        if(!(bool)ReadPoint.Invoke(null,args))return false;var p=(UnityEngine.Vector2)args[1];return Gesture(p,p);
    }
    static bool Ground(out UnityEngine.Vector2 point)
    {
        point=default;var c=UnityEngine.Camera.main;if(c==null)return false;var p=c.WorldToScreenPoint(site);if(p.z<=0)return false;point=p;
        var popup=UnityEngine.Object.FindAnyObjectByType<Game.UI.Runtime.MatchHudFullMapPopupView>(UnityEngine.FindObjectsInactive.Include);if(popup!=null&&popup.IsOpen)return false;
        var es=UnityEngine.EventSystems.EventSystem.current;if(es==null)return false;var hits=new System.Collections.Generic.List<UnityEngine.EventSystems.RaycastResult>();
        es.RaycastAll(new UnityEngine.EventSystems.PointerEventData(es){position=point},hits);return UnityEngine.Screen.safeArea.Contains(point)&&hits.Count==0;
    }
    static bool CameraOnly()
    {
        if(cameraStep==0)
        {
            if(Game.UI.Runtime.UiShellRuntimeGateway.TryReadMatchHudCommandState(out var mode)&&mode.ActiveCommandMode!=Game.Tactical.Contracts.TacticalCommandMode.Select)
            {var controls=UnityEngine.Object.FindAnyObjectByType<Game.UI.Runtime.MatchOverlayCommandControlsView>();Tap(controls?.SelectButton);return false;}
            cameraCommandsBefore=Game.Runtime.AriaCommandEvidence.AcceptedCommands;cameraStep=1;
        }
        var popup=UnityEngine.Object.FindAnyObjectByType<Game.UI.Runtime.MatchHudFullMapPopupView>(UnityEngine.FindObjectsInactive.Include);
        if(popup==null||!popup.IsOpen)
        {
            if(cameraStep==3){int after=Game.Runtime.AriaCommandEvidence.AcceptedCommands;Write(new Row{stage="CameraClosed",commandsBefore=cameraCommandsBefore,commandsAfter=after,cameraOnly=after==cameraCommandsBefore});if(after!=cameraCommandsBefore)throw new System.InvalidOperationException("Camera issued troop order");cameraStep=0;return true;}
            foreach(var map in UnityEngine.Object.FindObjectsByType<Game.UI.Runtime.MatchHudMinimapView>(UnityEngine.FindObjectsSortMode.None))
            {if(map.GetComponentInParent<Game.UI.Runtime.MatchHudFullMapPopupView>()!=null||map.MapRect==null)continue;var cv=map.GetComponentInParent<UnityEngine.Canvas>();var c=cv!=null&&cv.renderMode!=UnityEngine.RenderMode.ScreenSpaceOverlay?cv.worldCamera:null;var p=UnityEngine.RectTransformUtility.WorldToScreenPoint(c,map.MapRect.TransformPoint(map.MapRect.rect.center));if(Gesture(p,p))return false;}
            return false;
        }
        if(cameraStep==3){Tap(popup.CloseAction);return false;}
        var full=popup.Minimap;if(full==null)return false;var canvas=full.GetComponentInParent<UnityEngine.Canvas>();var cam=canvas!=null&&canvas.renderMode!=UnityEngine.RenderMode.ScreenSpaceOverlay?canvas.worldCamera:null;
        if(!full.TryGetPresentedMapPoint(site,cam,out var goal))return false;bool drag=full.ViewportRect!=null&&UnityEngine.RectTransformUtility.RectangleContainsScreenPoint(full.ViewportRect,goal,cam);
        var from=drag?UnityEngine.RectTransformUtility.WorldToScreenPoint(cam,full.ViewportRect.TransformPoint(full.ViewportRect.rect.center)):goal;var end=drag&&(from-goal).sqrMagnitude<=25?goal+UnityEngine.Vector2.up*12:goal;
        if(Gesture(from,end,drag ? .45f : 0f)){cameraStep=3;Write(new Row{stage="CameraTouch",goalX=site.x,goalZ=site.z,cameraOnly=true,commandsBefore=cameraCommandsBefore});}return false;
    }
    static void CandidateSite()
    {
        var forward=objective-player;forward.y=0;if(forward.sqrMagnitude<1)throw new System.InvalidOperationException("Public objective geometry absent");forward.Normalize();
        var side=UnityEngine.Vector3.Cross(UnityEngine.Vector3.up,forward);site=objective-forward*(12+candidate*6)+side*6;site.y=0;
    }
    static void BindCohort(Unity.Entities.EntityManager em,Game.Components.SkirmishExpandedSessionComponent session)
    {
        cohort.Clear();ids.Clear();starts.Clear();
        using var q=em.CreateEntityQuery(typeof(Game.Components.SelectedUnitTag),typeof(Game.Components.SkirmishAttemptOwnedComponent),typeof(Game.Components.UnitHealth),typeof(Unity.Transforms.LocalTransform),typeof(Game.Components.UnitMove),typeof(Game.Components.SkirmishUnitRoleComponent));using var list=q.ToEntityArray(Unity.Collections.Allocator.Temp);
        foreach(var e in list)
        {
            var o=em.GetComponentData<Game.Components.SkirmishAttemptOwnedComponent>(e);if(o.FactionId!=1||!o.SessionId.Equals(session.SessionId)||o.IsStructure!=0||em.GetComponentData<Game.Components.UnitHealth>(e).Current<=0||em.HasComponent<Game.Components.UnitAirMovement>(e))throw new System.InvalidOperationException("Fallback selected cohort not live own current ground unit");
            cohort.Add(e);ids.Add(e,o.StableObjectId.ToString());starts.Add(e,em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position);
        }
        if(cohort.Count==0)throw new System.InvalidOperationException("Actual public selection cohort absent");
    }
    static bool Sample(Unity.Entities.EntityManager em,float elapsed,bool visible,bool targetVisible)
    {
        int live=0;foreach(var e in cohort)
        {
            if(!em.Exists(e)||!em.HasComponent<Game.Components.UnitHealth>(e)||!em.HasComponent<Unity.Transforms.LocalTransform>(e))continue;
            var o=em.GetComponentData<Game.Components.SkirmishAttemptOwnedComponent>(e);if(o.FactionId!=1||o.SessionId.ToString()!=attempt||o.StableObjectId.ToString()!=ids[e])throw new System.InvalidOperationException("Fallback actor identity changed");
            var p=(UnityEngine.Vector3)em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position;var s=starts[e];bool alive=em.GetComponentData<Game.Components.UnitHealth>(e).Current>0;if(alive)live++;
            var role=em.GetComponentData<Game.Components.SkirmishUnitRoleComponent>(e).Role;
            Write(new Row{stage="Actor",id=ids[e],role=role.ToString(),x=p.x,z=p.z,startX=s.x,startZ=s.z,displacement=UnityEngine.Vector2.Distance(new UnityEngine.Vector2(p.x,p.z),new UnityEngine.Vector2(s.x,s.z)),speed=em.GetComponentData<Game.Components.UnitMove>(e).Speed,elapsed=elapsed,markerVisible=visible,targetVisible=targetVisible,selected=em.HasComponent<Game.Components.SelectedUnitTag>(e),alive=alive,receipt=receipt});
        }
        return live>0;
    }
    static void Tick()
    {
        try
        {
            if(!started||failed||!UnityEditor.EditorApplication.isPlaying)return;double now=UnityEditor.EditorApplication.timeSinceStartup;
            if(failure.Length>0)throw new System.InvalidOperationException(failure);
            var w=Unity.Entities.World.DefaultGameObjectInjectionWorld;if(w==null||!w.IsCreated){if(lease)throw new System.InvalidOperationException("World lost during fallback lease");return;}var em=w.EntityManager;
            using var sessions=em.CreateEntityQuery(typeof(Game.Components.SkirmishExpandedSessionComponent),typeof(Game.Components.SkirmishMatchState));if(sessions.CalculateEntityCount()==0){if(lease)throw new System.InvalidOperationException("Session lost during fallback lease");return;}if(sessions.CalculateEntityCount()!=1)throw new System.InvalidOperationException("Unique actual S005 session required");var session=sessions.GetSingletonEntity();var match=em.GetComponentData<Game.Components.SkirmishMatchState>(session);var state=em.GetComponentData<Game.Components.SkirmishExpandedSessionComponent>(session);
            if(match.Phase!=Game.Components.SkirmishPhase.Playing){if(lease&&!TryReleaseVerifiedTerminal(em,session,state,match))throw new System.InvalidOperationException("Unverified native phase change during fallback lease");return;}
            if(state.CatalogId.ToString()!="S005")throw new System.InvalidOperationException("Foreign actual session");var hud=UnityEngine.Object.FindAnyObjectByType<Game.UI.Runtime.SkirmishMatchView>();if(hud==null)return;
            if(!lease&&!S005NativeIntroReady1278.Ready(em))return;
            if(lease)
            {
                if(!object.ReferenceEquals(Driver.GetValue(null),touch)&&TryReleaseVerifiedSaveHandoff(state))return;
                if(state.SessionId.ToString()!=attempt||!object.ReferenceEquals(Driver.GetValue(null),touch)||!UnityEngine.Mathf.Approximately(UnityEngine.Time.timeScale,1)||Game.UI.Runtime.UiShellRuntimeGateway.ReadAriaPlay().Active)throw new System.InvalidOperationException("Actual input/attempt/normal speed/ARIA changed");
                if(now>=sampleNext){bool live=Sample(em,match.ElapsedSeconds,hud.EnemyBaseMarkerVisible,hud.EnemyBaseTargetVisible);sampleNext=now+.5;if(!live){Restore("CohortLost");return;}}
                if(touch.IsBusy||now<next)return;
                if(touch.PlayerInterrupted||!touch.IsRunning||touch.UnexpectedSamples!=0)throw new System.InvalidOperationException("Fallback Touch interrupted");
                if(now>deadline)throw new System.TimeoutException("Native public approach failed natural visibility within180s; manual timeout unchanged");
                if(cameraStep!=0){CameraOnly();return;}
                if(phase==4)
                {
                    if(hud.EnemyBaseMarkerVisible&&hud.EnemyBaseTargetVisible){Sample(em,match.ElapsedSeconds,true,true);Write(new Row{stage="NaturalVisibility",markerVisible=true,targetVisible=true,receipt=receipt,elapsed=match.ElapsedSeconds,members=cohort.Count});Restore("NaturalVisibleMarkerThenUnchangedManualAttack");return;}
                    return;
                }
                var controls=UnityEngine.Object.FindAnyObjectByType<Game.UI.Runtime.MatchOverlayCommandControlsView>();if(controls==null)return;
                if(phase==1){if(!Ground(out _)){CameraOnly();return;}if(!Game.UI.Runtime.UiShellRuntimeGateway.TryReadMatchHudCommandState(out var mode)||mode.ActiveCommandMode!=Game.Tactical.Contracts.TacticalCommandMode.Attack){Tap(controls.AttackButton);return;}phase=2;}
                if(phase==2)
                {
                    if(!Ground(out var p)){phase=1;return;}if(!Game.UI.Runtime.UiShellRuntimeGateway.TryReadMatchHudCommandState(out var mode)||mode.ActiveCommandMode!=Game.Tactical.Contracts.TacticalCommandMode.Attack){phase=1;return;}
                    acceptBefore=acceptCount;contactFrame=UnityEngine.Time.frameCount;if(Gesture(p,p)){Write(new Row{stage="GroundTouch",goalX=site.x,goalZ=site.z,safeArea=true,noUiHit=true,members=cohort.Count});phase=3;}return;
                }
                if(phase==3)
                {
                    if(acceptCount<=acceptBefore)
                    {
                        if(UnityEngine.Time.frameCount-contactFrame<=180)return;Write(new Row{stage="RejectedApproach",reason="No native accepted AttackMove",goalX=site.x,goalZ=site.z});if(++candidate>=3)throw new System.InvalidOperationException("All3 public ground approach candidates rejected");CandidateSite();phase=1;return;
                    }
                    Write(new Row{stage="AdvanceAccepted",receipt=receipt,verified=true,goalX=site.x,goalZ=site.z,elapsed=match.ElapsedSeconds,members=cohort.Count});phase=4;
                }
                return;
            }
            if(!permitted()||now<next||(int)Step.GetValue(null)!=3||(hud.EnemyBaseMarkerVisible&&hud.EnemyBaseTargetVisible)||!Game.UI.Runtime.UiShellRuntimeGateway.TryReadExpandedSquadPage(out var page))return;
            int slot=(int)Slot.GetValue(null);if(slot<0||slot>=5||(page.SelectedMask&(1<<slot))==0||(page.AssaultMask&(1<<slot))==0)return;
            var actual=Driver.GetValue(null) as Game.UI.Runtime.AriaTouchInputUiSystemHelper;if(actual==null||actual.IsBusy)return;
            if(++round>12)throw new System.InvalidOperationException("Bounded normal public fog approach attempts exhausted");
            attempt=state.SessionId.ToString();touch=actual;originalDue=(double)Due.GetValue(null);deadline=now+180;Due.SetValue(null,deadline+5);lease=true;
            objective=hud.EnemyBaseObjectivePosition;player=hud.PlayerBaseObjectivePosition;candidate=0;CandidateSite();BindCohort(em,state);receipt=0;phase=1;sampleNext=0;
            Write(new Row{stage="LeaseStarted",reason="WaitingForUnavailablePublicTarget",markerVisible=hud.EnemyBaseMarkerVisible,targetVisible=hud.EnemyBaseTargetVisible,sameDriver=true,originalDue=originalDue,leasedDue=deadline+5,members=cohort.Count,enemyObjectiveX=objective.x,enemyObjectiveZ=objective.z,playerObjectiveX=player.x,playerObjectiveZ=player.z,goalX=site.x,goalZ=site.z,elapsed=match.ElapsedSeconds});
        }
        catch(System.Exception error)
        {
            failed=true;failure=error.ToString();Write(new Row{stage="Failure",reason=failure});Restore("CompanionFailure");Game.Runtime.AriaCommandEvidence.Recorded-=OnReceipt;UnityEditor.EditorApplication.update-=Tick;
            UnityEngine.Debug.LogError("[S005ManualFogFallback1278] failed=1 nativeGameplayUntouched=1 reason="+error.Message);
        }
    }
}

// Read-only authoritative readiness; no layout, timing or gameplay writes.
public static class S005NativeIntroReady1278
{
    public static bool Ready(Unity.Entities.EntityManager em)
    {
        using var q=em.CreateEntityQuery(typeof(Game.UI.Shell.Contracts.Ecs.MatchIntroTransitionComponent));
        if(q.CalculateEntityCount()!=1)return false;var e=q.GetSingletonEntity();
        if(!em.HasComponent<Game.UI.Shell.Contracts.Ecs.UiShellStateComponent>(e))return false;
        var state=em.GetComponentData<Game.UI.Shell.Contracts.Ecs.MatchIntroTransitionComponent>(e);
        if(state.State!=Game.UI.Contracts.MatchIntroTransitionStateKind.Complete||state.InputLocked!=0)return false;
        using var finale=em.CreateEntityQuery(typeof(Game.Components.CampaignMissionFinalePresentationComponent));
        if(finale.CalculateEntityCount()==1){var f=finale.GetSingleton<Game.Components.CampaignMissionFinalePresentationComponent>();if(f.Required!=0&&f.Stage is >=1 and <=3)return false;}
        return true;
    }
}

// Native QA control only: reflects existing validation schedules and actuates real Touch.
// No gameplay component, stock, order, health, pose, fog or outcome writes.
public static class S005StopManual1278
{
    const string Evidence="/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/native1278-stop-manual-controls.jsonl";
    const BindingFlags Private=BindingFlags.NonPublic|BindingFlags.Static;
    static readonly Type Harness=typeof(SkirmishS002AriaRunHarness);
    static readonly FieldInfo Stage=Harness.GetField("stage",Private),Driver=Harness.GetField("manualTouch",Private),Actions=Harness.GetField("manualActions",Private),Due=Harness.GetField("manualDue",Private);
    static readonly MethodInfo StartManual=Harness.GetMethod("StartS004ManualProbe",Private),ReadPoint=Harness.GetMethod("TryPresentedButtonPoint",Private),Finish=Harness.GetMethod("Finish",Private),NativeTick=Harness.GetMethod("Tick",Private);
    static readonly Type ManualFrameType=Harness.Assembly.GetType("Game.Editor.SkirmishS004ManualInputFrame",true);
    static readonly FieldInfo AriaDriver=typeof(Game.UI.Shell.Ecs.AriaPlayInputSystem).GetField("touch",BindingFlags.NonPublic|BindingFlags.Instance);
    static readonly List<Entity> cohort=new();static readonly Dictionary<Entity,string> ids=new();static readonly Dictionary<Entity,Vector3> origins=new();static readonly Dictionary<Entity,Unity.Transforms.LocalTransform> pausedPoses=new();
    static readonly Dictionary<uint,Game.Skirmish.Contracts.SkirmishGroupOrderKind> oldOrders=new();
    static AriaTouchInputUiSystemHelper oldTouch,touch;static Game.UI.Shell.Ecs.AriaPlayInputSystem ariaSystem;static MonoBehaviour manualFrame;
    static EditorApplication.CallbackFunction nativeCallback;
    static string attempt="",originalManual,originalTerminal,failure="";static int step,lastFrame=-1,moveNumber,receiptFrame,commandsBeforeStop,cameraStep,cameraCommandsBefore;
    static uint groupId,receipt,oldCompleted,holdBefore;static int actualMembers,ariaTroopCommands;static float elapsed,heldElapsed,pausedElapsed,phaseElapsed;static double due,deadline,pausedAt;static bool started,failed,controlsPassed,frameWasEnabled,tickRemoved;
    static Vector3 site,publicPlayer,publicEnemy;static double originalManualDue;
    [Serializable] public sealed class Row
    {
        public string stage="",attempt="",reason="",operation="",id="",role="",order="",phase="",owner="";
        public int frame,step,moveNumber,members,actorHealth,commands,violations,stopBefore,stopAfter,receiptFrame,oldCommands,intentActive,intentTargetIndex,intentTargetVersion;
        public uint receipt,groupId,completed,dispatched,unexpected,interventions;
        public float elapsed,timeScale,dueMargin,x,y,z,qx,qy,qz,qw,scale,startX,startZ,displacement,goalX,goalZ,playerX,playerZ,enemyX,enemyZ,pausedElapsed,pausedWallSeconds;
        public bool verified,active,oldRunning,oldBusy,pressed,gestureRequested,auditMeasured,allAlive,allHeld,oldIntentCleared,allMoved,clockConserved,poseConserved,noOldOrderResurrection,qaOnly,sameAttempt,restoredExact,safeArea,noUiHit,normalSpeed,controlsPassed,hasMoveIntent,manualMoveMarker;
    }
    static void Write(Row r){r.frame=Time.frameCount;r.step=step;r.moveNumber=moveNumber;r.attempt=attempt;r.elapsed=elapsed;r.timeScale=Time.timeScale;File.AppendAllText(Evidence,JsonUtility.ToJson(r)+"\n");}
    public static void Start()
    {
        if(File.Exists(Evidence))throw new IOException("Preserve1278 controls evidence");using(File.Open(Evidence,FileMode.CreateNew,FileAccess.Write,FileShare.Read)){}
        if(Stage==null||Driver==null||Actions==null||Due==null||StartManual==null||ReadPoint==null||Finish==null||NativeTick==null||AriaDriver==null)throw new MissingMemberException("Native QA bridge absent");
        originalManual=Environment.GetEnvironmentVariable("WARLINE_S004_MANUAL_PROBE");originalTerminal=Environment.GetEnvironmentVariable("WARLINE_TERMINAL_ACTION");
        step=0;failed=controlsPassed=tickRemoved=false;lastFrame=-1;attempt=failure="";ariaTroopCommands=0;groupId=receipt=0;oldOrders.Clear();cohort.Clear();ids.Clear();origins.Clear();pausedPoses.Clear();deadline=EditorApplication.timeSinceStartup+180;due=0;
        started=true;AriaCommandEvidence.Recorded+=OnReceipt;AriaTouchInputUiSystemHelper.Evidence+=OnTouch;Canvas.willRenderCanvases+=Tick;
        Write(new Row{stage="Protocol",qaOnly=true,reason="NativeS005PlayConfirm→presentedStop→manualRifleMoveHoldPauseResumeMove→nativeVictoryMainMenu; not physical takeover/unattendedARIA"});
    }
    static void OnReceipt(string operation,uint id,bool verified)
    {
        try
        {
        if(!started)return;Write(new Row{stage="NativeReceipt",operation=operation,receipt=id,verified=verified});
        if(!verified||id==0){Fail(new InvalidOperationException("Unverified actual native command"));return;}
        if(step==0 && operation is "Move" or "AttackMove" or "ArmyAttack" or "SelectionOrder")ariaTroopCommands++;
        if(step==5&&operation=="Move")
        {
            receipt=id;receiptFrame=Time.frameCount;
            if(!TrySession(out var em,out _,out _))throw new InvalidOperationException("Native receipt world absent");
            foreach(var e in cohort){CheckActor(em,e);origins[e]=em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position;}
            Write(new Row{stage="MoveAccepted",receipt=id,receiptFrame=receiptFrame,groupId=groupId,members=cohort.Count,verified=true,sameAttempt=true});
        }

        }
        catch(Exception e){Fail(e);}

    }
    static void OnTouch(AriaTouchInputUiSystemHelper source,string kind,Vector2 position)
    {
        if(!started||step!=7||kind!="Ended"||!ReferenceEquals(source,touch))return;
        receiptFrame=Time.frameCount;
        Write(new Row{stage="HoldNativeEnded",owner="HoldButton",groupId=groupId,completed=source.CompletedGestures,dispatched=source.DispatchedGestures,unexpected=source.UnexpectedSamples,interventions=source.PhysicalInterventions,receiptFrame=receiptFrame,qaOnly=true});
    }
    static bool TrySession(out EntityManager em,out Entity session,out SkirmishMatchState match)
    {
        em=default;session=Entity.Null;match=default;var w=World.DefaultGameObjectInjectionWorld;if(w==null||!w.IsCreated)return false;em=w.EntityManager;
        using var q=em.CreateEntityQuery(typeof(SkirmishExpandedSessionComponent),typeof(SkirmishMatchState),typeof(SkirmishResolvedSetupRecord),typeof(SkirmishObjectiveClockComponent));if(q.CalculateEntityCount()!=1)return false;
        session=q.GetSingletonEntity();var s=em.GetComponentData<SkirmishExpandedSessionComponent>(session);match=em.GetComponentData<SkirmishMatchState>(session);
        var setup=em.GetComponentObject<SkirmishResolvedSetupRecord>(session).Setup;if(setup.CatalogId!="S005")throw new InvalidOperationException("Foreign normal mission");
        if(attempt.Length==0)attempt=s.SessionId.ToString();else if(attempt!=s.SessionId.ToString())throw new InvalidOperationException("Normal attempt changed");
        elapsed=em.GetComponentData<SkirmishObjectiveClockComponent>(session).ElapsedSeconds;return true;
    }
    static void Next(int phase,double seconds=45){step=phase;deadline=EditorApplication.timeSinceStartup+seconds;due=EditorApplication.timeSinceStartup+.35;}
    static bool Tap(Button b)
    {
        if(b==null)return false;var args=new object[]{b,default(Vector2)};if(!(bool)ReadPoint.Invoke(null,args))return false;Vector2 p=(Vector2)args[1];return Gesture(p,p);
    }
    static bool Gesture(Vector2 from,Vector2 to,float travel=0)
    {
        if(touch==null||!touch.TryGesture(from,to,.15f,travel,Time.unscaledTime))return false;
        Actions.SetValue(null,(int)Actions.GetValue(null)+1);due=EditorApplication.timeSinceStartup+.8;return true;
    }
    static void RequireTouch()
    {
        if(touch==null||!ReferenceEquals(touch,Driver.GetValue(null))||!touch.IsRunning||touch.PlayerInterrupted||touch.UnexpectedSamples!=0||touch.PhysicalInterventions!=0)throw new InvalidOperationException("Native manual Touch ownership/interruption changed");
    }
    static void BindCohort(EntityManager em,Entity session)
    {
        cohort.Clear();ids.Clear();origins.Clear();var s=em.GetComponentData<SkirmishExpandedSessionComponent>(session);
        using var q=em.CreateEntityQuery(typeof(SkirmishAttemptOwnedComponent),typeof(SkirmishArmyGroupMembershipComponent),typeof(UnitHealth),typeof(Unity.Transforms.LocalTransform),typeof(SkirmishUnitRoleComponent));using var entities=q.ToEntityArray(Unity.Collections.Allocator.Temp);
        int selected=0;foreach(var e in entities)
        {
            var o=em.GetComponentData<SkirmishAttemptOwnedComponent>(e);var m=em.GetComponentData<SkirmishArmyGroupMembershipComponent>(e);bool alive=em.GetComponentData<UnitHealth>(e).Current>0&&o.CapacityReleased==0;
            if(em.HasComponent<SelectedUnitTag>(e)&&alive){selected++;if(o.FactionId!=1||!o.SessionId.Equals(s.SessionId)||m.GroupId!=groupId)throw new InvalidOperationException("Mixed/foreign live selection");}
            if(o.FactionId!=1||!o.SessionId.Equals(s.SessionId)||m.GroupId!=groupId||!alive)continue;
            if(!em.HasComponent<SelectedUnitTag>(e)||em.GetComponentData<SkirmishUnitRoleComponent>(e).Role!=Game.Skirmish.Contracts.SkirmishRoleKind.Rifle||em.HasComponent<Disabled>(e)||em.HasComponent<UnitTransportPassenger>(e))throw new InvalidOperationException("Native whole Rifle cohort not selected/deployed");
            cohort.Add(e);ids[e]=o.StableObjectId.ToString();origins[e]=em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position;
        }
        if(cohort.Count!=actualMembers||selected!=actualMembers||actualMembers<=0)throw new InvalidOperationException("Whole card/cohort membership differs");
        Write(new Row{stage="SelectedWholeCohort",groupId=groupId,members=cohort.Count,allAlive=true,sameAttempt=true});
    }
    static void CheckActor(EntityManager em,Entity e)
    {
        if(!em.Exists(e)||!em.HasComponent<SkirmishAttemptOwnedComponent>(e)||!em.HasComponent<UnitHealth>(e)||!em.HasComponent<Unity.Transforms.LocalTransform>(e))throw new InvalidOperationException("Tracked native cohort actor gone");
        var o=em.GetComponentData<SkirmishAttemptOwnedComponent>(e);if(o.StableObjectId.Length==0||o.SessionId.ToString()!=attempt||o.StableObjectId.ToString()!=ids[e]||o.FactionId!=1||o.CapacityReleased!=0||em.GetComponentData<UnitHealth>(e).Current<=0||!em.HasComponent<SelectedUnitTag>(e))throw new InvalidOperationException("Tracked cohort authority/life/selection changed");
    }
    static bool Cleared(EntityManager em,Entity e)
    {
        bool clear=!em.HasComponent<UnitTarget>(e)&&!em.HasComponent<UnitPathRequest>(e)&&!em.HasComponent<UnitPathFollow>(e)&&!em.HasComponent<UnitPathRange>(e)&&!em.HasComponent<UnitPathRetryCooldown>(e)&&!em.HasComponent<UnitLongDistanceMove>(e)&&!em.HasComponent<ManualMoveGroupMemberTag>(e)&&!em.HasComponent<AttackMoveOrder>(e)&&!em.HasComponent<BaseBreachOrder>(e)&&!em.HasComponent<UnitTransportBoardingTarget>(e)&&!em.HasComponent<UnitTransportDeployOrder>(e)&&!em.HasComponent<SupportCollectOrderComponent>(e)&&!em.HasComponent<UnitResourceHaulOrder>(e);
        if(em.HasComponent<SkirmishMoveIntentComponent>(e)){var i=em.GetComponentData<SkirmishMoveIntentComponent>(e);clear &= i.Active==0&&i.Order==Game.Skirmish.Contracts.SkirmishGroupOrderKind.Hold&&i.AttackTarget==Entity.Null;}
        return clear; // Fresh defensive EngageTarget alone is permitted while held.
    }
    static bool Sample(EntityManager em,bool requireHold=false,bool requireMoved=false)
    {
        bool all=true;foreach(var e in cohort){CheckActor(em,e);var transform=em.GetComponentData<Unity.Transforms.LocalTransform>(e);Vector3 pos=transform.Position;var rotation=transform.Rotation.value;var from=origins[e];bool held=em.HasComponent<HoldPositionOrderTag>(e),clear=Cleared(em,e);float d=Vector2.Distance(new Vector2(pos.x,pos.z),new Vector2(from.x,from.z));bool moved=d>=2;
            bool hasIntent=em.HasComponent<SkirmishMoveIntentComponent>(e);var intent=hasIntent?em.GetComponentData<SkirmishMoveIntentComponent>(e):default;
            Write(new Row{stage="Actor",id=ids[e],groupId=groupId,role="Rifle",actorHealth=em.GetComponentData<UnitHealth>(e).Current,allAlive=true,x=pos.x,y=pos.y,z=pos.z,qx=rotation.x,qy=rotation.y,qz=rotation.z,qw=rotation.w,scale=transform.Scale,hasMoveIntent=hasIntent,intentActive=hasIntent?intent.Active:0,order=hasIntent?intent.Order.ToString():"Absent",intentTargetIndex=intent.AttackTarget.Index,intentTargetVersion=intent.AttackTarget.Version,manualMoveMarker=em.HasComponent<ManualMoveOrderTag>(e),startX=from.x,startZ=from.z,displacement=d,allHeld=held,oldIntentCleared=clear,receipt=receipt,receiptFrame=receiptFrame});
            if(requireHold&&(!held||!clear))all=false;if(requireMoved&&(held||!moved))all=false;
        }return all;
    }
    static void Goal(EntityManager em,bool second)
    {
        Vector3 center=default;foreach(var e in cohort){CheckActor(em,e);var pos=em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position;origins[e]=pos;center+=(Vector3)pos;}center/=cohort.Count;
        Vector3 forward=publicEnemy-publicPlayer;forward.y=0;if(forward.sqrMagnitude<1)throw new InvalidOperationException("Public objective axis absent");forward.Normalize();Vector3 side=Vector3.Cross(Vector3.up,forward);
        site=center+forward*(second?12:18)+side*(second?-6:6);site.y=0;cameraStep=0;
        Write(new Row{stage="PublicMoveGoal",groupId=groupId,goalX=site.x,goalZ=site.z,playerX=publicPlayer.x,playerZ=publicPlayer.z,enemyX=publicEnemy.x,enemyZ=publicEnemy.z,x=center.x,z=center.z,qaOnly=true,reason="Own selected cohort center + actual public objective axis; fixed18/12m forward±6m side"});
    }
    static bool Ground(out Vector2 point)
    {
        point=default;var c=Camera.main;if(c==null)return false;var p=c.WorldToScreenPoint(site);if(p.z<=0)return false;point=p;
        var popup=UnityEngine.Object.FindAnyObjectByType<MatchHudFullMapPopupView>(FindObjectsInactive.Include);if(popup!=null&&popup.IsOpen)return false;
        var es=UnityEngine.EventSystems.EventSystem.current;if(es==null)return false;var hits=new List<UnityEngine.EventSystems.RaycastResult>();es.RaycastAll(new UnityEngine.EventSystems.PointerEventData(es){position=point},hits);
        return Screen.safeArea.Contains(point)&&hits.Count==0;
    }
    static bool CameraOnly()
    {
        if(cameraStep==0){if(UiShellRuntimeGateway.TryReadMatchHudCommandState(out var mode)&&mode.ActiveCommandMode!=Game.Tactical.Contracts.TacticalCommandMode.Select){var commands=UnityEngine.Object.FindAnyObjectByType<MatchOverlayCommandControlsView>();Tap(commands?.SelectButton);return false;}cameraCommandsBefore=AriaCommandEvidence.AcceptedCommands;cameraStep=1;}
        var popup=UnityEngine.Object.FindAnyObjectByType<MatchHudFullMapPopupView>(FindObjectsInactive.Include);
        if(popup==null||!popup.IsOpen){if(cameraStep==3){int after=AriaCommandEvidence.AcceptedCommands;Write(new Row{stage="CameraClosed",commands=after,oldCommands=cameraCommandsBefore,qaOnly=true});if(after!=cameraCommandsBefore)throw new InvalidOperationException("Camera issued troop command");cameraStep=0;return true;}
            foreach(var map in UnityEngine.Object.FindObjectsByType<MatchHudMinimapView>(FindObjectsInactive.Exclude,FindObjectsSortMode.None)){if(map.GetComponentInParent<MatchHudFullMapPopupView>()!=null||map.MapRect==null)continue;var cv=map.GetComponentInParent<Canvas>();var cam=cv!=null&&cv.renderMode!=RenderMode.ScreenSpaceOverlay?cv.worldCamera:null;var pt=RectTransformUtility.WorldToScreenPoint(cam,map.MapRect.TransformPoint(map.MapRect.rect.center));if(Gesture(pt,pt))return false;}return false;}
        if(cameraStep==3){Tap(popup.CloseAction);return false;}var full=popup.Minimap;if(full==null)return false;var canvas=full.GetComponentInParent<Canvas>();var camera=canvas!=null&&canvas.renderMode!=RenderMode.ScreenSpaceOverlay?canvas.worldCamera:null;if(!full.TryGetPresentedMapPoint(site,camera,out var goal))return false;bool drag=full.ViewportRect!=null&&RectTransformUtility.RectangleContainsScreenPoint(full.ViewportRect,goal,camera);var from=drag?RectTransformUtility.WorldToScreenPoint(camera,full.ViewportRect.TransformPoint(full.ViewportRect.rect.center)):goal;var end=drag&&(from-goal).sqrMagnitude<=25?goal+Vector2.up*12:goal;if(Gesture(from,end,drag?.45f:0)){cameraStep=3;Write(new Row{stage="CameraTouch",goalX=site.x,goalZ=site.z,qaOnly=true});}return false;
    }
    static void Tick()
    {
        if(!started||failed||!EditorApplication.isPlaying||Time.frameCount==lastFrame)return;lastFrame=Time.frameCount;
        try
        {
            // Input pump before any wall schedule/busy gate, including native paused frames.
            if(touch!=null)touch.Tick(Time.unscaledTime);
            if(controlsPassed)return;
            if(EditorApplication.timeSinceStartup>deadline)throw new TimeoutException("Stop/manual controls timed out at phase"+step);
            if(!TrySession(out var em,out var session,out var match))return;
            if(step==0&&(int)Stage.GetValue(null)<3)return;
            if(match.Phase!=SkirmishPhase.Playing)throw new InvalidOperationException("Mission ended before complete native controls");
            if(step!=9&&step!=10&&step!=11&&!Mathf.Approximately(Time.timeScale,1))throw new InvalidOperationException("Controls normal speed changed");
            if(step==0)
            {
                if((int)Stage.GetValue(null)<3||ariaTroopCommands<=0||!UiShellRuntimeGateway.ReadAriaPlay().Active)return;
                ariaSystem=World.DefaultGameObjectInjectionWorld.GetExistingSystemManaged<Game.UI.Shell.Ecs.AriaPlayInputSystem>();if(ariaSystem==null)return;oldTouch=(AriaTouchInputUiSystemHelper)AriaDriver.GetValue(ariaSystem);if(oldTouch==null||!oldTouch.IsRunning||oldTouch.IsBusy||oldTouch.IsPressed)return;
                using var aq=em.CreateEntityQuery(typeof(Game.UI.Shell.Contracts.Ecs.AriaPlaySessionComponent));if(aq.CalculateEntityCount()!=1)return;var a=aq.GetSingleton<Game.UI.Shell.Contracts.Ecs.AriaPlaySessionComponent>();float margin=a.DueAt-Time.unscaledTime;
                if(a.Phase is not (Game.UI.Contracts.AriaPlayPhase.Aiming or Game.UI.Contracts.AriaPlayPhase.Verifying)||a.Pressed!=0||a.GestureRequested!=0||margin<Mathf.Max(.65f,.3f+3*Time.unscaledDeltaTime))return;
                if(ariaSystem.ExplicitStops!=0||oldTouch.CompletedGestures!=oldTouch.DispatchedGestures||oldTouch.UnexpectedSamples!=0||oldTouch.PhysicalInterventions!=0)throw new InvalidOperationException("PreStop ARIA input not clean");
                oldOrders.Clear();foreach(var g in em.GetBuffer<SkirmishArmyGroupRecord>(session,true))if(g.FactionId==1&&g.AliveCount>0&&g.LastOrder is Game.Skirmish.Contracts.SkirmishGroupOrderKind.Move or Game.Skirmish.Contracts.SkirmishGroupOrderKind.Attack)oldOrders[g.GroupId]=g.LastOrder;
                if(oldOrders.Count==0)return;
                foreach(var b in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))if(b.name is "WatchAriaPlay" or "AriaInstantStop")
                {var args=new object[]{b,default(Vector2)};if(!(bool)ReadPoint.Invoke(null,args))continue;var point=(Vector2)args[1];oldCompleted=oldTouch.CompletedGestures;commandsBeforeStop=AriaCommandEvidence.AcceptedCommands;
                    if(!oldTouch.TryGesture(point,point,.15f,0,Time.unscaledTime))return;
                    Environment.SetEnvironmentVariable("WARLINE_S004_MANUAL_PROBE","1");Environment.SetEnvironmentVariable("WARLINE_TERMINAL_ACTION","MAIN MENU");
                    Write(new Row{stage="StopDispatched",owner=b.name,active=true,dueMargin=margin,stopBefore=0,oldRunning=true,oldBusy=false,pressed=false,gestureRequested=false,completed=oldCompleted,dispatched=oldCompleted,commands=commandsBeforeStop,qaOnly=true,reason="Same actual native ARIA device taps presentedSTOP; only watchdog env transferred"});
                    foreach(var g in oldOrders)Write(new Row{stage="AcceptedOrderBeforeStop",groupId=g.Key,order=g.Value.ToString()});Next(1,12);return;
                }return;
            }
            if(step==1)
            {
                if(UiShellRuntimeGateway.ReadAriaPlay().Active)return;
                if(UiShellRuntimeGateway.ReadAriaPlay().Phase!=Game.UI.Contracts.AriaPlayPhase.Manual)throw new InvalidOperationException("Stop did not return native Manual phase");
                if(ariaSystem.ExplicitStops!=1||oldTouch.IsRunning||oldTouch.IsBusy||oldTouch.IsPressed||oldTouch.CompletedGestures!=oldCompleted+1||oldTouch.CompletedGestures!=oldTouch.DispatchedGestures||oldTouch.UnexpectedSamples!=0||oldTouch.PhysicalInterventions!=0||AriaCommandEvidence.AcceptedCommands!=commandsBeforeStop)throw new InvalidOperationException("Native Stop/input/accepted order conservation failed");
                bool measured=AriaCommandEvidence.TryReadAudit(oldTouch.CompletedGestures,oldTouch.UnexpectedSamples,out int violations);if(!measured||violations!=0)throw new InvalidOperationException("PreStop recorder phase not clean");
                int found=0;foreach(var g in em.GetBuffer<SkirmishArmyGroupRecord>(session,true))if(oldOrders.TryGetValue(g.GroupId,out var previous)){if(g.LastOrder!=previous)throw new InvalidOperationException("Stop replaced accepted native gameplay intent");found++;Write(new Row{stage="AcceptedOrderAfterStop",groupId=g.GroupId,order=g.LastOrder.ToString()});}if(found!=oldOrders.Count)throw new InvalidOperationException("Accepted native group order vanished during Stop");
                Write(new Row{stage="StopVerified",active=false,stopBefore=0,stopAfter=1,oldRunning=false,oldBusy=false,completed=oldTouch.CompletedGestures,dispatched=oldTouch.DispatchedGestures,unexpected=oldTouch.UnexpectedSamples,interventions=oldTouch.PhysicalInterventions,auditMeasured=measured,violations=violations,commands=AriaCommandEvidence.AcceptedCommands,sameAttempt=true});
                StartManual.Invoke(null,null);touch=(AriaTouchInputUiSystemHelper)Driver.GetValue(null);
                foreach(var frame in UnityEngine.Object.FindObjectsByType<MonoBehaviour>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))if(frame.GetType()==ManualFrameType){if(manualFrame!=null)throw new InvalidOperationException("Multiple QA manual updaters");manualFrame=frame;}
                if(manualFrame==null||!manualFrame.enabled)throw new InvalidOperationException("Unique enabled QA manual updater absent");frameWasEnabled=manualFrame.enabled;manualFrame.enabled=false;originalManualDue=(double)Due.GetValue(null);Due.SetValue(null,EditorApplication.timeSinceStartup+1200);
                Write(new Row{stage="ManualOwnershipHandoff",qaOnly=true,sameAttempt=true,reason="Only QA MonoBehaviour disabled; existing manualTouch/recorder retained; gameplay systems unchanged"});Next(2);return;
            }
            RequireTouch();if(UiShellRuntimeGateway.ReadAriaPlay().Active)throw new InvalidOperationException("ARIA reactivated after deliberate Stop");
            if(touch.IsBusy||EditorApplication.timeSinceStartup<due)return;
            var tray=UnityEngine.Object.FindAnyObjectByType<MatchHudSquadTrayView>();var hud=UnityEngine.Object.FindAnyObjectByType<SkirmishMatchView>();var controls=UnityEngine.Object.FindAnyObjectByType<MatchOverlayCommandControlsView>();
            if(step==2)
            {
                if(tray==null||!UiShellRuntimeGateway.TryReadExpandedSquadPage(out var page)||!UiShellRuntimeGateway.TryReadMatchHudSquadTray(out var cards))return;
                if(page.SelectedGroups>0){Tap(tray.ClearSelectionButton);return;}
                for(int i=0;i<5;i++){var card=cards.GetCard(i);if(!card.Visible||card.AliveCount<=0||card.GroupId==0||card.Title==null||card.Title.IndexOf("RIFLE",StringComparison.OrdinalIgnoreCase)<0)continue;
                    if(Tap(tray.VisibleCardButton(i))){groupId=card.GroupId;actualMembers=card.AliveCount;Next(3);return;}}
                if(page.PreviousPage)Tap(tray.PreviousPageButton);return;
            }
            if(step==3)
            {
                if(!UiShellRuntimeGateway.TryReadExpandedSquadPage(out var page)||page.SelectedGroups!=1)return;BindCohort(em,session);
                if(hud==null)return;publicPlayer=hud.PlayerBaseObjectivePosition;publicEnemy=hud.EnemyBaseObjectivePosition;moveNumber=1;Goal(em,false);Next(4,60);return;
            }
            if(step==4)
            {
                if(controls==null)return;if(cameraStep!=0){CameraOnly();return;}if(!Ground(out _)){CameraOnly();return;}
                if(!UiShellRuntimeGateway.TryReadMatchHudCommandState(out var mode)||mode.ActiveCommandMode!=Game.Tactical.Contracts.TacticalCommandMode.Move){Tap(controls.MoveButton);return;}
                if(!Ground(out var point))return;receipt=0;receiptFrame=0;step=5;
                if(Gesture(point,point)){Write(new Row{stage="NativeMoveTerrainTouch",goalX=site.x,goalZ=site.z,safeArea=Screen.safeArea.Contains(point),noUiHit=true,groupId=groupId});deadline=EditorApplication.timeSinceStartup+60;}else step=4;return;
            }
            if(step==5)
            {
                if(receipt==0)return;bool moved=Sample(em,false,true);if(!moved)return;
                Write(new Row{stage="MoveVerified",receipt=receipt,receiptFrame=receiptFrame,groupId=groupId,members=cohort.Count,allMoved=true,allAlive=true,sameAttempt=true});
                if(moveNumber==2){Complete();return;}Next(6);return;
            }
            if(step==6){if(controls==null)return;receipt=0;receiptFrame=0;holdBefore=touch.CompletedGestures;step=7;if(Tap(controls.HoldButton)){deadline=EditorApplication.timeSinceStartup+30;Write(new Row{stage="HoldTouchDispatched",owner="HoldButton",groupId=groupId,completed=holdBefore,dispatched=touch.DispatchedGestures,qaOnly=true});}else step=6;return;}
            if(step==7)
            {
                if(receiptFrame==0||touch.CompletedGestures!=holdBefore+1||!Sample(em,true))return;heldElapsed=elapsed;Write(new Row{stage="HoldVerified",groupId=groupId,receipt=receipt,receiptFrame=receiptFrame,members=cohort.Count,allHeld=true,oldIntentCleared=true});
                nativeCallback=(EditorApplication.CallbackFunction)Delegate.CreateDelegate(typeof(EditorApplication.CallbackFunction),NativeTick);EditorApplication.update-=nativeCallback;tickRemoved=true;
                Write(new Row{stage="PauseOwnershipHandoff",qaOnly=true,sameAttempt=true,reason="Remove exact inherited QA startup Tick during legitimate pause only; no simulation writes"});Next(8);return;
            }
            if(step==8){foreach(var b in UnityEngine.Object.FindObjectsByType<Button>(FindObjectsInactive.Exclude,FindObjectsSortMode.None))if(b.name=="PauseButton"&&Tap(b)){Next(9);return;}return;}
            if(step==9)
            {
                if(!UiShellRuntimeGateway.TryReadSkirmish(out var model)||!model.Paused)return;
                if(!Sample(em,true))throw new InvalidOperationException("Native pause lost Hold/cleared intent");pausedElapsed=elapsed;pausedAt=EditorApplication.timeSinceStartup;pausedPoses.Clear();foreach(var e in cohort)pausedPoses[e]=em.GetComponentData<Unity.Transforms.LocalTransform>(e);Write(new Row{stage="PausedSnapshot",pausedElapsed=pausedElapsed,allHeld=true,oldIntentCleared=true});Next(10);return;
            }
            if(step==10)
            {
                if(!UiShellRuntimeGateway.TryReadSkirmish(out var model)||!model.Paused||Time.timeScale!=0||elapsed!=pausedElapsed||!Sample(em,true))throw new InvalidOperationException("Native paused Hold/clock changed");
                foreach(var e in cohort){var t=em.GetComponentData<Unity.Transforms.LocalTransform>(e);var old=pausedPoses[e];if(!t.Position.Equals(old.Position)||!t.Rotation.Equals(old.Rotation)||t.Scale!=old.Scale)throw new InvalidOperationException("Native paused transform changed");}
                double wall=EditorApplication.timeSinceStartup-pausedAt;if(wall<1)return;Write(new Row{stage="PausedConserved",pausedElapsed=pausedElapsed,pausedWallSeconds=(float)wall,clockConserved=true,poseConserved=true,allHeld=true,oldIntentCleared=true});
                var popup=UnityEngine.Object.FindAnyObjectByType<PauseOptionsV3PopupView>();if(popup!=null&&Tap(popup.ResumeButton))Next(11);return;
            }
            if(step==11)
            {
                if(UiShellRuntimeGateway.TryReadSkirmish(out var model)&&model.Paused)return;
                if(!Mathf.Approximately(Time.timeScale,1))throw new InvalidOperationException("Native Resume did not restore normal speed");
                if(!Sample(em,true))throw new InvalidOperationException("Hold resurrected old native intent");
                if(tickRemoved){EditorApplication.update+=nativeCallback;tickRemoved=false;phaseElapsed=elapsed;Write(new Row{stage="PauseOwnerRestored",qaOnly=true,restoredExact=true,sameAttempt=true});}
                if(elapsed-phaseElapsed<2)return;Write(new Row{stage="HoldNoResurrection",groupId=groupId,allHeld=true,oldIntentCleared=true,noOldOrderResurrection=true,normalSpeed=true,pausedElapsed=phaseElapsed});moveNumber=2;Goal(em,true);Next(4,60);return;
            }
        }
        catch(Exception e){Fail(e);}
    }
    static void Complete()
    {
        bool measured=AriaCommandEvidence.TryReadAudit(touch.CompletedGestures,touch.UnexpectedSamples,out int violations);if(!measured||violations!=0||touch.IsBusy||touch.CompletedGestures!=touch.DispatchedGestures)throw new InvalidOperationException("Controls native audit not complete/clean");
        controlsPassed=true;Write(new Row{stage="ControlsPassed",controlsPassed=true,completed=touch.CompletedGestures,dispatched=touch.DispatchedGestures,unexpected=touch.UnexpectedSamples,interventions=touch.PhysicalInterventions,auditMeasured=measured,violations=violations,commands=AriaCommandEvidence.AcceptedCommands});
        Due.SetValue(null,originalManualDue);manualFrame.enabled=frameWasEnabled;Write(new Row{stage="ManualOwnerRestored",qaOnly=true,restoredExact=(double)Due.GetValue(null)==originalManualDue&&manualFrame.enabled==frameWasEnabled,sameAttempt=true});S005ManualFogFallback1278.Start(()=>controlsPassed);
    }
    public static void Fail(Exception e)
    {
        if(failed)return;failed=true;failure=e.ToString();if(started)Write(new Row{stage="Failure",reason=failure});
        if(tickRemoved){EditorApplication.update+=nativeCallback;tickRemoved=false;}
        if(manualFrame!=null){manualFrame.enabled=frameWasEnabled;Due.SetValue(null,originalManualDue);}
        if(EditorApplication.isPlayingOrWillChangePlaymode)Finish.Invoke(null,new object[]{true,"externalStopManual1278:"+e.Message});
    }
    public static void Close()
    {
        if(!started)return;Canvas.willRenderCanvases-=Tick;AriaCommandEvidence.Recorded-=OnReceipt;AriaTouchInputUiSystemHelper.Evidence-=OnTouch;if(tickRemoved){EditorApplication.update+=nativeCallback;tickRemoved=false;}
        if(manualFrame!=null){manualFrame.enabled=frameWasEnabled;Due.SetValue(null,originalManualDue);}
        Environment.SetEnvironmentVariable("WARLINE_S004_MANUAL_PROBE",originalManual);Environment.SetEnvironmentVariable("WARLINE_TERMINAL_ACTION",originalTerminal);
        Write(new Row{stage="Closed",controlsPassed=controlsPassed&&!failed,reason=failure,restoredExact=true,qaOnly=true});started=false;
    }
}

// Read-only QA telemetry. Captures the actual private test-driver state and native
// projected roster at render cadence and at real accepted input receipts/releases.
// It does not repair acknowledgments, select units or alter any game/QA scheduling.
public static class S005ManualDriverDiagnostic1278
{
    const string Evidence="/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/native1278-manual-driver-state.jsonl";
    static readonly Type Harness=typeof(SkirmishS002AriaRunHarness);
    const BindingFlags Flags=BindingFlags.NonPublic|BindingFlags.Static;
    static readonly FieldInfo Driver=Harness.GetField("manualTouch",Flags), Step=Harness.GetField("manualStep",Flags),Slot=Harness.GetField("manualSlot",Flags),Verified=Harness.GetField("manualVerifiedAttackMoves",Flags),Before=Harness.GetField("manualAttackMovesBeforeOrder",Flags),Attack=Harness.GetField("manualAttackReceipts",Flags),Retry=Harness.GetField("manualOrderRetries",Flags),Awaiting=Harness.GetField("manualAwaitingStructureOrder",Flags),CameraPending=Harness.GetField("manualCameraFocusPending",Flags),Due=Harness.GetField("manualDue",Flags),Deadline=Harness.GetField("manualDeadline",Flags);
    static bool started;static int lastFrame=-1;static double next;
    [Serializable] public sealed class Row
    {
        public string stage="",attempt="",operation="",phase="",id="",role="";
        public int frame,step,slot,verifiedAttackMoves,beforeOrder,attackReceipts,retries,page,selectedMask,assaultMask,structureMask,attackOrderMask,selectedGroups,health;
        public uint receipt,groupId,completed,dispatched,unexpected,interventions;
        public float elapsed,x,z;public double due,deadline;
        public bool awaitingStructure,cameraPending,pageAvailable,selected,living,driverAvailable,driverRunning,driverBusy,verified,paused;
    }
    public static void Start()
    {
        foreach(var f in new[]{Driver,Step,Slot,Verified,Before,Attack,Retry,Awaiting,CameraPending,Due,Deadline})if(f==null)throw new MissingFieldException("Read-only manual diagnostic contract absent");
        using(File.Open(Evidence,FileMode.CreateNew,FileAccess.Write,FileShare.Read)){}
        started=true;next=0;lastFrame=-1;Canvas.willRenderCanvases+=Sample;AriaCommandEvidence.Recorded+=Receipt;AriaTouchInputUiSystemHelper.Evidence+=Touch;
    }
    static void Write(Row row){row.frame=Time.frameCount;File.AppendAllText(Evidence,JsonUtility.ToJson(row)+"\n");}
    static void Receipt(string operation,uint receipt,bool verified){if(started)Capture("AcceptedReceipt",operation,receipt,verified,false);}
    static void Touch(AriaTouchInputUiSystemHelper source,string kind,Vector2 position)
    {
        if(started&&kind=="Ended"&&ReferenceEquals(source,Driver.GetValue(null)))Capture("ManualTouchEnded",kind,0,false,false);
    }
    static void Sample()
    {
        if(!started||!EditorApplication.isPlaying||lastFrame==Time.frameCount||EditorApplication.timeSinceStartup<next)return;
        lastFrame=Time.frameCount;next=EditorApplication.timeSinceStartup+.25;Capture("ManualDriverState","",0,false,true);
    }
    static void Capture(string stage,string operation,uint receipt,bool verified,bool actors)
    {
        var touch=Driver.GetValue(null) as AriaTouchInputUiSystemHelper;if(touch==null)return;
        var w=World.DefaultGameObjectInjectionWorld;if(w==null||!w.IsCreated)return;var em=w.EntityManager;
        using var query=em.CreateEntityQuery(typeof(SkirmishExpandedSessionComponent),typeof(SkirmishObjectiveClockComponent));if(query.CalculateEntityCount()!=1)return;var session=query.GetSingletonEntity();var owned=em.GetComponentData<SkirmishExpandedSessionComponent>(session);var clock=em.GetComponentData<SkirmishObjectiveClockComponent>(session);
        bool hasPage=UiShellRuntimeGateway.TryReadExpandedSquadPage(out var page);
        Write(new Row{stage=stage,operation=operation,receipt=receipt,verified=verified,attempt=owned.SessionId.ToString(),elapsed=clock.ElapsedSeconds,paused=clock.Paused!=0,step=(int)Step.GetValue(null),slot=(int)Slot.GetValue(null),verifiedAttackMoves=(int)Verified.GetValue(null),beforeOrder=(int)Before.GetValue(null),attackReceipts=(int)Attack.GetValue(null),retries=(int)Retry.GetValue(null),awaitingStructure=(bool)Awaiting.GetValue(null),cameraPending=(bool)CameraPending.GetValue(null),due=(double)Due.GetValue(null),deadline=(double)Deadline.GetValue(null),pageAvailable=hasPage,page=page.PageIndex,selectedMask=page.SelectedMask,assaultMask=page.AssaultMask,structureMask=page.StructureMask,attackOrderMask=page.AttackOrderMask,selectedGroups=page.SelectedGroups,driverAvailable=true,driverRunning=touch.IsRunning,driverBusy=touch.IsBusy,completed=touch.CompletedGestures,dispatched=touch.DispatchedGestures,unexpected=touch.UnexpectedSamples,interventions=touch.PhysicalInterventions});
        if(!actors)return;
        using var aq=em.CreateEntityQuery(typeof(SkirmishAttemptOwnedComponent),typeof(SkirmishArmyGroupMembershipComponent),typeof(SkirmishUnitRoleComponent),typeof(UnitHealth),typeof(Unity.Transforms.LocalTransform),typeof(SelectedUnitTag));using var entities=aq.ToEntityArray(Unity.Collections.Allocator.Temp);
        foreach(var e in entities){var o=em.GetComponentData<SkirmishAttemptOwnedComponent>(e);if(o.FactionId!=1||!o.SessionId.Equals(owned.SessionId))continue;var pos=em.GetComponentData<Unity.Transforms.LocalTransform>(e).Position;var hp=em.GetComponentData<UnitHealth>(e).Current;Write(new Row{stage="SelectedActor",attempt=owned.SessionId.ToString(),elapsed=clock.ElapsedSeconds,id=o.StableObjectId.ToString(),role=em.GetComponentData<SkirmishUnitRoleComponent>(e).Role.ToString(),groupId=em.GetComponentData<SkirmishArmyGroupMembershipComponent>(e).GroupId,health=hp,x=pos.x,z=pos.z,selected=true,living=hp>0&&o.CapacityReleased==0});}
    }
    public static void Close(){if(!started)return;Canvas.willRenderCanvases-=Sample;AriaCommandEvidence.Recorded-=Receipt;AriaTouchInputUiSystemHelper.Evidence-=Touch;Write(new Row{stage="Closed"});started=false;}
}
