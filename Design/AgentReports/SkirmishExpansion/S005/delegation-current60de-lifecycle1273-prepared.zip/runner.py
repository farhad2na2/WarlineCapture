"""Reconstructed current-source ten-cycle lifecycle runner; original1226 runner unavailable, strict1263 closure lineage retained. Root must review/compile and explicitly release heavy lane before execution."""
import argparse,csv,hashlib,importlib.util,json,pathlib,re,subprocess,sys

ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
STATE=REPORT/'TECHNICAL_READINESS_CURRENT.json'
FIXTURE=pathlib.Path('/private/tmp/s005-lifecycle1273/S005Lifecycle1273.cs')
PREP=pathlib.Path('/private/tmp/s005-lifecycle1273/manifest.json')
HELPER=pathlib.Path('/private/tmp/warline-s005-source-manifest.py')
IDLE_HELPER=pathlib.Path('/private/tmp/S005MainIdle1242.cs')
LOG='native-1273-lifecycle-fa-seed104734.log'
OBS='native1273-lifecycle-observation.jsonl'
ARCHIVE='native1273-lifecycle-observer.cs.txt'
METHOD='S005Lifecycle1273.RunValidation'

def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def new_json(p,d):
 with p.open('x') as f:f.write(json.dumps(d,indent=2)+'\n')
def idle_state():
 s=read(STATE)
 if s.get('activeRun') is not None:raise RuntimeError('Main heavy lane already owned: '+str(s.get('activeRun')))
 return s
def manifest(prefix):
 for suffix in ('-source-manifest.json','-independent-fingerprint.json'):
  if (REPORT/(prefix+suffix)).exists():raise RuntimeError('Preserve existing manifest '+prefix)
 subprocess.run(['rtk','proxy','python3',str(HELPER),prefix],cwd=ROOT,check=True)
 return prefix+'-source-manifest.json'
def cli_json(arguments,path):
 result=subprocess.run(['rtk','proxy','unity','command',*arguments,'--project-path',str(ROOT),'--format','json'],cwd=ROOT,capture_output=True,text=True)
 with path.open('x') as f:f.write(result.stdout)
 if result.stderr:new_json(path.with_name(path.name+'.stderr.json'),{'stderr':result.stderr,'exit':result.returncode})
 value=json.loads(result.stdout)
 if result.returncode!=0 or value.get('success') is not True or value.get('data',{}).get('success') is not True or value.get('data',{}).get('result',{}).get('success') is not True:raise RuntimeError('Native CLI outer/nested failure: '+path.name)
 return value['data']['result'].get('result')
def verify_aria_no_physical_takeover(log_text, touch_rows):
 if '[AriaTouchInput] physicalTakeover' in log_text or 'ariaStopped:Manual' in log_text:
  raise ValueError('Physical input takeover/Manual abort cannot qualify an ARIA baseline')
 if not touch_rows or any(row.get('kind')=='PhysicalTakeover' or any(row.get(key)!=0 for key in ('unexpected','interventions','receiptViolations')) for row in touch_rows):
  raise ValueError('Every ARIA native Touch row must have zero unexpected/interventions/receipt violations and no physical takeover')

def native_idle(tag):
 if sha(IDLE_HELPER.read_bytes())!=prep['nativeIdleHelperSha256']:raise RuntimeError('Reviewed new idle helper changed')
 path=REPORT/('native1273-'+tag+'-native-idle.json')
 raw=cli_json(['run_script','--file',str(IDLE_HELPER),'--entry','S005MainIdle1242.Run','--timeout_ms','30000'],path)
 evidence=read(path);data=evidence['data'];params=data['parameters']
 value=json.loads(raw)
 if params.get('file')!=str(IDLE_HELPER) or params.get('entry')!='S005MainIdle1242.Run' or params.get('timeout_ms') not in ('30000',30000) or data.get('target',{}).get('projectPath')!=str(ROOT) or any(value.get(k) is not False for k in ('applicationIsPlaying','editorIsCompiling','editorIsUpdating','editorIsPlayingOrWillChangePlaymode')) or value.get('assemblyCompilationState')!='Idle' or value.get('assemblyCompilationStateOwner')!='UnityEditor.EditorApplication.isCompiling' or value.get('dataPath')!=str(ROOT/'Assets') or not isinstance(value.get('activeScenePath'),str):raise RuntimeError('Actual reviewed read-only main native idle check failed: '+tag)

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('pre_manifest',help='Root-selected current complete source-manifest basename, required to match fresh source before native calls')
ap.add_argument('--dry-compile-proof',required=True)
ap.add_argument('--heavy-lane-owner',required=True,choices=['main1273'])
args=ap.parse_args()
idle_state();prep=read(PREP)
if pathlib.Path(args.pre_manifest).name!=args.pre_manifest or not (REPORT/args.pre_manifest).is_file():raise RuntimeError('Existing pre-manifest basename required')
dry_path=pathlib.Path(args.dry_compile_proof)
if dry_path.parent!=REPORT:raise RuntimeError('Native drycompile proof must be archived in exact report directory')
dry=read(dry_path);data=dry.get('data',{});native_compile=data.get('result',{});params=data.get('parameters',{})
if dry.get('success') is not True or data.get('success') is not True or native_compile.get('success') is not True or any(str(d.get('severity','')).lower()=='error' for d in native_compile.get('diagnostics',[])) or params.get('file')!=str(FIXTURE) or params.get('entry')!='S005Lifecycle1273.Run' or params.get('dry_run') not in ('true',True) or data.get('target',{}).get('projectPath')!=str(ROOT):raise RuntimeError('Exact new native fixture drycompile success/parameters/target not proven')
if sha((REPORT/args.pre_manifest).read_bytes())!=prep['expectedFullSourceManifestSha256']:raise RuntimeError('Reviewed complete current source manifest mismatch')

for p,expected in ((FIXTURE,prep['fixtureSha256']),(HELPER,prep['sourceManifestHelperSha256']),(pathlib.Path(prep['parser']),prep['parserSha256'])):
 if sha(p.read_bytes())!=expected:raise RuntimeError('Frozen fixture/helper changed; review required')
for name,expected in prep['sourceContracts'].items():
 if sha((ROOT/name).read_bytes())!=expected:raise RuntimeError('Reviewed source contract changed: '+name)
if sha(pathlib.Path(__file__).read_bytes())!=prep['runnerSha256']:raise RuntimeError('Runner bytes changed from reviewed preparation')
for name in (LOG,LOG+'.dispatch.cs',LOG+'.exit',LOG+'.wrapper-exit',LOG+'.dispatch.json',OBS,ARCHIVE,'native1273-lifecycle-touch.jsonl','native1273-confirmation-ui-diagnostic.jsonl','native1273-parser.py.txt','native1273-lifecycle-pass.json','native1273-lifecycle-failure.json','native1273-runner-start.json','load1273-lifecycle-observer.json','native1273-before-load-native-idle.json','native1273-before-dispatch-native-idle.json','native1273-after-close-native-idle.json','native1273-before-load-native-idle.json.stderr.json','native1273-before-dispatch-native-idle.json.stderr.json','native1273-after-close-native-idle.json.stderr.json','native1273-unclosed-ownership.json','native1273-executed-runner.py.txt',*[f'final-1273-lifecycle-{phase}-{suffix}.json' for phase in ('preflight','pre-dispatch','post') for suffix in ('source-manifest','independent-fingerprint')]):
 if (REPORT/name).exists():raise RuntimeError('Preserve existing1273 artifact '+name)
preflight=manifest('final-1273-lifecycle-preflight')
if read(REPORT/args.pre_manifest)!=read(REPORT/preflight):raise RuntimeError('Supplied source differs from current source; no Unity call started')
if read(REPORT/preflight.replace('-source-manifest.json','-independent-fingerprint.json'))['sourceHash']!=prep['currentCandidateSourceHash']:raise RuntimeError('Fresh whole-source hash differs from reviewed candidate')
native_idle('before-load');idle_state()
new_json(REPORT/'native1273-runner-start.json',{'explicitHeavyLaneOwner':args.heavy_lane_owner,'coordination':'Root supplied token only after explicit T7 release; no implicit ownership takeover','preManifest':args.pre_manifest,'preflightManifest':preflight,'fixtureSha256':prep['fixtureSha256'],'executedRunnerSha256':sha(pathlib.Path(__file__).read_bytes()),'method':METHOD,'normalInput':True,'qaOneWinWatcherAndManualAutoCombatCoordinated':True,'matchResourcesPosesDamageVisibilityClocksOutcomeWrittenByAdapter':False})
with (REPORT/ARCHIVE).open('xb') as f:f.write(FIXTURE.read_bytes())
with (REPORT/'native1273-executed-runner.py.txt').open('xb') as f:f.write(pathlib.Path(__file__).read_bytes())
with (REPORT/'native1273-parser.py.txt').open('xb') as f:f.write(pathlib.Path(prep['parser']).read_bytes())
cli_json(['run_script','--file',str(FIXTURE),'--entry','S005Lifecycle1273.Run','--timeout_ms','30000'],REPORT/'load1273-lifecycle-observer.json')
predispatch=manifest('final-1273-lifecycle-pre-dispatch')
if read(REPORT/args.pre_manifest)!=read(REPORT/predispatch):raise RuntimeError('Source changed before native dispatch')
native_idle('before-dispatch');s=idle_state();s.update(activeRun='native1273',activeLog=LOG,activeScope=METHOD,activePreManifest=args.pre_manifest);STATE.write_text(json.dumps(s,indent=2)+'\n')
print('native1273 normal FA104734 ten Surrender/Replay/setup cycles; explicit root heavy-lane ownership; checked macOS reuse wrapper',flush=True)
wrapper=subprocess.run(['rtk','proxy','Tools/CI/invoke_unity_macos.sh','--reuse','--timeout','1800','--log',str(REPORT/LOG),'--','-executeMethod',METHOD],cwd=ROOT).returncode
with (REPORT/(LOG+'.wrapper-exit')).open('x') as f:f.write(str(wrapper)+'\n')
receipt=REPORT/(LOG+'.exit')
if not receipt.is_file() or not re.fullmatch(r'-?\d+\s*',receipt.read_text()):
 print('Missing/malformed actual native receipt. Keep ownership/evidence; no fallback launch or termination.',flush=True);sys.exit(4)
native=int(receipt.read_text().strip())
try:native_idle('after-close')
except Exception as e:
 new_json(REPORT/'native1273-unclosed-ownership.json',{'result':'Unclosed','wrapperExit':wrapper,'nativeExit':native,'reason':str(e),'ownershipPreserved':True,'playerReady':False});raise
post=manifest('final-1273-lifecycle-post')
same=read(REPORT/args.pre_manifest)==read(REPORT/preflight)==read(REPORT/predispatch)==read(REPORT/post)
fp=read(REPORT/post.replace('-source-manifest.json','-independent-fingerprint.json'));h=fp['sourceHash']
text=(REPORT/LOG).read_text(errors='replace');errors=[]
if wrapper!=0 or native!=0:errors.append('Actual wrapper/native exit must both be0')
if not same or h!=prep['currentCandidateSourceHash']:errors.append('Full source/material manifests changed')
markers=['[S005CandidateAvailability] fixture=EditorMemoryOnly publication=InProgress shippedCatalogModified=0','[S004MenuProfileFixture] chapter1Completed=5 progressionGate=Preserved isolatedProfile=1','[S004MenuJourney] result=Passed input=Touch controls=Skirmish,Scroll,S005,Launch seedFixture=104734 nativeSessionObserved=1','[S004ManualNative] started=1 input=Touch ariaStarted=0','[S005Lifecycle1273] result=Passed cycles=10 scope=NormalNativeSurrenderReplaySetupLifecycle wins=0 playerReady=0']
for marker in markers:
 if marker not in text:errors.append('Missing exact native marker '+marker)
if '[AriaTouchInput] physicalTakeover' in text or 'ariaStopped:Manual' in text:errors.append('Physical takeover cannot qualify lifecycle input')
if re.search(r'error CS\d+|Compilation failed',text):errors.append('Native compilation failed')
qualified=None
try:
 spec=importlib.util.spec_from_file_location('current_native_lifecycle',pathlib.Path(prep['parser']));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 qualified=module.qualify(REPORT,OBS,'native1273-lifecycle-touch.jsonl',True)
except (OSError,ValueError,KeyError,TypeError) as e:errors.append('Actual lifecycle evidence rejected: '+str(e))
proof={'result':qualified['result'] if not errors and qualified else 'Failed','scope':'Current-source S005 FA104734 NORMAL public Menu, ten genuine native Surrender Defeats/eight Replay/one AdjustSetup-Launch/one MainMenu; exact first-frame authored package plus current typed AI reset and pause conservation. Desktop memory review remains separate; no complete combat win, EN Defeat/device claim.','sourceHash':h,'fullSourceUnchanged':same,'preManifest':args.pre_manifest,'preflightManifest':preflight,'preDispatchManifest':predispatch,'postManifest':post,'actualWrapperExit':wrapper,'nativeExit':native,'fixture':ARCHIVE,'fixtureSha256':prep['fixtureSha256'],'executedRunnerSha256':sha(pathlib.Path(__file__).read_bytes()),'parserSha256':prep['parserSha256'],'log':LOG,'logSha256':sha((REPORT/LOG).read_bytes()),'observation':OBS,'observationSha256':sha((REPORT/OBS).read_bytes()) if (REPORT/OBS).is_file() else None,'qualification':qualified,'normalResourcesPosesDamageVisibilityClocksOutcomeInjected':False,'qaOneWinWatcherAndManualAutoCombatCoordinated':True,'genuineDefeats':10 if not errors else None,'countedWins':0,'fullX17Certified':False,'memoryGrowthReviewRequired':True,'shippingPublicationModified':False,'errors':errors,'playerReady':False,'realHumanDeviceAcceptance':False}
new_json(REPORT/('native1273-lifecycle-'+('pass' if not errors else 'failure')+'.json'),proof)
s=read(STATE)
if s.get('activeRun')!='native1273':raise RuntimeError('Main ownership changed; do not clear unrelated lane')
s.update(activeRun=None,activeLog=None,activeScope=None,activePreManifest=None,latestLifecycle1273='native1273-lifecycle-'+('pass' if not errors else 'failure')+'.json');STATE.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({'result':proof['result'],'errors':errors,'sourceHash':h,'playerReady':False}),flush=True)
sys.exit(0 if not errors else 2)
