"""Offline qualification guards only; never writes an aggregate or launches Unity."""
import copy, importlib.util, json, pathlib
P=pathlib.Path(__file__).parent
s=importlib.util.spec_from_file_location('aggregate',P/'verify_current_aria_matrix.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
matrix=m.read(m.MATRIX);canonical=m.read(m.REPORT/matrix['candidateManifest'])
a=importlib.util.spec_from_file_location('contacts',m.ROOT/'Tools/CI/audit_skirmish_native_contacts.py');audit=importlib.util.module_from_spec(a);a.loader.exec_module(audit)
checks=[]
assert m.validate_retry_lineage(matrix,canonical)['fixtureAndRunnerOnlyIdPathChanges'] is True
checks.append('Real preserved1267 interruption and exact1276 retry lineage')
for r in matrix['runs'][:-1]:
    result=m.validate_case(r,canonical,audit);assert result['id']==r['id'];checks.append('Rechecked actual closed native case '+str(r['id']))
first=matrix['runs'][0];path=m.REPORT/f"native{first['id']}-normal-aria-pass.json";proof=m.read(path);read=m.read
def reject(fn):
    try:fn()
    except ValueError:return
    raise AssertionError('Malformed proof accepted')
for key,value in [('result','Failed'),('sourceHash','other'),('fullSourceUnchanged',False),('errors',['failure']),('normalInput',False),('normalSpeedCertified',False),('countedWinCertified',False),('countsForAriaSeedBaseline',False),('fundingReadinessActorPoseDamageVisibilityOutcomeInjected',True),('actualWrapperExit',143),('nativeBridgeExit',1)]:
    altered=copy.deepcopy(proof);altered[key]=value;m.read=lambda p,altered=altered:altered if pathlib.Path(p)==path else read(p)
    try:reject(lambda:m.validate_case(first,canonical,audit));checks.append('Reject actual proof mutation '+key)
    finally:m.read=read
mutated=copy.deepcopy(matrix);mutated['replacedInterruptedSlot']['qualificationTransferred']=True
reject(lambda:m.validate_retry_lineage(mutated,canonical));checks.append('Reject transferred interrupted qualification')
assert [r['id'] for r in matrix['runs']]==[1263,1264,1265,1266,1276,1268]
assert m.sha(m.MATRIX)==m.MATRIX_SHA
assert [(r['locale'],r['seed']) for r in matrix['runs']]==[('en',104734),('en',130368),('en',155926),('fa-IR',104734),('fa-IR',130368),('fa-IR',155926)]
checks.append('Exact six slots with fresh1276 replacing only interrupted1267')
out=dict(result='Passed',cases=len(checks),checks=checks,scope='Offline strict checks of five actually closed cases and aggregate fail-closed controls; no completed six-case aggregate, no native calls, no readiness edits.',candidateSourceHash=m.SOURCE,nativeCalls=0,aggregateQualified=False,playerReady=False)
with (P/'offline-controls-result.json').open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ('result','cases','scope')}))
