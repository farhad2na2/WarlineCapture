import hashlib,json,pathlib,datetime
root=pathlib.Path.cwd()
run=root/'Logs/SkirmishProduction/SharedNativePreparation/20261015-03-ui-storage'
manifest=root/'Tools/CI/SkirmishProductionDrafts/AriaUiOwnedStorage/manifest.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(manifest)=='c98531ea647895ba48439d2b67123be416c6e975f087e47990d287dc897f5d98'
rows=json.loads(manifest.read_text(encoding='utf-8-sig'))['files']
for r in rows:
    target=root/r['target']; source=root/r['source']
    assert sha(source)==r['sha256'],r['source']
    assert (sha(target) if target.exists() else None)==r['before_sha256'],r['target']
for r in rows:
    target=root/r['target']
    if target.exists():
        backup=run/'before'/r['target']; backup.parent.mkdir(parents=True,exist_ok=True); backup.write_bytes(target.read_bytes())
    target.write_bytes((root/r['source']).read_bytes())
    assert sha(target)==r['sha256']
(run/'IMPORT_RECEIPT.json').write_text(json.dumps({'result':'ImportedExactReviewedSixTargets','manifest_sha256':sha(manifest),'files':rows,'native_pending':True},indent=2)+'\n')
print('[AriaUiStorageImport] result=Passed targets=6 nativePending=1')
