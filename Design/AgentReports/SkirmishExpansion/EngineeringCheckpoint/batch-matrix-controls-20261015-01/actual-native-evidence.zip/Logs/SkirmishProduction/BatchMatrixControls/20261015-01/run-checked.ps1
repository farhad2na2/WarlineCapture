$ErrorActionPreference='Stop'
$project='D:\Projects\WarlineCapture'
$run=Join-Path $project 'Logs\SkirmishProduction\BatchMatrixControls\20261015-01'
$ownedExit=1
try {
    & (Join-Path $project 'Tools\CI\ResolveUnityEditor.ps1') -UnityVersion '6000.5.8f1' -OutputPath (Join-Path $run 'unity-editor.txt') -LogFile (Join-Path $run 'resolver.log')
    if($LASTEXITCODE -ne 0){throw 'Checked Editor resolution failed'}
    $unity=[IO.File]::ReadAllText((Join-Path $run 'unity-editor.txt')).Trim()
    $marker='[SkirmishProductionMatrixAuthorityTests] result=Passed methods=7 baselineSlots=720 syntheticStressSlots=1200 nativeJobs=0 queueSuccessEnabled=0'
    & (Join-Path $project 'Tools\CI\InvokeUnityExecuteMethodValidation.ps1') -UnityExe $unity -ProjectPath $project -ExecuteMethod 'Game.Tests.Editor.SkirmishProductionMatrixAuthorityTests.RunFocusedValidation' -LogFile (Join-Path $run 'unity.log') -RequiredPassMarker $marker -BuildTarget Android -GuiLicensing -TimeoutSeconds 900
    if($LASTEXITCODE -ne 0){throw 'Native matrix controls failed'}
    $ownedExit=0
}catch{[Console]::Error.WriteLine($_.ToString())}
finally{[IO.File]::WriteAllText((Join-Path $run 'checked-child-exit.txt'),[string]$ownedExit)}
exit $ownedExit
