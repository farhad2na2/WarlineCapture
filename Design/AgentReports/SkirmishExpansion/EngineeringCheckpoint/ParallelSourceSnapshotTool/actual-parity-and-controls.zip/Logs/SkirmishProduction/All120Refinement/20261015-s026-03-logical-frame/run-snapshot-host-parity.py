from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,time

root=Path(__file__).resolve().parents[4]
directory=Path(__file__).resolve().parent
assert (root/'Assets').is_dir(),root
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
old=root/'Tools/CI/s005_windows_source_snapshot.py'
new=root/'Tools/CI/SkirmishProductionDrafts/ParallelSourceSnapshot/s005_windows_source_snapshot.py'
manifest=root/'Tools/CI/SkirmishProductionDrafts/ParallelSourceSnapshot/manifest.json'
review=root/'Tools/CI/SkirmishProductionDrafts/ParallelSourceSnapshot/INDEPENDENT_REVIEW.json'
control=root/'Logs/SkirmishProduction/Offline/ParallelSourceSnapshotControls/5b3a57219c67447fa39fb00aadcc132d/result.json'
baseline=directory/'source-before.json'
row=json.loads(manifest.read_text())['files'][0]
assert sha(old)==row['before_sha256'] and sha(new)==row['sha256']
assert sha(review)=='cb1238b41a07f32a7a20713170d8946e606765e0a802b5a0de12360796e41577'
assert sha(control)=='26f7aebacd02ec5698fcac94bceee10b87ec57835f2d8c498949a7ceb560d0d7'
inputs=[old,new,manifest,review,control,baseline,Path(__file__)]
pins={p.as_posix():sha(p) for p in inputs}
spec=importlib.util.spec_from_file_location('actual_installed_snapshot',old)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
dll_before,build_before=module.build_snapshot(root)
jobs=[]
for label,tool,name in [('old',old,'source-after.json'),('parallel',new,'source-after-parallel.json')]:
    output=directory/name
    assert not output.exists(),output
    stdout=directory/(label+'-snapshot.stdout.log');stderr=directory/(label+'-snapshot.stderr.log')
    assert not stdout.exists() and not stderr.exists()
    out=stdout.open('x',encoding='utf-8');err=stderr.open('x',encoding='utf-8')
    argv=[sys.executable,str(tool),'--project',str(root),'--output',str(output),'--capture-only']
    started=time.perf_counter()
    process=subprocess.Popen(argv,cwd=root,stdout=out,stderr=err)
    jobs.append(dict(label=label,tool=tool,output=output,stdout=stdout,stderr=stderr,handles=(out,err),
        process=process,argv=argv,start=started))
for job in jobs:
    job['exit_code']=job['process'].wait()
    job['elapsed_seconds']=time.perf_counter()-job['start']
    for handle in job['handles']:handle.close()
dll_after,build_after=module.build_snapshot(root)
changed_inputs=[p for p,h in pins.items() if sha(p)!=h]
receipts=[]
for job in jobs:
    receipts.append({k:job[k] for k in ['label','argv','exit_code','elapsed_seconds']}|
        {'output':job['output'].as_posix(),'output_sha256':sha(job['output']) if job['output'].exists() else None,
         'stdout_sha256':sha(job['stdout']),'stderr_sha256':sha(job['stderr']),
         'captured_marker_present':'[S005WindowsSourceSnapshot] result=CapturedUnqualified' in job['stdout'].read_text(encoding='utf-8')})
result={'scope':'ConcurrentHostParityNotSpeedBenchmark','execution_context':'Host via explicitly authorized escalated RTK Python',
    'input_sha256':pins,'input_mismatches':changed_inputs,'jobs':receipts,
    'dll_guard_before':dll_before,'dll_guard_after':dll_after,'dll_guard_equal':dll_before==dll_after and build_before==build_after,
    'result':'Failed','native_executed':False,'actual_tool_changed':False,'speedup_claim':False}
if all(r['exit_code']==0 and r['captured_marker_present'] for r in receipts):
    left=json.loads(jobs[0]['output'].read_text(encoding='utf-8'))
    right=json.loads(jobs[1]['output'].read_text(encoding='utf-8'))
    previous=json.loads(baseline.read_text(encoding='utf-8'))
    equality={key:left[key]==right[key] for key in ['source_manifest','candidate_sha256','build_manifest','build_sha256']}
    pre_sources={v['path']:v['sha256'] for v in previous['source_manifest']}
    post_sources={v['path']:v['sha256'] for v in left['source_manifest']}
    before_dll={v['path']:v['sha256'] for v in previous['build_manifest']}
    after_dll={v['path']:v['sha256'] for v in left['build_manifest']}
    result.update({'complete_output_byte_equality':jobs[0]['output'].read_bytes()==jobs[1]['output'].read_bytes(),
        'field_equality':equality,'source_count':len(left['source_manifest']),'build_count':len(left['build_manifest']),
        'candidate_sha256':left['candidate_sha256'],'build_sha256':left['build_sha256'],
        'pre_native_source_manifest_equal':previous['source_manifest']==left['source_manifest'],
        'pre_native_candidate_hash_equal':previous['candidate_sha256']==left['candidate_sha256'],
        'pre_native_source_diffs':[{'path':p,'before':pre_sources.get(p),'after':post_sources.get(p)} for p in sorted(pre_sources.keys()|post_sources.keys()) if pre_sources.get(p)!=post_sources.get(p)],
        'pre_native_dll_diffs':[{'path':p,'before':before_dll.get(p),'after':after_dll.get(p)} for p in sorted(before_dll.keys()|after_dll.keys()) if before_dll.get(p)!=after_dll.get(p)],
        'expected_compile_boundary':'Native835-to836 Editor partial import; list actual DLL changes without assuming equality across native compilation'})
    if result['complete_output_byte_equality'] and all(equality.values()) and result['pre_native_source_manifest_equal'] and result['pre_native_candidate_hash_equal'] and result['dll_guard_equal'] and not changed_inputs:
        result['result']='PassedConcurrentHostFullParity'
output=directory/'snapshot-host-parity-result.json'
with output.open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'result':result['result'],'receipt':output.as_posix(),'receipt_sha256':sha(output),
    'jobs':receipts,'source_diffs':len(result.get('pre_native_source_diffs',[])),'dll_diffs':result.get('pre_native_dll_diffs',[])},indent=2))
raise SystemExit(0 if result['result']=='PassedConcurrentHostFullParity' else 1)
