"""Reconstructed successor: exact1232 observer/fog qualifier plus losslessly recovered1185 strict runner. Not recovery of original1246 bytes. Root native drycompile/review and explicit main1246 lane required."""
import argparse,csv,hashlib,importlib.util,json,pathlib,re,subprocess,sys

ROOT=pathlib.Path('/Users/farhad/Projects/WarlineCapture')
REPORT=ROOT/'Design/AgentReports/SkirmishExpansion/S005'
STATE=REPORT/'TECHNICAL_READINESS_CURRENT.json'
FIXTURE=pathlib.Path('/private/tmp/s005-normal-manual-recovery1246-diagnostic/S005NormalManualR2Recovery1246Observer.cs')
PREP=pathlib.Path('/private/tmp/s005-normal-manual-recovery1246-diagnostic/prepared.json')
HELPER=pathlib.Path('/private/tmp/warline-s005-source-manifest.py')
LOG='native-1246-normal-manual-r2-recovery-en-seed155926.log'
OBS='native1246-normal-manual-r2-recovery-observation.jsonl'
ARCHIVE='native1246-normal-manual-r2-recovery-observer.cs.txt'
METHOD='S005NormalManualR2Recovery1246Observer.RunValidation'
IDLE=pathlib.Path('/private/tmp/s005-normal-manual-recovery1246-diagnostic/S005NormalRecoveryIdle1246.cs')
QUALIFIER=pathlib.Path('/private/tmp/s005-normal-manual-recovery1246-diagnostic/manual-fog-fallback-qualifier.py')
FALLBACK="native1246-manual-fog-fallback.jsonl"
PAID_QUALIFIER=pathlib.Path('/private/tmp/s005-normal-manual-recovery1246-diagnostic/paid-recovery-qualifier.py')

def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def new_json(p,d):
 with p.open('x') as f:f.write(json.dumps(d,indent=2)+'\n')
def idle_state():
 s=read(STATE)
 if s.get('activeRun') is not None:raise RuntimeError('Main heavy lane already owned: '+str(s.get('activeRun')))
 return s
def manifest(prefix):
 for suffix in ('-source-manifest.json','-independent-fingerprint.json'):
  if (REPORT/(prefix+suffix)).exists():raise RuntimeError('Preserve existing manifest '+prefix)
 subprocess.run(['rtk','proxy','python3',str(HELPER),prefix],cwd=ROOT,check=True)
 return prefix+'-source-manifest.json'
def cli_json(arguments,path):
 result=subprocess.run(['rtk','proxy','unity','command',*arguments,'--project-path',str(ROOT),'--format','json'],cwd=ROOT,capture_output=True,text=True)
 with path.open('x') as f:f.write(result.stdout)
 if result.stderr:new_json(path.with_name(path.name+'.stderr.json'),{'stderr':result.stderr,'exit':result.returncode})
 value=json.loads(result.stdout)
 if result.returncode!=0 or value.get('success') is not True or value.get('data',{}).get('success') is not True or value.get('data',{}).get('result',{}).get('success') is not True:raise RuntimeError('Native CLI outer/nested failure: '+path.name)
 return value['data']['result'].get('result')
def native_idle(tag):
 value=cli_json(['run_script','--file',str(IDLE),'--entry','S005NormalRecoveryIdle1246.Run','--timeout_ms','30000'],REPORT/('native1246-'+tag+'-native-idle.json'))
 if value!='False|False|False|False|False|'+str(ROOT/'Assets'):raise RuntimeError('Correct main Editor/five native owner flags are not idle: '+tag+' actual='+repr(value))

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('pre_manifest',help='Root-selected current complete source-manifest basename, required to match fresh source before native calls')
ap.add_argument('--dry-compile-proof',required=True)
ap.add_argument('--heavy-lane-owner',required=True,choices=['main1246'])
args=ap.parse_args()
idle_state();prep=read(PREP)
dry_path=pathlib.Path(args.dry_compile_proof)
if dry_path.parent!=REPORT:raise RuntimeError('Native drycompile proof must be archived in exact report directory')
dry=read(dry_path);data=dry.get('data',{});native_compile=data.get('result',{});params=data.get('parameters',{})
if dry.get('success') is not True or data.get('success') is not True or native_compile.get('success') is not True or any(str(d.get('severity','')).lower()=='error' for d in native_compile.get('diagnostics',[])) or params.get('file')!=str(FIXTURE) or params.get('entry')!='S005NormalManualR2Recovery1246Observer.Run' or params.get('dry_run') not in ('true',True) or data.get('target',{}).get('projectPath')!=str(ROOT):raise RuntimeError('Exact new native fixture drycompile success/parameters/target not proven')

if pathlib.Path(args.pre_manifest).name!=args.pre_manifest or not (REPORT/args.pre_manifest).is_file():raise RuntimeError('Existing pre-manifest basename required')
for p,expected in ((FIXTURE,prep['fixtureSha256']),(HELPER,prep['sourceManifestHelperSha256']),(IDLE,prep['idleHelperSha256']),(QUALIFIER,prep['fallbackQualifierSha256']),(PAID_QUALIFIER,prep['paidQualifierSha256'])):
 if sha(p.read_bytes())!=expected:raise RuntimeError('Frozen fixture/helper changed; review required')
for name,expected in prep['sourceContracts'].items():
 if sha((ROOT/name).read_bytes())!=expected:raise RuntimeError('Reviewed source contract changed: '+name)
if sha(pathlib.Path(__file__).read_bytes())!=prep['runnerSha256']:raise RuntimeError('Runner bytes changed from reviewed preparation')
for name in (LOG,LOG+'.exit',LOG+'.wrapper-exit',LOG+'.dispatch.json',LOG+'.dispatch.cs',OBS,FALLBACK,ARCHIVE,'native1246-unclosed-ownership.json','native1246-normal-manual-r2-recovery-pass.json','native1246-normal-manual-r2-recovery-failure.json','native1246-runner-start.json','load1246-normal-manual-r2-recovery-observer.json','native1246-normal-manual-r2-native-checkpoint.json','native1246-passenger-carrier-identity.jsonl','native1246-executed-runner.py.txt'):
 if (REPORT/name).exists():raise RuntimeError('Preserve existing1246 artifact '+name)
for tag in ('before-load','before-dispatch','after-close'):
 for suffix in ('-native-idle.json','-native-idle.json.stderr.json'):
  if (REPORT/('native1246-'+tag+suffix)).exists():raise RuntimeError('Preserve prior native idle evidence')
if (REPORT/'load1246-normal-manual-r2-recovery-observer.json.stderr.json').exists():raise RuntimeError('Preserve prior load stderr evidence')
preflight=manifest('final-1246-normal-manual-r2-recovery-preflight')
if read(REPORT/args.pre_manifest)!=read(REPORT/preflight):raise RuntimeError('Supplied source differs from current source; no Unity call started')
if read(REPORT/preflight.replace('-source-manifest.json','-independent-fingerprint.json'))['sourceHash']!=prep['currentCandidateSourceHash']:raise RuntimeError('Whole source differs from reviewed reconstructed current candidate; no Unity call started')
native_idle('before-load');idle_state()
new_json(REPORT/'native1246-runner-start.json',{'explicitHeavyLaneOwner':args.heavy_lane_owner,'coordination':'Root supplied token only after explicit T7 release; no implicit ownership takeover','preManifest':args.pre_manifest,'preflightManifest':preflight,'fixtureSha256':prep['fixtureSha256'],'executedRunnerSha256':sha(pathlib.Path(__file__).read_bytes()),'method':METHOD,'normalInput':True,'matchResourcesPosesDamageVisibilityClocksOutcomeWrittenByAdapter':False})
with (REPORT/ARCHIVE).open('xb') as f:f.write(FIXTURE.read_bytes())
with (REPORT/'native1246-executed-runner.py.txt').open('xb') as f:f.write(pathlib.Path(__file__).read_bytes())
cli_json(['run_script','--file',str(FIXTURE),'--entry','S005NormalManualR2Recovery1246Observer.Run','--timeout_ms','30000'],REPORT/'load1246-normal-manual-r2-recovery-observer.json')
predispatch=manifest('final-1246-normal-manual-r2-recovery-pre-dispatch')
if read(REPORT/args.pre_manifest)!=read(REPORT/predispatch):raise RuntimeError('Source changed before native dispatch')
native_idle('before-dispatch');s=idle_state();s.update(activeRun='native1246',activeLog=LOG,activeScope=METHOD,activePreManifest=args.pre_manifest);STATE.write_text(json.dumps(s,indent=2)+'\n')
print('native1246 normal Menu/ManualR2Recovery EN155926; explicit root heavy-lane ownership; checked macOS reuse wrapper',flush=True)
wrapper=subprocess.run(['rtk','proxy','Tools/CI/invoke_unity_macos.sh','--project',str(ROOT),'--reuse','--timeout','1800','--log',str(REPORT/LOG),'--','-executeMethod',METHOD],cwd=ROOT).returncode
with (REPORT/(LOG+'.wrapper-exit')).open('x') as f:f.write(str(wrapper)+'\n')
receipt=REPORT/(LOG+'.exit')
if not receipt.is_file() or not re.fullmatch(r'-?\d+\s*',receipt.read_text()):
 print('Missing/malformed actual native receipt. Keep ownership/evidence; no fallback launch or termination.',flush=True);sys.exit(4)
native=int(receipt.read_text().strip())
try:native_idle('after-close')
except Exception as e:
 new_json(REPORT/'native1246-unclosed-ownership.json',{'result':'Unclosed','wrapperExit':wrapper,'nativeExit':native,'reason':str(e),'ownershipPreserved':True,'playerReady':False});raise
post=manifest('final-1246-normal-manual-r2-recovery-post')
same=read(REPORT/args.pre_manifest)==read(REPORT/preflight)==read(REPORT/predispatch)==read(REPORT/post)
fp=read(REPORT/post.replace('-source-manifest.json','-independent-fingerprint.json'));h=fp['sourceHash']
text=(REPORT/LOG).read_text(errors='replace');errors=[]
if wrapper!=0 or native!=0:errors.append('Actual wrapper/native exit must both be0 for counted win')
if not same:errors.append('Full source/material manifests changed')

markers=['[ExistingEditorValidation] result=Passed executeMethod='+METHOD,'[S005CandidateAvailability] fixture=EditorMemoryOnly publication=InProgress shippedCatalogModified=0','[S004MenuProfileFixture] chapter1Completed=5 progressionGate=Preserved isolatedProfile=1','[S004MenuJourney] result=Passed input=Touch controls=Skirmish,Scroll,S005,Launch seedFixture=155926 nativeSessionObserved=1','[SkirmishNativeShaderGate] result=Passed compiling=0 settledSeconds=2','[S005RoleLifecycle] phase=PaidDelivery role=ApcHeavy','[S005CombatSave] phase=BattleObserved input=Touch','[SkirmishPlayerSave] result=Passed session=','[S005PlayerSaveResume] result=Passed input=Touch','[S005CombatSave] phase=VerifiedInputCarry sameAttempt=1','[S004ManualReceiptAudit] result=Passed measured=1','[S004ManualNative] result=Passed outcome=Victory','[SkirmishTerminalProbe] frozen=1 returnInput=Touch target=MAIN MENU','[SkirmishTerminalProbe] result=Passed reason=frozenResultAnd:MAIN MENU','[SkirmishValidationExit] result=Requested code=0']
for marker in markers:
 if marker not in text:errors.append('Missing actual native manual marker '+marker)
for forbidden in ('[SkirmishS002AriaRun] watchStarted=1','[S004AriaConsent] result=Passed','[S005NativeRecoveryCase] result=Passed','[S005PaidBuildingClearanceCompletion] result=Passed','[S005NormalManualR2Recovery1246] observerFailure=1'):
 if forbidden in text:errors.append('Unexpected ARIA/isolated-only/observer-failure path '+forbidden)
if re.search(r'error CS\d+|Compilation failed',text):errors.append('Native compiler failure')
obs=[];binding=None;trace=None;terminal=None;audit=None;commands=[];snapshot=None;research=[];recovered=None;paid=None;fogproof=None;paidproof=None
try:
 obs=[json.loads(line) for line in (REPORT/OBS).read_text().splitlines() if line.strip()]
 if any(r['stage']=='ObserverFailure' for r in obs):errors.append('Read-only observer failed')
 contexts=[r for r in obs if r['stage']=='RenderedViewportContext' and r.get('nativeViewportMatched') is True]
 if not contexts or any(r.get('samplingPhase')!='CanvasWillRenderCanvases' or abs(r['canvasWidth']-r['screenWidth'])>1 or abs(r['canvasHeight']-r['screenHeight'])>1 for r in contexts):errors.append('Actual native Canvas render viewport evidence missing/invalid')
 boundrows=[r for r in obs if r['stage']=='NativeBoundText']
 for role in ('SetupTitle','SetupObjective','HudPurposeTitle','HudPurposeBody','PlayerBaseCaption','EnemyBaseCaption','CurrentMatchClock','AriaControl','ResultText','MainMenuSkirmishControl'):
  if not any(r['role']==role and r.get('exactBoundReference') is True and r.get('samplingPhase')=='CanvasWillRenderCanvases' and r['activeText'] is True and r['culledText'] is False and r['textAlpha']>.01 and r['ancestorAlpha']>.01 and r['visibleGlyphs']>0 and r['safeAreaOverlap'] is True and r['renderedBody'] is True for r in boundrows):errors.append('Strict actual native bound rendered text missing: '+role)
 if not any(r['stage']=='NormalDriverFlags' and r['normalDriverFlags'] is True for r in obs):errors.append('Native public manual/R2/recovery driver flags not verified')
 bindings=[r for r in obs if r['stage']=='ActualResolvedBinding']
 if len(bindings)!=1:raise ValueError('Exactly one initial actual resolved native session required')
 binding=bindings[0]
 required={'catalog':'S005','definition':'skirmish.s005','size':'Standard','difficulty':'Regular','army':'CombinedArms','start':'FieldBase','readiness':'Field','readinessValue':1,'seed':155926,'deadline':1080,'objective':'BaseAssault','sharedFog':True,'developmentFullVision':False,'locale':'en'}
 if any(binding.get(k)!=v for k,v in required.items()):errors.append('Actual initial resolved setup/gates differ')
 if not binding['attempt']:errors.append('Actual attempt identity absent')
 if not any(r['stage']=='NativeSetupBriefing' and r['seed']==155926 and r['renderedTitle'] and r['renderedObjective'] and r['localizedObjectiveCopy'] for r in obs):errors.append('Actual initial S005 purpose/failure-rule copy missing')
 if not any(r['stage']=='NativeHudPurpose' and not r['ariaActive'] and r['renderedTitle'] and r['renderedBody'] and r['localizedPurposeCopy'] for r in obs):errors.append('Actual manual purpose/next action missing')
 if any(r.get('ariaActive') is True for r in obs):errors.append('ARIA was active in manual-only normal path')
 if not any(r['stage']=='NativeAriaControl' and not r['ariaActive'] and r['presentedControl'] and r['renderedBody'] for r in obs):errors.append('Actual inactive ARIA Play control not presented/rendered')
 if not any(r['stage']=='NativeObjectiveStrip' and not r['ariaActive'] and not r['finished'] and all(r.get(k) is True for k in ('renderedPlayerBase','renderedEnemyBase','renderedClock','exactPlayerBinding','exactEnemyBinding','exactClockBinding','clockNumberPresentAndCurrent')) and r.get('expectedPlayerCaption')=='YOUR BASE' and r.get('expectedEnemyCaption')=='ENEMY BASE' and r.get('modelClockNumber') and r.get('nativeClockNumber')==r.get('modelClockNumber') for r in obs):errors.append('Actual typed rendered base captions/current clock missing')
 victories=[i for i,r in enumerate(obs) if r['stage']=='NativeRenderedResultText' and r['finished'] and r['frozenVictory'] and r['renderedTitle'] and r['renderedVictoryWitnessed'] and r['outcome']=='Victory' and r['attempt']==binding['attempt'] and r['title'].upper()=='VICTORY']
 destinations=[(i,r) for i,r in enumerate(obs) if r['stage']=='NativeMainMenuDestination']
 if not destinations or any(not r.get('exactMainMenuOwner') or not r.get('exactMainMenuTitle') or r.get('mainMenuIntent')!='OpenMenuRoute' or r.get('mainMenuRoute')!='QuickCustomSetup' or not r.get('controlPath','').endswith('/Card_Skirmish/Hotspot') or not r.get('mainMenuTitlePath','').endswith('/Card_Skirmish/Title') or not r.get('expectedMainMenuCaption') or not r.get('actualMainMenuCaption') for _,r in destinations):errors.append('Exact actual typed MainMenu Hotspot/directCard/siblingTitle/localized binding missing')
 if not victories or not destinations or any(i<=min(victories) or r['frame']<obs[min(victories)]['frame'] or r['attempt']!=binding['attempt'] or r['shellRoute']!='MainMenu' or r['outcome']!='Victory' or not all(r.get(k) is True for k in ('finished','frozenVictory','renderedVictoryWitnessed','presentedControl','renderedBody','unobscuredDestination','destinationSessionAbsent')) for i,r in destinations):errors.append('Actual rendered MainMenu destination must follow same-attempt native frozen/rendered Victory')
 closed=[r for r in obs if r['stage']=='ClosedObserver']
 if len(closed)!=1 or not all(closed[0].get(k) is True for k in ('setupSeen','bindingSeen','purposeSeen','manualPlaySeen','resultSeen','returnSeen')):errors.append('Strict manual observer closure incomplete')
 runtime=[r for r in obs if r['stage']=='NativeManualRuntime']
 if not runtime or any(r['attempt']!=binding['attempt'] for r in runtime):errors.append('Actual native same-attempt runtime sequence missing')
 playing=[r for r in runtime if r['simulationActive'] and not r['paused']]
 if not playing or any(abs(r['timeScale']-1)>.0001 for r in playing):errors.append('Observed actual normal speed failed')
 research=[r for r in obs if r['stage']=='NativePaidResearch' and r['faction']==1 and r['researchKind']=='Readiness']
 ids=set(r['researchId'] for r in research)
 if len(ids)!=1 or 0 in ids or any(r['attempt']!=binding['attempt'] or r['materialsPaid']!=240 or r['expectedCost']!=240 or r['expectedResearchSeconds']!=45 for r in research):errors.append('Exactly one genuine paid240 native R2 readiness queue required')
 progressing=[r for r in research if r['researchPhase'] in ('Queued','Researching') and 0<r['researchRemainingSeconds']<=45.001]
 completed=[r for r in research if r['researchPhase']=='Completed' and r['researchRemainingSeconds']==0 and r['runtimeReadiness']=='Established' and r['readinessValue']==2]
 if not progressing or not completed or min(r['elapsed'] for r in completed)-progressing[0]['elapsed']<progressing[0]['researchRemainingSeconds']-.55:errors.append('Actual normal-clock R2 progress/completion45-second contract not observed')
 if not any(r['runtimeReadiness']=='Field' and r['readinessValue']==1 for r in runtime) or not any(r['runtimeReadiness']=='Established' and r['readinessValue']==2 for r in runtime):errors.append('Native real Field→Established transition missing')
 if any(r[k]!=0 for r in runtime for k in ('infantryUpgrade','vehicleUpgrade','aircraftUpgrade')):errors.append('Unexpected category upgrades in level-zero R2 journey')
 heavy=[r for r in obs if r['stage']=='NativePaidReservation' and r['faction']==1 and r['role']=='ApcHeavy' and r['phase']=='Live' and r['producer']>0 and r['expectedCost']>0 and r['materialsPaid']==r['expectedCost'] and r['deliveredMembers']==r['members']==1]
 if len(heavy)!=1:errors.append('Exactly one real paid/delivered HeavyAPC receipt required')
 else:paid=heavy[0]
 preactors=[r for r in runtime if paid and r['reservation']==paid['reservation'] and r['actorCount']==1 and r['actorHealth']>0 and r['actorStableId'] and not r['recoveredNativeComplete']]
 recoveredrows=[r for r in obs if r['stage']=='NativeRecoveredSameAttempt' and r['recoveredNativeComplete']]
 if len(recoveredrows)!=1:errors.append('Exactly one actual native recovered-complete same-attempt witness required')
 else:recovered=recoveredrows[0]
 if not preactors or not recovered or not paid or recovered['attempt']!=binding['attempt'] or recovered['runtimeReadiness']!='Established':errors.append('Actual paid HeavyAPC delivery/same-attempt/R2 witnesses missing')
 profiles=[r for r in obs if r['stage']=='InheritedSaveProfile'];checkpoints=[r for r in obs if r['stage']=='ActualNativeCheckpoint']
 if len(profiles)!=1 or len(checkpoints)!=1 or not profiles[0]['inheritedProfileVerified'] or not checkpoints[0]['checkpointNativeValidated']:errors.append('Actual unique inherited profile/native validated checkpoint archive missing')
 else:
  cp=checkpoints[0];archive=REPORT/'native1246-normal-manual-r2-native-checkpoint.json';wire=read(archive)
  if wire['Version']!=1 or sha(wire['Payload'].encode())!=wire['Checksum']:errors.append('Actual persisted native wire checksum differs')
  snapshot=json.loads(wire['Payload'])
  if snapshot['CatalogId']!='S005' or snapshot['SessionId']!=binding['attempt'] or cp['attempt']!=binding['attempt'] or cp['runtimeReadiness']!='Established' or cp['savedElapsed']<=0 or not cp['paused'] or not recovered or recovered['elapsed']<cp['savedElapsed']:errors.append('Actual saved/restored R2 attempt and paused clock differ')
  if not paid or not recovered:raise ValueError('Actual paid/recovered witness absent')
  spec=importlib.util.spec_from_file_location('s005_paid_recovery1246',PAID_QUALIFIER);paidmodule=importlib.util.module_from_spec(spec);spec.loader.exec_module(paidmodule)
  paidproof=paidmodule.qualify(obs,snapshot,paid,recovered,binding,cp)
  if not {'Game.Components.SkirmishResearchStateComponent','Game.Components.SkirmishResearchQueueItem','Game.Components.SkirmishProductionReservation','Game.Components.SkirmishObjectiveClockComponent'}<=set(p['Type'] for p in snapshot['SessionParts']):errors.append('Actual native paid/R2/clock checkpoint Parts absent')
 # Existing native input carry/old-world/receipt checks are required exact markers, not inferred from a fresh actor.
 resume=re.search(r'\[S005PlayerSaveResume\] result=Passed input=Touch gestures=\d+ oldPhysicalGone=\d+ paidReceiptPreserved=1 sameAttempt=1 savedElapsed=[0-9.]+ paidRole=ApcHeavy paidCost=(\d+) combatGestures=\d+ combatSave=1 boardedSave=0 passengers=0 commands=\d+ receiptViolations=0 resumedMissionAcceptance=Pending',text)
 if not resume or not paid or int(resume[1])!=paid['materialsPaid']:errors.append('Actual native paid HeavyAPC combatSave/Continue conservation marker missing')
 trace=pathlib.Path(binding['tracePath'])
 if trace.parent!=REPORT or not re.fullmatch(r's005-aria-live-155926-en-[0-9a-f]{32}\.jsonl',trace.name):raise ValueError('Actual unique native manual trace path differs')
 rows=[json.loads(line) for line in trace.read_text().splitlines() if line.strip()]
 if not rows:raise ValueError('Actual native manual trace is empty; preserve native failure instead of indexing missing terminal')
 terminal=rows[-1]
 if terminal['phase']!='Finished' or terminal['outcome']!='Victory' or terminal['clockPaused']!=1 or terminal['simulationActive']!=0 or not 0<terminal['elapsed']<=1080:errors.append('Actual terminal frozen manual Victory missing')
 rawtouch=[json.loads(line) for line in pathlib.Path(str(trace)+'.touch.jsonl').read_text().splitlines() if line.strip()]
 if not rawtouch or any(any(row.get(k)!=0 for k in ('unexpected','interventions','receiptViolations')) for row in rawtouch):errors.append('All native raw Touch rows must have zero unexpected/interventions/receipt violations')
 spec=importlib.util.spec_from_file_location('s005_native_contact_audit',ROOT/'Tools/CI/audit_skirmish_native_contacts.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);audit=module.audit(rawtouch)
 if audit['errors'] or not audit['strictRecordedContacts'] or not audit['nativeMenuContactsRecorded'] or not audit['terminalContactsRecorded']:errors.append('Strict native Menu/PlayerResume/Manual/Terminal contact pairing failed')
 commands=[json.loads(line) for line in pathlib.Path(str(trace)+'.commands.jsonl').read_text().splitlines() if line.strip()]
 if not commands or any(c['verified'] is not True or not c['receipt'] for c in commands):errors.append('Actual accepted manual command receipt verification failed')
 if not any(c['operation'] in ('AttackMove','ArmyAttack') for c in commands):errors.append('Actual verified manual attack/advance command absent')
 fallbackrows=[json.loads(line) for line in (REPORT/FALLBACK).read_text().splitlines() if line.strip()]
 spec=importlib.util.spec_from_file_location('s005_normal_fog_qualifier1246',QUALIFIER);fogmodule=importlib.util.module_from_spec(spec);spec.loader.exec_module(fogmodule)
 fogproof=fogmodule.qualify(fallbackrows,commands,binding['attempt'],required=False,handoff_proof={'nativeSaveContinuePassed':bool(resume),'sameAttempt':bool(recovered and recovered['attempt']==binding['attempt']),'strictContactAudit':bool(audit and not audit['errors'] and audit['strictRecordedContacts']),'oldPhysicalGone':int(re.search(r'oldPhysicalGone=(\d+)',resume[0])[1]) if resume else 0},terminal_proof={'renderedVictoryPassed':bool(victories),'sameAttemptReturnPassed':bool(destinations and all(row['attempt']==binding['attempt'] and row['shellRoute']=='MainMenu' and row['outcome']=='Victory' and all(row.get(k) is True for k in ('finished','frozenVictory','renderedVictoryWitnessed','presentedControl','renderedBody','unobscuredDestination','destinationSessionAbsent')) for _,row in destinations)),'strictContactAudit':bool(audit and not audit['errors'] and audit['strictRecordedContacts'])})
except (OSError,KeyError,ValueError,TypeError,StopIteration,IndexError) as e:errors.append('Missing/malformed actual normal manual evidence: '+str(e))
proof={'result':'Passed' if not errors else 'Failed','scope':'Current-source genuine public EN155926 manual+paidR2+paidHeavyAPC native lifecycle (strict live recovery OR independently conserved pre-save casualty)+native combat-order SaveContinue+actual manual Victory/rendered result/MainMenu. Hybrid native UI/tactical Touch with read-only public-world projection/raycast target finding; not all-Touch ARIA matrix, real human, device, Stop/takeover or discreteMove/Hold proof.','sourceHash':h,'fullSourceUnchanged':same,'preManifest':args.pre_manifest,'preflightManifest':preflight,'preDispatchManifest':predispatch,'postManifest':post,'actualWrapperExit':wrapper,'nativeBridgeExit':native,'log':LOG,'logSha256':sha((REPORT/LOG).read_bytes()),'fixture':ARCHIVE,'fixtureSha256':prep['fixtureSha256'],'executedRunnerSha256':sha(pathlib.Path(__file__).read_bytes()),'observation':OBS,'observationSha256':sha((REPORT/OBS).read_bytes()) if (REPORT/OBS).is_file() else None,'actualResolvedSetup':binding,'trace':trace.name if trace is not None else None,'terminal':terminal,'inputAudit':audit,'nativePaidHeavyAPC':paid,'nativeRecoveredIdentity':recovered,'nativeResearchObservationCount':len(research),'nativeFogApproach':fogproof,'paidRecoveryLifecycle':paidproof,'countsForLivePaidActorRecovery':bool(paidproof and paidproof['countsForLivePaidActorRecovery'] and not errors),'reconstructedLineage':prep['reconstructedLineage'],'original1246Recovered':False,'exactOriginal128ContractListRecovered':False,'reviewedContractCount':len(prep['sourceContracts']),'normalInput':True,'rendererObservedNormalSpeed':not errors,'countsForCurrentManualAcceptance':not errors,'countsForAriaSeedBaseline':False,'fundingReadinessActorPoseDamageVisibilityOutcomeInjected':False,'preSaveBattleObservedLimitation':'Existing public driver treats unknown enemyHealth0 as less than800; preSave accepted attack receipt proves orders, not observed HPdamage. No damage assertion inferred from that marker.','errors':errors,'playerReady':False,'realHumanDeviceAcceptance':False}
diagnostic=REPORT/'native1246-passenger-carrier-identity.jsonl'
proof['passengerCarrierIdentityDiagnostic']={'path':diagnostic.name,'sha256':sha(diagnostic.read_bytes()) if diagnostic.is_file() else None,'scope':'Read-only per-observed-native-frame current-attempt owned passenger/carrier links, including Disabled; not exact capture-instruction interception or a standalone readiness gate'}
new_json(REPORT/('native1246-normal-manual-r2-recovery-'+('pass' if not errors else 'failure')+'.json'),proof)
s=read(STATE)
if s.get('activeRun')!='native1246':raise RuntimeError('Main ownership changed; do not clear unrelated lane')
s.update(activeRun=None,activeLog=None,activeScope=None,activePreManifest=None,latestNormalManual1246='native1246-normal-manual-r2-recovery-'+('pass' if not errors else 'failure')+'.json');STATE.write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps({'result':proof['result'],'errors':errors,'sourceHash':h,'playerReady':False}),flush=True)
sys.exit(0 if not errors else 2)
