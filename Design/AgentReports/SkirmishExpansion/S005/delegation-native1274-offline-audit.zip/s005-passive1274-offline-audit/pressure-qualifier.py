import math,pathlib,re
REPORT=pathlib.Path('/Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005')
def qualify(inputs,audit_fn):
 errors=[]
 obs=[];trace=None;features={};audits={}
 try:
  obs=inputs['observation']
  def rows(stage):return [r for r in obs if r['stage']==stage]
  def one(stage):
   values=rows(stage)
   if len(values)!=1:raise ValueError('Exactly one actual '+stage+' required')
   return values[0]
  if rows('PassivePressureFailure'):raise ValueError('Native pressure fixture failure')
  fresh=one('FreshNativeAttempt');coord=one('QaPassiveCoordination');defeat=one('NativeFrozenRenderedDefeat');menu=one('NativeMainMenuDestination');summary=one('NativePassivePressureSummary');closed=one('ClosedPassivePressure')
  attempt=fresh['attempt'];trace=pathlib.Path(coord['tracePath'])
  if not attempt or fresh['seed']!=104734 or not all(fresh[k] for k in ('passed','sameBudget','sameRoster','oldRemoved','sharedFog')) or fresh['developmentFullVision'] or fresh['oldPhysical']!=0 or fresh['selected']!=0 or fresh['hold']!=0 or fresh['readiness']!=1 or fresh['deliveredActors']!=0 or fresh['initialActors']<=0 or fresh['owned']<=0 or fresh['markers']<0 or not 0<=fresh['elapsed']<=fresh['baselineElapsed']:raise ValueError('Native exact fresh authored budget/roster/R1/fog/first clock gate missing')
  if coord['attempt']!=attempt or not coord['qaOnlyCoordination'] or not coord['passed'] or coord['manualActions']!=0 or coord['manualAttackReceipts']!=0 or trace.parent!=REPORT or not re.fullmatch(r's005-aria-live-104734-fa-[0-9a-f]{32}\.jsonl',trace.name):raise ValueError('Owned zero-command native manual QA handoff/trace invalid')
  passive=rows('NativePlayerPassivity')
  if len(passive)<2 or any(r['attempt']!=attempt or not r['passed'] or not r['playerPassive'] or any(r[k]!=0 for k in ('manualActions','manualAttackReceipts','selected','hold','receipt','violations')) for r in passive):raise ValueError('Actual full native passive zero-player-command/ARIA stream missing/violated')
  if rows('NativeCommandReceipt'):raise ValueError('Actual accepted player command in passive run')
  runtime=rows('NativePressureRuntime')
  if len(runtime)<2 or any(r['attempt']!=attempt or not math.isfinite(r['elapsed']) or r['elapsed']<0 or r['simulationActive'] and (abs(r['timeScale']-1)>.0001 or r['paused'] or not r['playing']) for r in runtime):raise ValueError('Actual normal-clock enemy pressure stream invalid')
  if any(b['elapsed']<a['elapsed'] for a,b in zip(runtime,runtime[1:])):raise ValueError('Actual native elapsed clock regressed')
  hp=[r['hp'] for r in runtime if r['hp']>=0]
  if not hp or hp[0]!=800 or min(hp)>=800:raise ValueError('Actual original playerbase800 and real HP decline missing')
  planners=rows('NativeEnemyPlanner');groups=rows('NativeArmyGroup');assignments=rows('NativeEnemyAssignment');actors=rows('NativeEnemyActor')
  if len(planners)!=len(runtime) or any(r['attempt']!=attempt or not r['passed'] for r in planners) or not groups or not assignments or not actors:raise ValueError('Actual planner/group/assignment/actor observation coverage missing')
  if any(r['attempt']!=attempt for r in groups+assignments+actors):raise ValueError('Foreign-attempt pressure data')
  if not any(r['faction']==2 and r['groupOrder'] in ('Move','Attack') for r in groups) or not any(r['orderAccepted']==1 and r['groupOrder'] in ('Move','Attack') for r in assignments):raise ValueError('Actual accepted native enemy movement/attack pressure missing')
  if not any(r['initialActor'] and r['bodyPresent'] and r['displacement']>=2 for r in actors):raise ValueError('Actual original enemy actor displacement missing')
  if defeat['attempt']!=attempt or defeat['resultSession']!=attempt or defeat['outcome']!='Defeat' or defeat['reason']!='MainBaseDestroyed' or defeat['saveAcknowledged']!=1 or not 0<defeat['elapsed']<1080 or not all(defeat[k] for k in ('passed','frozen','rendered','captionMatches','viewportMatches')) or defeat['visibleGlyphs']<=0 or not defeat['title'] or not defeat['sourceCopy'] or defeat['samplingPhase']!='CanvasWillRenderCanvases':raise ValueError('Genuine natural same-attempt frozen/rendered localized Defeat before native deadline missing')
  settlement=rows('NativeDefeatSettlementState')
  if not settlement or any(r['attempt']!=attempt or r['resultSession']!=attempt or r['outcome']!='Defeat' or r['reason']!='MainBaseDestroyed' or not r['frozen'] or not r['paused'] or r['playing'] or r['simulationActive'] or r['saveAcknowledged'] not in (0,1) for r in settlement) or not any(r['saveAcknowledged']==1 for r in settlement):raise ValueError('Actual frozen terminal clock/settlement state missing')
  if menu['attempt']!=attempt or menu['shellRoute']!='MainMenu' or not all(menu[k] for k in ('passed','sessionAbsent','rendered','captionMatches','viewportMatches','exactMainMenuOwner','exactMainMenuTitle')) or menu['visibleGlyphs']<=0 or menu['mainMenuIntent']!='OpenMenuRoute' or menu['mainMenuRoute']!='QuickCustomSetup' or not menu['controlPath'].endswith('/Card_Skirmish/Hotspot') or not menu['mainMenuTitlePath'].endswith('/Card_Skirmish/Title') or not menu['actualMainMenuCaption'] or not menu['expectedMainMenuCaption'] or menu['samplingPhase']!='CanvasWillRenderCanvases':raise ValueError('Actual rendered typed native MainMenu destination missing')
  controls=rows('NativeControlTouch')
  if len(controls)!=1 or controls[0]['action']!='Leave' or controls[0]['attempt']!=attempt or obs.index(defeat)>=obs.index(controls[0]) or obs.index(controls[0])>=obs.index(menu):raise ValueError('Exactly one genuine Leave touch after rendered Defeat then MainMenu required')
  if not summary['passed'] or not closed['passed'] or summary['completed']!=1 or summary['completed']!=summary['dispatched'] or any(summary[k]!=0 for k in ('unexpected','interventions','violations')) or obs.index(menu)>=obs.index(summary) or obs.index(summary)>=obs.index(closed):raise ValueError('Actual completed native return/closed Play and QA restoration missing')
  touchrows=inputs['externalTouch']
  native_touch=inputs['inheritedTouch']
  audits={}
  for name,data in (('externalPassive',touchrows),('inheritedPublicNormal',native_touch)):
   if not data or any(r['unexpected']!=0 or r['interventions']!=0 or r['receiptViolations']!=0 for r in data):raise ValueError('Any raw native Touch stream missing/violated '+name)
   audit=audit_fn(data);audits[name]=audit
   if audit.get('errors') or audit.get('strictAllContactsEnded') is not True:raise ValueError('Actual paired contacts fail '+name+' '+str(audit.get('errors')))
   if name=='inheritedPublicNormal' and audit.get('nativeMenuContactsRecorded') is not True:raise ValueError('Real public Menu launch Touch contacts missing')
  reservations=rows('NativePaidReservation');intents=rows('NativeEnemyPaidIntent')
  features={'nativeInitialEnemyActorsMoved':any(r['initialActor'] and r['displacement']>=2 for r in actors),'paidEnemyReservationsObserved':sorted({r['reservationId'] for r in reservations if r['faction']==2 and r['materialsPaid']>0}),'nativePaidEnemyDeliveredReservationsObserved':sorted({r['reservationId'] for r in reservations if r['faction']==2 and r['materialsPaid']>0 and r['deliveredMembers']>0}),'paidIntentStatesObserved':sorted({r['intentState'] for r in intents}),'enemyDutiesObserved':sorted({r['duty'] for r in assignments}),'lastObservedPlayerUnitsLost':runtime[-1]['playerLost'],'lastObservedEnemyUnitsLost':runtime[-1]['enemyLost'],'playerBaseMinimumObservedHp':min(hp),'nativeElapsedAtDefeat':defeat['elapsed'],'paidReplacementScoutDefenseRecoveryQualified':False}
 except Exception as e:errors.append('Strict native passive pressure parser failed: '+str(e))
 if errors:raise ValueError('; '.join(errors))
 return dict(features=features,contactAudits=audits,attempt=attempt,tracePath=str(trace))
