from pathlib import Path
import hashlib, json, struct, sys, time

root = Path('/Users/farhad/Projects/WarlineCapture')
report = root / 'Design/AgentReports/SkirmishExpansion/S005'
extensions = {'.cs', '.asmdef', '.asmref', '.rsp', '.json', '.asset', '.prefab', '.unity', '.shader', '.hlsl', '.cginc', '.compute', '.meta'}
started = time.monotonic()
paths = sorted((p for directory in ('Assets', 'Packages', 'ProjectSettings')
                for p in (root / directory).rglob('*')
                if p.is_file() and p.suffix.lower() in extensions), key=lambda p: str(p).encode('utf-16-be'))
manifest, aggregate, total = {}, hashlib.sha256(), 0
for path in paths:
    relative = path.relative_to(root).as_posix()
    encoded = relative.encode()
    count, prefix = len(encoded), bytearray()
    while count >= 128:
        prefix.append((count & 127) | 128)
        count >>= 7
    prefix.append(count)
    aggregate.update(prefix)
    aggregate.update(encoded)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    raw = digest.digest()
    aggregate.update(struct.pack('<i', len(raw)))
    aggregate.update(raw)
    total += path.stat().st_size
    manifest[relative] = digest.hexdigest()
materials = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in (root / 'Assets').rglob('*.mat')}
fingerprint = dict(sourceHash=aggregate.hexdigest(), sourceFiles=len(paths), sourceBytes=total,
                   seconds=time.monotonic() - started,
                   method='Independent Python SHA-256 with C# BinaryWriter UTF-8 manifest and Ordinal UTF-16 path ordering',
                   scope='All source extensions in Assets/Packages/ProjectSettings; no exclusions added')
(report / (sys.argv[1] + '-independent-fingerprint.json')).write_text(json.dumps(fingerprint, indent=2) + '\n')
(report / (sys.argv[1] + '-source-manifest.json')).write_text(json.dumps(dict(files=manifest, materials=materials), indent=2) + '\n')
print(json.dumps(fingerprint))
