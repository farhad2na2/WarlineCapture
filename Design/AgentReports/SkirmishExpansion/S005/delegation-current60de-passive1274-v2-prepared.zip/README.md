# 1274 runner/metadata-only V2

Original frozen1274 remains untouched. C# fixture/idle and all three outcome/escort/performance qualifiers remain byte-identical. The runner now verifies descriptive metadata against its actual1274 entrypoint/source/hash/locale/seed/deadlines/scope before any native contact. Exact reviewed pre-source manifest hash is required. Native behavior and all original gates remain unchanged.

53 original qualifier controls rerunPASS plus32 metadata/dry-schema controlsPASS;12 previous dry controls remain preserved. New native drycompile is required for the exact copied fixture path (identicalC#bytes, not yet loaded).

Dry entry S005PassivePerformance1274.Run on /private/tmp/s005-passive-performance1274-v2/S005PassivePerformance1274.cs. Archive CLI outer/data/nested successful dry proof with exactproject/parameters under compile1274-passive-v2-reviewed-dry-run.json.

Root-owned invocation after review/dry:

rtk proxy python3 /private/tmp/s005-passive-performance1274-v2/runner.py final-1258-ground-carrier-post-source-manifest.json --dry-compile-proof /Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/compile1274-passive-v2-reviewed-dry-run.json --heavy-lane-owner main1274

Normal FA104734 S005 Standard/Regular public manualMenu launch, QA-only passive handoff, zero playerorders/ARIA, natural MainBaseDestroyed Defeat before1080s, paid enemy delivery/progress, frozen localized renderedDefeat/realLeave/MainMenu, same fullsource/nativewrapper0 and idle. Wrapper2100s, nativefixture1800s. Performance unavailablecounter/gaps/EditorQAoverhead retained: no Android/devicebudget/worstpopulation certificate or playerVictory. No Unity/source/sharedreadiness edits made.
