import copy,importlib.util,pathlib,json
p=pathlib.Path(__file__).parent;s=importlib.util.spec_from_file_location('driver',p/'driver-qualifier.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r={k:0 for k in m.FIELDS};r.update(stage='ManualDriverState',attempt='test',driverAvailable=True,driverRunning=True);data=[r,dict(stage='Closed')];m.qualify(data);count=1
for key in m.FIELDS:
 d=copy.deepcopy(data);del d[0][key]
 try:m.qualify(d)
 except ValueError:count+=1
 else:raise AssertionError('Missing field accepted '+key)
for mutate in [lambda d:d.pop(),lambda d:d[0].update(interventions=1),lambda d:d[0].update(unexpected=1),lambda d:d[0].update(completed=2,dispatched=1),lambda d:d[0].update(elapsed=float('nan'))]:
 d=copy.deepcopy(data);mutate(d)
 try:m.qualify(d)
 except ValueError:count+=1
 else:raise AssertionError('Bad row accepted')
print(json.dumps({'result':'Passed','cases':count,'nativeEvidenceFabricated':False,'scope':'Offline negative parser controls only'}))
