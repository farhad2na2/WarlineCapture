param(
    [Parameter(Mandatory=$true)][string]$UnityExe,
    [Parameter(Mandatory=$true)][string]$ProjectPath,
    [Parameter(Mandatory=$true)][string]$LogFile,
    [Parameter(Mandatory=$true)][string]$RawOutput
)
$ErrorActionPreference = 'Stop'
$env:WARLINE_S005_PLANE_CANARY_OUTPUT = $RawOutput
$env:WARLINE_ARIA_BACKGROUND_VALIDATION = '1'
& (Join-Path $ProjectPath 'Tools/CI/InvokeUnity.ps1') -UnityExe $UnityExe -ProjectPath $ProjectPath -GuiLicensing -NoProcessExit -TimeoutSeconds 2100 -LogFile $LogFile -UnityArguments @('-executeMethod','Game.Editor.SkirmishS002AriaRunHarness.RunS005NormalCameraCalibration')
$taskWrapperExit = $global:LASTEXITCODE
[IO.File]::WriteAllText((Join-Path (Split-Path -Parent $LogFile) 'wrapper-exit.txt'), [string]$taskWrapperExit)
exit $taskWrapperExit
