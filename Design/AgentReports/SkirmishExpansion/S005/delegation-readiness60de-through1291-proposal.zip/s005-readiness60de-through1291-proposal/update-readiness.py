"""Reviewed keyed readiness proposal. Default is read-only; --apply requires idle and exact evidence."""
import argparse,copy,hashlib,json,os,pathlib,tempfile
P=pathlib.Path(__file__).parent
def require(value,message):
 if not value:raise ValueError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def reconcile(current,proposal):
 require(current.get('sourceHash')==proposal['sourceHash'],'Source changed; prepare a fresh proposal')
 require(current.get('activeRun') is None,'Native lane is active; never reconcile owned readiness while running')
 require(current.get('technicallyReady') is False and current.get('playerReady') is False,'Readiness already changed; require fresh review')
 require({k:v for k,v in current.items() if k.startswith('latest')}==proposal['guardLatestSnapshot'],'Completed evidence advanced; refresh proposal before applying')
 prohibited={'activeRun','activeLog','activeScope','activePreManifest','sourceHash','physicalSource','physicalSourceSceneSha256','shippingRuntimeCommit'}
 require(not prohibited.intersection(proposal['changes']),'Proposal must not alter ownership/source/physical/shipping identity')
 out=copy.deepcopy(current)
 for key,change in proposal['changes'].items():
  require((key in current)==change['expectedPresent'],'Key existence changed: '+key)
  require(current.get(key)==change['expected'],'Reviewed key changed: '+key)
  out[key]=copy.deepcopy(change['proposed'])
 require(out['technicallyReady'] is False and out['playerReady'] is False,'No player-ready promotion authorized')
 for key,value in current.items():
  if key not in proposal['changes']:require(out[key]==value,'Untouched historical/unknown key changed: '+key)
 return out
def verify_evidence(proposal):
 report=pathlib.Path(proposal['statePath']).parent
 require(sha(pathlib.Path(proposal['acceptancePath'])) in [proposal['acceptanceBeforeSha256'],proposal['acceptanceProposedSha256']],'Acceptance text changed; review fresh patch')
 for name,pin in proposal['proofPins'].items():
  require(pathlib.Path(name).name==name,'Evidence must use dedicated report basename')
  path=report/name;require(sha(path)==pin['sha256'],'Immutable proof/log changed: '+name)
  if 'result' in pin:
   data=read(path);require(data['result']==pin['result'] and data['sourceHash']==pin['sourceHash'] and data['fullSourceUnchanged'] is True,'Closed evidence no longer matches: '+name)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--apply',action='store_true');parser.add_argument('--backup',type=pathlib.Path);parser.add_argument('--output',type=pathlib.Path)
 args=parser.parse_args();proposal=read(P/'keyed-update.json');state=pathlib.Path(proposal['statePath'])
 original=state.read_bytes();current=json.loads(original);verify_evidence(proposal);updated=reconcile(current,proposal)
 encoded=(json.dumps(updated,indent=2,ensure_ascii=False)+'\n').encode()
 if args.apply:
  require(args.backup is not None and args.backup.is_absolute(),'--apply requires unique absolute external --backup path')
  require(args.output is None,'Use either apply or external preview')
  require(args.backup.resolve()!=state.resolve() and state.parent not in args.backup.resolve().parents,'Backup must be external to shared readiness reports')
  with args.backup.open('xb') as f:f.write(original)
  require(state.read_bytes()==original,'Shared state changed after review; backup preserved, apply aborted')
  descriptor,temporary=tempfile.mkstemp(prefix='readiness-reviewed-',suffix='.json',dir=state.parent)
  try:
   with os.fdopen(descriptor,'wb') as f:f.write(encoded);f.flush();os.fsync(f.fileno())
   require(state.read_bytes()==original,'Shared state changed before atomic replacement')
   os.replace(temporary,state)
  finally:
   if os.path.exists(temporary):os.unlink(temporary)
 elif args.output:
  require(args.output.is_absolute() and pathlib.Path('/private/tmp') in args.output.resolve().parents,'Preview output must be an exclusive external /private/tmp file')
  with args.output.open('xb') as f:f.write(encoded)
 print(json.dumps({'result':'AppliedReviewedKeyedUpdate' if args.apply else 'ReadOnlyProposalValidated','sourceHash':proposal['sourceHash'],'modifiedKeys':list(proposal['changes']),'unknownHistoricalKeysPreserved':True,'ownershipFieldsUntouched':True,'technicallyReady':False,'playerReady':False,'acceptancePatchAppliedByThisScript':False}))
if __name__=='__main__':main()
