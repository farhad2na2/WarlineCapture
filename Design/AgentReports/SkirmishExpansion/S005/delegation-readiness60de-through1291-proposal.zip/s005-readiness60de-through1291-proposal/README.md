# External current-source readiness reconciliation through1291

Proposal only; shared readiness and acceptance files remain untouched. TechnicallyReady/playerReady stay false. The source60de top section reconciles six ARIA cases, EN1262 normal living paid-actor recovery, FA1291 normal paid-casualty conservation/SaveContinue/Victory/MainMenu, independently audited1290 explicitStop/manual, ground-carrier1258 and scoped1273 reset conservation. FA1291 is not live paid-actor recovery. Its native accepted pre-save orders are not an observed hidden-base damage measurement.

Original1278/1287/1290 failures are preserved. Cargo1272/1282/1289, air1280/1284/1288, Campaign1275/1281 remain unqualified.1288 failed first runtime Touch before air prerequisites/effects.1273 leaves fullX17/memory attribution open. Physical automatic takeover, distinct approach, current pressure/performance, relevant stress/family, visual and human/device gates remain pending.

This immutable successor preserves the entire through1290 predecessor at its original path. Keyed updater checks exact original/proposed acceptance hashes, all proof/log pins, all reviewed keys and latest-evidence snapshot, and rejects activeRun/source/readiness/evidence changes. Unknown/historical keys and ownership/map/shipping identity remain unchanged. Current native1274 is active and excluded; do not apply during it. A later closure changing latest keys requires another reviewed snapshot.

Read-only check:
rtk proxy python3 /private/tmp/s005-readiness60de-through1291-proposal/update-readiness.py

After root review and actual idle with the same evidence snapshot, JSON apply:
rtk proxy python3 /private/tmp/s005-readiness60de-through1291-proposal/update-readiness.py --apply --backup /private/tmp/s005-readiness-before-reviewed-through1291.json

Markdown independently, from repository root, only after the same guarded check passes:
rtk git apply --check /private/tmp/s005-readiness60de-through1291-proposal/CURRENT_ACCEPTANCE.patch
rtk git apply /private/tmp/s005-readiness60de-through1291-proposal/CURRENT_ACCEPTANCE.patch

The updater never applies Markdown, touches Unity or certifies player readiness. A unique exclusive external backup is mandatory. No apply commands were executed by this agent.
