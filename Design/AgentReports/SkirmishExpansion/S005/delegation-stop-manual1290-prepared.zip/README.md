# Prepared native 1290 — external QA carry isolation

Unique successor of actually failed 1278. Current source 60de9fddb00f2c22e416b14082f60ad352e173f867515cfe18942f270b4046f9. EN seed 155926, existing public RunS005EditorAriaEnSeed3, Standard/Regular/CombinedArms/FieldBase/Field, authored 1080 seconds and normal resources/fog.

After real active ARIA, real presented Stop and same-attempt accepted-order conservation, the adapter records all native QA resume guard operands. It permits one narrow private QA flag reset only for an inactive identified different prior attempt, never a current/unidentified/active/recovered carry. StartS004ManualProbe must then create a fresh zero-counter native input driver; the original flag is restored after Play fully closes. Internal recovery-record presence is read through its exact unique loaded Type and native ComponentType API. No ECS, actor pose, stock, clock, fog, health, accepted order, terminal outcome or displayed text writes.

All prior Move/Hold/Pause/Resume/Move, native audit, natural Victory, frozen rendered result and exact rendered MainMenu destination gates remain. The same native attempts and raw preStop input stream are retained. QA-only manual scheduling handoff and later native manual fallback are disclosed. This is planned explicitStop takeover, not physical takeover, fresh mission Replay or six-case unattended ARIA qualification.

104 synthetic offline controls: 31 original proof/visual schema, 26 passive driver schema, 10 collision, 37 fresh-driver cleanup/provenance/chronology controls. These establish parser rejection behavior only. Native dry compile and whole journey pending. Original 1278 failure and loaded bytes preserved. Seed3 tactics are unchanged; a natural manual win is not guaranteed.

Dry compile (root-owned, no Play): unity command run_script --file /private/tmp/s005-stop-manual-takeover1290/S005NormalStopManual1290Observer.cs --entry S005NormalStopManual1290Observer.Run --dry_run true --timeout_ms 30000 --project-path /Users/farhad/Projects/WarlineCapture --format json. Preserve output as compile1290-stop-manual-reviewed-dry-run.json in S005 reportdir.

Then root launch:
rtk proxy python3 /private/tmp/s005-stop-manual-takeover1290/runner.py final-1258-ground-carrier-post-source-manifest.json --dry-compile-proof /Users/farhad/Projects/WarlineCapture/Design/AgentReports/SkirmishExpansion/S005/compile1290-stop-manual-reviewed-dry-run.json --heavy-lane-owner main1290

Runner requires exact submitted compile path/entry, outer/data/nested success, exclusive artifacts, idle main, exact current source contracts and complete full source pre/preflight/predispatch/post equality, wrapper/native0, all raw Touch violations/interventions0, genuine normal outcome/render/return and bounded closure. Only exact submitted validated dry proof may preexist. Do not launch concurrently with another root-owned main lane.
